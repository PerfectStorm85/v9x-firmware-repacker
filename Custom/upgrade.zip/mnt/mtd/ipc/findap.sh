#! /bin/sh

TMP=/mnt/mtd/ipc/tmpfs/wf129
TMP1=/mnt/mtd/ipc/tmpfs/wf129t
SEARCH=/mnt/mtd/ipc/tmpfs/wifi.search
count=0

TARGET="/mnt/mtd/ipc"
CONF="$TARGET/conf"
WIFIPATH="$CONF/wifi.conf"
. $WIFIPATH

if [ $WifiType = "Adhoc" ]
then
	NETFLAG=`cat /mnt/mtd/ipc/tmpfs/netflag.dat`
	if [ $NETFLAG -ne 0 ]
	then
		if ps | grep dhcpd | grep mnt
		then
			exit 0
		fi
	fi
fi

if grep 8731 /mnt/mtd/ipc/tmpfs/wifi.type
then
	echo 1 > /proc/net/rtl8733bu/wlan0/survey_info
	sleep 1
	cat /proc/net/rtl8733bu/wlan0/survey_info > $TMP	
else
iwlist wlan0 scanning > $SEARCH
/mnt/mtd/ipc/m_wpa_cli $SEARCH $TMP 0
for count in $(seq 1 4) 
do
    if grep -E ':|NONE|WEP|WPA' $TMP > /dev/null
    then
        break
    else
        if grep -E 'Cell 01|ESSID' $SEARCH > /dev/null
        then
	    	/mnt/mtd/ipc/m_wpa_cli $SEARCH $TMP 1
        else
            break
        fi
    fi
	usleep 500000
done
fi

if grep 7601 /mnt/mtd/ipc/tmpfs/wifi.type
then
	/mnt/mtd/ipc/wfsort $TMP $TMP1 0
elif grep 8731 /mnt/mtd/ipc/tmpfs/wifi.type
then
	/mnt/mtd/ipc/wfsort $TMP $TMP1 3
elif grep 3733 /mnt/mtd/ipc/tmpfs/wifi.type
then
	/mnt/mtd/ipc/wfsort $TMP $TMP1 4
else
	/mnt/mtd/ipc/wfsort $TMP $TMP1 1
fi

mv $TMP1 $TMP
