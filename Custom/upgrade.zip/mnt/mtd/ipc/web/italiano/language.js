﻿// JavaScript Document
//punct
var colon    = ":";
var period   = ".";
var comma    = ",";
var blank    = "&nbsp;";
var exclamation = "!";

//deviceinfo
var str_devname = "ID dispositivo";
var str_devtype = "Tipo di dispositivo";
var str_netstat = "Connessione di rete";
var str_connnum = "Utente corrente";
var str_softver = "Versione software";
var str_webware = "Versione Webware";
var str_rs485ver   = "Versione PTZ";
var str_macaddr = "Indirizzo Mac";
var str_ipaddr = "Indirizzo IP";
var str_submask = "Maschera di sottorete";
var str_gateway = "Gateway";
var str_1stdns = "DNS primario";
var str_2nddns = "DNS secondario";
var str_upnpstatus = "Stato UPnP";
var str_facddnsstatus = "Stato DDNS del produttore";
var str_th3ddnsstatus = "Stato DDNS di terze parti";
var success = "Successo";
var unenable = "Non abilitato";
var fail = "Mancato";
var str_sysstart = "Ora di inizio";
var str_sdstat = "Stato SD";
var str_connwireless = "WiFi";
var str_connwired = "LAN";
var str_conn4g     = "4G";
var str_dnsset = "Tipo di configurazione DNS";
var str_manualdns = "Manuale DNS";
var str_autodns = "Dal server DHCP";
var str_httpport = "Numero di porta HTTP";
var str_rtspport = "Porta RTSP";
var str_rtmpport = "Porta RTMP";
var str_rtspauth = "Controllo delle autorizzazioni RTSP";
var str_cap_cvbs = "Impostazioni CVBS";
var str_cloud = "Impostazioni Cloud";
var str_cloudstat = "Stato Cloud";
var str_notpurchased = "Not Purchased";
var str_retention = "Giorni di conservazione"
var str_exptime = "Expiration Time";

//Terminale
var str_addrcode = "Indirizzo";
var str_protocol = "Protocollo";
var str_portset = "Impostazione Com";
var str_485portset = 485 + str_portset;
var str_485set = "Impostazione 485";
var str_baudrate = "Baudrate";
var str_databit = "Data bit";
var str_stopbit = "Stop bit";
var str_check = "Controlla tipo";
var str_none = "Nessuno";
var str_oddcheck = "Dispari";
var str_evencheck = "Pari";
var str_tiltscope = '(1-50)';
var str_tiltno = 'I giri di crociera non possono essere vuoti';
var tilttes = "Velocità di PTZ";
var tiltnum = "Giri di crociera";
var tiltmunmax = "Gamma dei giri di crociera: 1-50";
var tiltcenter = "Centrato mentre Self Check";
var str_speed0 = "Veloce";
var str_speed1 = "Medio";
var str_speed2 = "Lento";
var str_ptzalarm = "Chiudi l'allarme quando PTZ è in movimento";
var str_lenmodetip = 'Indicatore Modalità di visualizzazione';
var str_lenmode1 = 'Sempre acceso';
var str_lenmode2 = 'Sempre spento';
var str_smartrack="Smart track";

//FTP 
var str_pasvmode = "Modalità passiva";
var str_ftppic_name = "Nome Snap";
var str_time_name = "Nome tempo";
var str_fixed_name = "Nome fisso";
var str_alampic_name = "Nome snap allarmi";
var str_timepic_name = "Nome snap temporale";
var str_filename_set = "Impostazione del nome file";
var str_autocreatedir = "Auto create dir";

//Server
var str_server = "Indirizzo server";
var str_port = "Porta del server";
var str_username = "Nome utente";
var str_password = "Password";
var str_repassword = "Ripeti password";
var str_auth = "Autenticazione";
var str_ftp_path = "Percorso";
var str_ftp_test = "Verifica le impostazioni FTP";
var str_email_test = "Verifica le impostazioni e-mail";

//E-mail
var str_emailset = "Impostazioni e-mail";
var str_smtpserv = "Nome server SMTP:";
var str_sendto = "Invia a";
var str_emailaddr = "Indirizzo e-mail"
var str_sendaddr = "Mittente";
var str_subject = "Oggetto";
var str_info = "Messaggio";
var str_max127c = "La lunghezza massima è 127";
var str_safelink = "Collegamento sicuro";
var str_massl0 = "Nessuno";
var str_massl1 = "SSL";
var str_massl2 = "TLS";
var str_massl3 = "STARTTLS";

// Autoscatto
var str_timeint = "Intervallo snap";
var str_sendemail = "Invia e-mail";
var str_savepic = "Salva immagine sulla scheda SD";
var str_ftpsnap = "Salva immagine sul server FTP";
var str_cloudsnap  = "Salva immagine sul server Cloud";

// Impostazioni di registrazione
var str_recsetup = "Impostazioni di registrazione";
var str_recfile = "Durata dei file registrati";
var str_recplan = "Registrazione programmata";
var str_allday = "Registrazione di tutti i tempi";
var str_allclear = "Nessuna registrazione";
var str_timearea = "Registrazione temporale specificata";
var str_recswitch = "Se aprire la registrazione";
var str_all_area = 'Seleziona lista';
var str_no_area = 'Cancella lista';
var str_recformat = 'Formato di registrazione';

//Allarme
var str_offenon = "Aperto";
var str_offenoff = "Chiuso";
var str_alarmex = "Allarme esterno";
var str_alarmimode = "Modalità allarme esterno";

//audio alarm
var str_alarmaudio = "Allarme audio";
var str_audiorange = "Gamma di volume";

//smd
var str_alarmsmd ="Allarme umanoide";
var str_smdrecognition ="Riconoscimento intelligente umanoide";
var str_smdthreshold ="Soglia";
var str_smdrect ="Incornicia la forma umana";

//Audio
var str_audioset = "Impostazioni audio";
var str_collecta = "Raccolta audio";
var str_auformat = "Tipo audio";
var str_audioin = "Modalità di input";
var str_volumein = "Volume di input";
var str_volumeout = "Volume di output";
var str_inoption = "Input audio";
var str_intype = "Tipo di input";
var str_aumicin = "MIC";
var str_aulinein = "Input lineare";

//Tempo
var str_timenow = "Data e ora correnti";
var str_timedev = "Ora e data sul dispositivo";
var str_change = "Aggiustare";
var str_manualset = "Impostazione manuale";
var str_date = "Data";
var str_time = "Ora";
var str_dateformat = "(Aaaa-mm-gg)";
var str_timeformat = "(Hh: mm: ss)";
var str_daterange = "(1971-01-01 ~ 2036-12-31)";
var str_syncfrompc = "Sincronizza con l'ora del computer";
var str_syncfrompc1 = "Sincronizza con l'ora del PC";
var str_pctime = "Ora del PC";
var str_ntserver = "Network Time Protocol";
var str_ntpserver = "Server NTP";
var str_synctime = "Intervallo";
var str_hour = "Ore";
var str_keeptmset = "Mantieni le impostazioni correnti";
var str_timezone = "Fuso orario";
var str_autotime = "Regola automaticamente l'ora";

//Video
var str_videoset = "Impostazioni video";
var str_videomode = "Formato video";
var str_videocoding = "Codifica video";
var str_resolution = "Risoluzione";
var str_streamrate = "Bit rate";
var str_framerate = "Frequenza fotogrammi massima";
var str_framegap = "Intervallo di fotogrammi chiave";
var str_vcodectrl = "Controllo della velocità in bit";
var str_fixedcr = "CBR";
var str_variablecr = "VBR";
var str_vcodequa = "Qualità dell'immagine";
var str_osdset = "Impostazione OSD";
var str_osdopt = "Opzioni di parentesi";
var str_osdtime = "Timbro orario";
var str_osdname = "Nome della telecamera";
var str_name = "Nome";
var str_maxchn = "Codifica di canale video massimo";
var str_colour = "Colore";
var str_timeshow = "Visualizza ora";
var str_nameshow = "Visualizza nome";
var str_tl = "In alto a sinistra";
var str_tr = "In alto a destra";
var str_bl = "In basso a sinistra";
var str_br = "In basso a destra";

//Piattaforma
var str_plcon = "Abilita";
var str_puidnum = "PUID";
var str_asp = "Porta del server di accesso";
var str_asa = "Indirizzo del server di accesso";
var str_fsp = "Porta del server di inoltro";
var str_fsa = "Indirizzo del server di inoltro";
var str_gpsi = "Intervallo di trasmissione delle informazioni GPS";
var str_msec = "(Millisecondo)";
var str_loginid = "ID dispositivo";
var str_loginpass = "Password";
var str_serverport = "Porta";
var str_serveraddr = "Server";
var str_timeout = "Timeout";
var str_constate = "Stato connessione";
var str_devnum = "ID dispositivo";
var str_dvsn = "Numero di serie";
var str_atransfer = "Trasmissione audio";
var str_alarmtrans = "Trasmissione delle informazioni di allarme";
var str_uid = "UID";
var str_server1 = "Server 1";
var str_server2 = "Server 2";
var str_server3 = "Server 3";
var str_server4 = "Server 4";

// Onvif
var str_onvifenable = "Onvif";
var str_offcheck = "Nessun controllo";
var str_timecheck = "Impostazioni del fuso orario";
var str_videocheck = "Impostazioni immagine";
var str_allow = "Consenti";
var str_prohibit = "Proibisci";
var str_onvifchn = "Via circolazione sottocodice";
var str_onvifsnap = "Cattura il canale";
var str_onvifnvctype = "Tipo NVC";
var str_normal = "Normal";
var str_uniview = "Uniview";

//Allarme
var str_emailalarm = "Allarme e-mail e invia immagine";
var str_sendpic = "Invia immagine";
var str_saverecftp = "Salva video sul server FTP";
var str_relayout = "Relay out";
var str_savevideo = "Salva video sulla scheda SD";
var str_cloudrecord  = "Impostazioni server Cloud";
var str_ftpservset = "Impostazioni server FTP";
var str_alarmplan = "Allarme tempo";
var str_alarmday = "Allarme tutto il tempo";
var str_alarmclear = "Nessun allarme";
var str_alermarea = "Allarme a tempo specificato";
var str_mdalarm_type    ="Allarme Trigger";
var str_mdalarm_single    ="Separate trigger";
var str_mdalarm_union    ="Linkage trigger";
var str_linkset = "Impostazione del collegamento";
var str_snapset = "Acquisizione dell'immagine";
var str_snapnum = "Numero di acquisizione dell'immagine";
var str_alarmpreset = "Preimpostazione del collegamento";
var str_alarmsound = "Suono di collegamento";
var str_alarmbell = "Allarme";
var str_alarmdog = "Cane";
var str_alarmcustom = "Personalizzato";

//Rete
var str_manualip = "Indirizzo IP fisso";
var str_autoip = "Indirizzo IP dinamico";
var str_lnset = "Impostazioni LAN";
var str_ipget = "Tipo di configurazione IP";
var str_internetip = "Indirizzo IP Internet";
var str_netip = "Indirizzo IP Internet";
var str_proddnsset = "Main DDNS";
var str_hostname = "Il tuo dominio";
var str_3thdnsset = "3 ° DDNS";
var str_servprov = "Provider";
var str_autoupnp = "UPnP Port Forwarding";
var str_wlcheck = "Verifica impostazioni wireless";
var str_wlsuccess = "Connesso a WiFi con successo.";
var str_applywl = "Seleziona & quot; Applica & quot; per salvare queste impostazioni.";
var str_wlfailed = "Connessione WiFi fallita.";

//Programma
var str_weekmode = "Usa la modalità settimana";
var str_weekendmode = "Usa la modalità di lavoro";
var str_alltimemode = "Tutti i tempi";
var str_week = "Giorno";
var str_begintime = "Start";
var str_endtime = "End";
var str_workday = "Giorni feriali";
var str_freeday = "fine settimana";
var str_everyday = "Ogni giorno";
var str_sunday = "Domenica";
var str_monday = "Lunedì";
var str_tuesday = "Martedì";
var str_wednesday = "Mercoledì";
var str_thursday = "Giovedì";
var str_friday = "Venerdì";
var str_saturday = "Sabato";

//Navigazione
var str_rtview = "Monitor";
var str_config = "Impostazioni";
var str_avargs = "Media";
var str_videoa = "Video";
var str_imagea = "Immagine";
var str_audioa = "Audio";
var str_netset = "Rete";
var str_wlset = "Wireless";
var str_ddnsset = "Ddns";
var str_plset = "Piattaforma";
var str_onvif = "ONVIF";
var str_p2pset = "P2P";
var str_alarmset = "Allarme";
var str_alarmin = "Allarme in";
var str_mdset = "Rilevamento del movimento";
var str_alaction = "Allarme";
var str_altime = "Schedule";
var str_advset = "Avanzato";
var str_userset = "Utente";
var str_timesnap = "Autoscatto";
var str_timerec = "Registrazione timer";
var str_email = "Email";
var str_ftpset = "FTP";
var str_ptzset = "Terminale";
var str_sysset = "Sistema";
var str_timeset = "Ora";
var str_initset = "Inizializza";
var str_devinfo = "Informazioni sul dispositivo";
var str_systemlog = "Registro di sistema";
var str_videoshade = "Video shade";

// Sd op
var str_sdview = "Scheda SD del browser";
var str_sdfat32 = "Formatta scheda SD come fat32";
var str_sdstop = "Scollega SD Card";

// Sd stat
var str_havesd = "Carta";
var str_nothavesd = "Nessuna carta";
var str_freespace = "Spazio libero"
var str_totalspace = "Spazio totale"

// Sistema bak up
var str_reboot = "Riavvia";
var str_recoverdef = "Impostazioni di fabbrica";
var str_backup = "Dati di impostazione del backup";
var str_recoverbak = "Ripristina";
var str_upgradesys = "Aggiorna";
var str_lenstype = "Tipo di lente";

//Pulsante
var str_btn_reboot = "&nbsp; riavvia &nbsp;";
var str_btn_save = "&nbsp; salva &nbsp;";
var str_btn_confirm = "&nbsp; ok &nbsp;";
var str_btn_query = "&nbsp; mostra &nbsp;";
var str_btn_advanced = "&nbsp; Avanzato &nbsp;";
var str_btn_recoverdef = "impostazioni di fabbrica";
var str_btn_apply = "&nbsp; Applica &nbsp;";
var str_btn_cancel = "Annulla";
var str_btn_clear = "&nbsp; Cancella &nbsp;";
var str_btn_default = "Default";
var str_btn_search = "&nbsp; cerca &nbsp;";
var str_btn_check = "&nbsp; controlla &nbsp;";
var str_btn_close = "&nbsp; chiude &nbsp;";
var str_btn_refresh = "&nbsp; aggiorna &nbsp;";
var str_btn_test = "Test";
var str_btn_cleanlog = "Cancella registro";

// Suggerimento
var str_note_upgrade = "&nbsp; IP Camera sta aggiornando, per favore non spegnere la fotocamera.";
var str_note_upgradeok = "IP Camera aggiornamento successo!";
var str_note_needreset = "Nota: modifica le impostazioni, il sistema si riavvierà automaticamente";
var str_note_needreset0 = "(Nota: modifica le impostazioni, il sistema si riavvierà automaticamente)";
var str_note_needreset1 = "Nota: modifica le impostazioni, riavvia il dispositivo";
var str_note_needreset2 = "(Nota: modifica le impostazioni, riavvia il dispositivo)";
var str_note_astreamnote = "(mobile)";
var str_note_wlsetting = "Controllo WiFi, attendere circa 30 secondi.";
var str_note_inputpath = "Per favore inserisci il percorso del file";
var str_note_inputipaddr = "Per favore inserisci l'indirizzo IP";
var str_note_inputsubmask = "Per favore inserisci l'indirizzo della subnet mask";
var str_note_inputgateway = "Per favore inserisci l'indirizzo del gateway";
var str_note_inputhostname = "Per favore inserisci il dominio";
var str_note_inputusername = "Per favore inserisci il nome utente";
var str_note_inputpassword = "Per favore inserisci il password";
var str_note_inputport = "Per favore inserisci la porta del server";
var str_note_inputpath = "Per favore immetti il percorso root./";
var str_note_testtitle = "Per favore imposta prima e poi digita.";
var str_note_inputservaddr = "Per favore inserisci l'indirizzo del server";
var str_note_inputservname = "Per favore inserisci il nome del server";
var str_note_inputemail = "Per favore inserisci l'indirizzo e-mail";
var str_note_inputsendaddr = "Per favore inserisci l'indirizzo del mittente";
var str_note_inputasp = "Per favore inserisci la porta del server";
var str_note_inputasa = "Per favore inserisci l'indirizzo di accesso";
var str_note_inputfsp = "Per favore immetti la porta del server d'inoltro";
var str_note_inputfsa = "Per favore inserisci l'indirizzo del spedizioniere";
var str_note_inputtimeout = "Per favore inserisci il valore di timeout";
var str_note_inputgpsi = "Per favore inserisci l'intervallo di trasmissione delle informazioni GPS";
var str_note_noinpublicip = "Indirizzo IP Internet: NULL";
var str_note_internetipis = "Indirizzo IP Internet:";
var str_note_vcodequa = "(Minore è il valore, migliore è la qualità dell'immagine e maggiore è il controllo del flusso)";
var str_note_mbsize = "Risoluzione immagine mobile";
var str_note_mdoff = "Nota: il rilevamento del movimento sarà disabilitato quando il primo stream è 320x176";
var str_note_maxframerate = "Le frequenze dei fotogrammi sono oltre 25.";
var str_note_maxbps = "L'intervallo di bit rate è 32-6144.";
var str_note_maxbps1 = "L'intervallo di bit rate è 32-8192.";
var str_note_maxbps2 = "L'intervallo di bit rate è 32-2048.";
var str_note_maxbps3 = "L'intervallo di bit rate è 32-512.";
var str_note_maxbps4 = "L'intervallo di bit rate è 32-256.";
var str_note_atransfer = "(Prima di aprire la trasmissione audio, accedi alla pagina delle impostazioni audio e video, imposti il secondo flusso audio sulla modalità 'accensione', formato AMR)";
var str_note_ipportchange = "L'IP o la porta sono stati cambiati, per favore ricollegati";
var str_note_rhportsame = "Http e rtsp usano la stessa porta";
var str_note_inputdate = "Per favore inserisci la data";
var str_note_inputtime = "Per favore inserisci l'ora";
var str_note_routemode = "(Seleziona la modalità Infrastruttura se si utilizza il router wireless.)";
var str_note_inputascii = "Per favore inserisci caratteri ASCII (la lunghezza è 5 o 13)";
var str_note_inputascii2 = "Per favore inserisci caratteri ASCII (la lunghezza è da 8 a 63)";
var str_note_inputhex = "Per favore inserisci caratteri HEX (la lunghezza è 10 o 26)";
var str_note_inputssid = "Per favore inserisci lo ssid";
var str_note_inputkey = "Per favore inserisci la chiave";
var str_note_inputrekey = "Per favore inserisci la chiave di conferma";
var str_note_nosupportp2p = "WPA / WPA2 non supporta la modalità Point to Point.";
var str_note_turnoffmd = "La risoluzione video è 320x176, il rilevamento del movimento è disabilitato";
var str_note_autoreboot = "La macchina verrà riavviata!";
var str_test_success = "Test ...... Successo.";
var str_test_fail = "Test ...... Non riuscito.";
var str_note_mdalarmtype   = "(L'allarme di attivazione del collegamento richiede l'attivazione sia del rilevamento del movimento sia dell'allarme umanoide.)";



// Errore
var str_err_invaildc = "Include carattere non valido";
var str_err_invaildc2 = "Include carattere non valido. (&, =, \", \\\) ";
var str_err_username = "Errore del nome utente";
var str_err_hostname = "Errore hostname";
var str_err_servname = "Errore nome server";
var str_err_password = "Errore password";
var str_err_port = "Errore porta";
var str_err_userinfo = "Errore di informazioni dell'utente, per favore inserisci di nuovo";
var str_err_servbusy = "Il server è occupato, per favore attendi per un momento";
var str_err_addrcode = "Indirizzo fuori intervallo";
var str_err_port = "Errore porta"
var str_err_servaddr = "Errore indirizzo";
var str_err_smptserv = "Errore porta";
var str_err_emailaddr = "Indirizzo non valido";
var str_err_tooshort = "La lunghezza dell'indirizzo deve essere maggiore di 5";
var str_err_noat = "L'indirizzo deve includere il carattere "+"@";
var str_err_addr1 = "Errore l'indirizzo del destinatario";
var str_err_addr2 = "";
var str_err_addr3 = "";
var str_err_sendaddr = "Errore l'indirizzo del mittente";
var str_err_subject = "Errore oggetto";
var str_err_info = "Errore messaggio";
var str_err_snapint = "L'intervallo dovrebbe essere 5-86400.";
var str_err_recfile = "L'intervallo di tempo di 15-900 secondi";
var str_err_recfile1 = "L'intervallo di tempo di 15-600 secondi";
var str_err_pwdconfirm = "Conferma errore password.";
var str_err_framegap = "Il frame principale è 2-300";
var str_err_gopframe   = "Key frame are less than framerate";
var str_err_osdname = "Numero di parole 'è maggiore di 18.";
var str_err_noname = "Per favore inserisci il nome della telecamera";
var str_err_noblank = "Il nome non può essere vuoto";
var str_err_puid = "Errore Input PUID";
var str_err_asp = "Errore porta del server di accesso";
var str_err_asa = "Errore indirizzo di accesso";
var str_err_fsp = "Errore porta del server d'inoltro";
var str_err_fsa = "Errore indirizzo dello spedizioniere";
var str_err_username = "Errore nome utente";
var str_err_timeout = "Errore valore di timeout di input";
var str_err_tooutrange = "Timeout fuori intervallo";
var str_err_devnum = "Errore ID dispositivo di input";
var str_err_servaddr = "Errore indirizzo di server";
var str_err_input = "Errore di input \ n \ n";
var str_err_addrrange1 = "Indirizzo non valido, il primo numero";
var str_err_addrrange2 = "Iindirizzo non valido, il secondo numero";
var str_err_addrrange3 = "Indirizzo non valido, il terzo numero";
var str_err_addrlast = "Indirizzo non valido, l'ultimo numero"
var str_err_addr = "Indirizzo non valido";
var str_err_value = "valore non valido";
var str_err_pctime = "L'ora del pc non è valida, deve essere compresa tra 1970-01-01 e 2037-12-31";
var str_err_dateformat = "Formato data non valido";
var str_err_dfinput = "Il formato deve essere aaaa-mm-gg";
var str_err_reinputd = "Data non valida, inserisci di nuovo";
var str_err_invaildtmf = "Formato data non valido";
var str_err_timeformat = "Il formato deve essere hh: mm: ss";
var str_err_imvaildtm = "Formato orario non valido";
var str_err_key = "Errore lunghezza della chiave wep. Hex è 10 o 26; ASCII è 5 o 13";
var str_err_ssid = "Errore ssid, include un carattere non valido";
var str_err_rekey = "Errore chiave di conferma";
var str_err_ssid = "Errore ssid, include carattere non valido";
var str_err_ip2gateway = "IP e gateway non nello stesso segmento di rete";
var str_err_volume = "Il volume non è compreso nell'intervallo (1-100), per favore resetta";
var str_err_username = "Il nome utente non può essere lo stesso";
var str_err_nameerr = "Il nome utente può contenere solo lettere e numeri";
var str_err_nousername = "Si prega di inserire il nome utente";
var str_error_none = "Un errore sconosciuto";
var str_error_server = "Impossibile connettersi al server";
var str_error_namepwd = "Utente o password errati";
var str_error_dir = "Errore del percorso";
var str_error_ssl = "Errore di impostazione SSL";


var str_bps32_2048 = "Il primo bit rate del flusso è 32-2048 kbps";
var str_bps32_512 = "Il primo bit rate del flusso è 32-512 kbps";
var str_bps32_256 = "Il primo bit rate del flusso è 32-256 kbps";

//Gamma
var str_1_65535 = "1-65535";
var str_1_223_127 = "Deve essere compreso tra 1 e 223 e non 127";
var str_0_255 = "Deve essere compreso tra 0 e 255";
var str_1_255 = "Deve essere compreso tra 1 e 255";
var str_0_254 = "Deve essere compreso tra 0 e 254";
var str_1_254 = "Deve essere compreso tra 1 e 254"
var str_80or1024_49151 = "(80 or1024 ~ 49151)";
var str_554or1024_49151 = "(554 or1024 ~ 49151)";
var str_1935or1024_49151 = "(1935 o 1024 ~ 49151)";
var str_daterange = "La data deve essere compresa tra 1971-01-01 e 2036-12-31, per favore re-inserisci";
var str_drange = "(1971-01-01 ~ 2036-12-31)";

// no ins
var str_noins0 = "L'emergere di questa pagina mostra:";
var str_noins1 = "1. Non si installa questo controllo ActiveX.";
var str_noins2 = "2. È stato installato, ma esiste una versione aggiornata del controllo ActiveX che è necessario scaricare.";
var str_noins3 = "3. Devi connetterti a Internet.";
var str_noins4 = "Per favore clicca";
var str_noins5 = "Scarica ActivX";
var str_noins6 = "E clicca";
var str_noins7 = "Esegui";
var str_noins8 = "Nella finestra di messaggio pop per installare questo controllo ActiveX, in fine, aggiornare questa pagina web, avviare un dispositivo, poi è possibile visualizzare il video";

// In uso comune
var str_readonly = "Sola lettura";
var str_rate = "Rate";
var str_auto = "Auto";
var str_view = "Visualizza";
var str_minute = "Minuti";
var str_stream = "Stream";
var str_1ststream = "Primo stream";
var str_2ndstream = "Secondo stream";
var str_3thstream = "Terzo stream";
var str_on = "Accesso";
var str_off = "Spento";
var str_online = "Online";
var str_offline = "Offline";
var str_sec = "Secondo"
var str_language_ex  = "Language";
var str_ch_ex        = "Chinese";
var str_en_ex        = "English";
var str_fr_ex        = "Français";
var str_de_ex        = "Deutsch";
var str_it_ex        = "Italiano";
var str_sp_ex        = "Español";
var str_ru_ex        = "русский язык";
var str_ja_ex        = "日本語";
var str_kr_ex        = "Korean";
var str_pl_ex        = "Polski";
var str_language = "Lingua";
var str_chinese = "Cinese";
var str_english = "Inglese";
var str_francaise = "Francese";
var str_deutsch   = "Tedesco";
var str_italiano  = "Italiano";
var str_spanish   = "Spagnolo";
var str_russian   = "русский язык";
var str_japan    = "日本語";
var str_korean   = "Il coreano";
var str_poland    = "Polski";
var str_add = "Azione";
var str_encrypt = "Encrypt";
var str_authen = "Auth";
var str_connetm = "Tipo di rete";
var str_channel = "Canale";
var str_confirm = "Partecipa";
var str_purview = "Purview";


//Fuso orario
var str_GMT1 = 'Linea data internazionale del cambio di data ovest';
var str_GMT2 = 'Samoa';
var str_GMT3 = 'Hawaii';
var str_GMT4 = 'Alaska';
var str_GMT5 = 'Pacific Time (Stati Uniti e Canada)';
var str_GMT6 = 'Chihuahua,';
var str_GMT7 = 'Mountain Time (Stati Uniti e Canada)';
var str_GMT8 = 'Arizona';
var str_GMT9 = 'Saskatchewan';
var str_GMT10 = 'Guadalajars, Città del Messico, Monterrey';
var str_GMT11 = 'Central Time (Stati Uniti e Canada)';
var str_GMT12 = 'America centrale';
var str_GMT13 = 'Indiani (est)';
var str_GMT14 = 'Eastern Time (Stati Uniti e Canada)';
var str_GMT15 = 'Bogota, Lima, Quita';
var str_GMT16 = 'Carcacas';
var str_GMT17 = 'Santiago';
var str_GMT18 = 'Atlantic Time (Canada)';
var str_GMT19 = 'Terranova';
var str_GMT20 = 'Montevideo';
var str_GMT21 = 'Buenos Aires';
var str_GMT22 = 'Brasilia';
var str_GMT23 = 'Mid-Atlantic';
var str_GMT24 = 'Isole di Capo Verde';
var str_GMT25 = 'Azzorre';
var str_GMT26 = 'Dublino, Edimburgo, Lisbona, Londra';
var str_GMT27 = 'Casablance';
var str_GMT28 = 'Amsterdam, Berlino, Berna, Roma, Stoccolma, Vienna';
var str_GMT29 = 'Belgrado, Bratislava, Budapest, Lubiana, Praga';
var str_GMT30 = 'Bruxelles, Copenaghen, Madrid, Parigi';
var str_GMT31 = 'Sarajevo, Skopje, Warsaw, Zagreb';
var str_GMT32 = 'Africa centro-occidentale';
var str_GMT33 = 'Atene, Bucarest, Istanbul';
var str_GMT34 = 'Bucarest';
var str_GMT35 = 'Cairo';
var str_GMT36 = 'Harare, Pretoria';
var str_GMT37 = 'Helsinki, Kiev, Riga, Sofia, Vilnius, Talinn';
var str_GMT38 = 'Gerusalemme';
var str_GMT39 = 'Baghdad';
var str_GMT40 = 'Kuwait, Riyadh';
var str_GMT41 = 'Mosca, San Pietroburgo, Volgograd';
var str_GMT42 = 'Nairobi';
var str_GMT43 = 'Tehran';
var str_GMT44 = 'Abu_Dhabi, Muscat';
var str_GMT45 = 'Baku';
var str_GMT46 = 'Kabul';
var str_GMT47 = 'Ekaterinburg';
var str_GMT48 = 'Islamabad, Karachi';
var str_GMT49 = 'Chennai, Kolkata, Mumbai, New Delhi';
var str_GMT50 = 'Katmandu';
var str_GMT51 = 'Novosibirsk';
var str_GMT52 = 'Dhaka';
var str_GMT53 = 'Astana';
var str_GMT54 = 'Rangoon';
var str_GMT55 = 'Bangkok, Hanoi, Jakarta';
var str_GMT56 = 'Krasnoyarsk';
var str_GMT57 = 'Pechino, Chongqing, Hong Kong, Urumqi';
var str_GMT58 = 'Irkutsk';
var str_GMT59 = 'Kuala Lumpur, Singapore';
var str_GMT60 = 'Perth';
var str_GMT61 = 'Taipei';
var str_GMT62 = 'Osaka, Sapporo, Tokyo';
var str_GMT63 = 'Seoul';
var str_GMT64 = 'Yakutsk';
var str_GMT65 = 'Adelaide';
var str_GMT66 = 'Brisbane';
var str_GMT67 = 'Canberra, Melbourne, Sydney';
var str_GMT68 = 'Guam, Port Moresby';
var str_GMT69 = 'Hobart';
var str_GMT70 = 'Vladivostok';
var str_GMT71 = 'Magadan';
var str_GMT72 = 'Auckland, Wellington';
var str_GMT73 = 'Fiji';
var str_GMT74 = 'Nuku_alofa';


// Query
var str_ask_sdfat32 = "La SD Card sarà formattata come fat32. Sei sicuro?";
var str_ask_sdstop = "La scheda SD verrà arrestata. Sei sicuro?";
var str_ask_recoverbak = "L'ipcam verrà ripristinata. Sei sicuro?";
var str_ask_syspath = "Per favore inserisci il percorso del file";
var str_ask_upgradesys = "L'ipcam verrà aggiornato. Sei sicuro?";
var str_ask_reboot = "L'ipcam verrà riavviato. Sei sicuro?";
var str_ask_recoverdef = "I dati di installazione verranno inizializzati. Sei sicuro?";


/// Display
var str_adjustneff = "(Regolazione effetto notturno)";
var str_nightmode = "Modello notturno";
var str_adjustnl = "Regolazione luminanza notturna";
var str_nlight = "Luminanza notturna";
var str_brightness = "Luminosità";
var str_saturation = "Saturazione";
var str_contrast = "Contrasto";
var str_sharpness = "Nitidezza";
var str_hue = "Chroma";
var str_shutter = "Otturatore";
var str_ldcratio = "Distorsione";
var str_ae = "Esposizione minima";
var str_targety = "Esposizione";
var str_gamma = "Gamma";
var str_dnt = "Sensibilità";
var str_lumi = "Luminanza";
var str_imageset = "Impostazioni immagine";
var str_updown = "Capovolgi";
var str_leftright = "Mirror";
var str_wdr = "WDR";
var str_onmode = "Modalità";
var str_mode = "Modalità";
var str_black = "Bianco e nero";
var str_color = "Colore";
var str_aemode = "Modalità di esposizione";
var str_auto = "Auto";
var str_indoor = "Indoor";
var str_outdoor = "All'aperto";
var str_imgmode = "Imgmode";
var str_framerate1 = "Frequenza dei fotogrammi";
var str_inance = "Illuminanza";
var str_ircut = "IRCut";
var str_ircutye = "(1-1024, maggiore è il valore, maggiore è il tempo di commutazione)";
var str_sensitivity = "Sensibilità";
var str_wdrmode = "WDR";
var str_wdrvalue = "Valore WDR";
var str_lightmode     = "Modalità della luce";
var str_changing      = "Cambiare";
var str_manual       = "Manuale";
var str_lightness    = "Leggerezza";
var str_window = "Finestra";
var str_safetype = "Modalità sicurezza";
var str_encway = "Algoritmo WPA";
var str_key = "Chiave";
var str_confirmkey = "Chiave di conferma";
var str_checkwl = "Verifica installazione senza fili";
var str_hwctrl = "Controllo LED IR";
var str_noise = "Noise";
var str_noisetye = "(0-100, Abbassare in base al lavoro)";
var str_lamp       = "Modalità visione notturna";
var str_lamp0       = "Normale";
var str_lamp1       = "A colori";
var str_lamp2       = "Intelligente";

// senza fili
var str_wlenable = "Attiva senza fili";
var str_conmode = "Modalità";
var str_route = "Infrastruttura";
var str_p2p = "Punto a punto";

var str_welcome = "Seleziona cosa vuoi fare:";
var str_pcview = "Visualizzazione PC";
var str_mbview = "Visualizzazione mobile";
var str_setupsoft = "Software di installazione (prima volta)";

var str_sd = "Scheda SD";
var str_snap = "Cattura";
var str_record = "Registrazione";
var str_playback = "Playback";
var str_up = "Su";
var str_down = "Giù";
var str_right = "Destra";
var str_left = "Sinistra";
var str_center = "Centro";
var str_ud = "Crociera su e giù";
var str_lr = "Crociera a sinistra e a destra";
var str_preset = "preimpostazione";
var str_zoomin = "Ingrandire";
var str_zoomout = "Rimpicciolire";
var str_focusin = "Fuoco +";
var str_focusout = "Fuoco -";
var str_posset = "Set";
var str_poscall = "Call";
var str_refresh = "Aggiorna";
// gb28181
var str_err_svrport = "L'intervallo di porta è compreso tra 1 e 65535.";
var str_gb28181 = "GB28181";
var str_gb_gb28181 = "GB28181";
var str_svrid = "ID server";
var str_svrip = "Indirizzo server";
var str_svrport = "Porta del server";
var str_devid = "ID dispositivo";
var str_devport = "Porta dispositivo";
var str_devpwd = "Password del dispositivo";
var str_alarmid = "ID allarme";
var str_heartcycle   ="KCiclo di battito cardiaco";
var str_heartcount   ="Tempo massimo del battito cardiaco";
var str_regtime      ="Validità di registrazione";

// Impostazioni multiple
var str_addport = 'Impostazioni multiple';
var str_addportset = 'Impostazioni multiple';
var str_local_host = "Nativo";
var str_refesh = "Aggiorna";
var str_local_network = "Ricerca Lan";
var str_first_dev = "Il primo dispositivo";
var str_second_dev = "Il secondo dispositivo";
var str_third_dev = "Il terzo dispositivo";
var str_fourth_dev = "Il quarto dispositivo";
var str_fifth_dev = "Il quinto dispositivo";
var str_sixth_dev = "Il sesto dispositivo";
var str_seventh_dev = "Il settimo dispositivo";
var str_eighth_dev = "L'ottavo dispositivo";
var str_ninth_dev = "Il nono dispositivo";
var str_add = "Aggiungi";
var str_remove = "Rimuovi";
var str_set = "Sottoponi";
var str_cancel = "Annulla";
var str_none = 'Nessuno';
var str_overlay_name = 'Nome telecamera:';
var str_ip_address = 'IP:';
var str_http_port = 'Porta:';
var str_user_name = 'Utente:';
var str_user_psw = 'Password:';
var str_anonymous = '';
var str_err_selected = "L'host non esiste, per favore scegli di nuovo!"
var str_err_hostnum = "Per favore scegli di operare sull'host!";

// Modalità wifi
var str_wifi_mode = 'Modalità wifi';
var str_wifimode = 'Modalità';
var str_wifi_speed = 'Velocità';
var str_wifi_channel = 'Canale';
var str_wifi_power = 'Potenza';
var str_wifimode0 = 'Modalità TX continua non modulata';
var str_wifimode1 = 'Modalità TX continua modulata';
var str_wifimode2 = 'Modalità RX continua';

//4G
var str_4gset ='Impostazioni 4G';
var str_4grunmode ='Modalità APN';
var str_4gauto ='automatico';
var str_4gmanual ='Manuale';
var str_4gapn ='APN';
var str_4gsimcard ='SIM card';
var str_4gversion ='Modulo versione';
var str_4gquality ='Qualità dei segnali';
var str_4gmcc ='Codice Paese';
var str_4gmnc ='Codice di rete';
var str_4gstatus ='Codice dello stato';
var str_4gauthtype ='Tipo di cifratura';
var str_4gcarrier ='Operatore';
var str_4gimei ='IMEI';
var str_4giccid ='ICCID';

// Riavvia il timer
var str_restarttime = "Riavvia il timer";
var str_oclock = "O'clock";

//Tmall Genie
var str_tmall="Tmall Genie";

//Amazon Echo
var str_amazon="Amazon Echo";