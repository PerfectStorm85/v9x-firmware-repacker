﻿// JavaScript Document
function load_form_address()
{
	var f = document.getElementById("form_address");
	
	f.value = address;          
}

function check_form_address()
{
	var f = document.getElementById("form_address");
	if(checkProhibitedCharacter2(f,f.value)==false)return false;
	if  ((f.value < 0 ) ||(f.value > 255))
	{
		alert(str_err_addrcode + comma + str_0_255);
		f.focus();
		return false;
	}
	
	return true;
}

function submit_form_address()
{
	var f = document.getElementById("form_address");
	var s = document.getElementById("form_submit");
	
	s.address.value = f.value;
	s.address.name  = "-address";
}

function load_form_protocal()
{
	var f = document.getElementById("form_protocal");
	
	f.options[protocal].selected=true; 
}

function submit_form_protocal()
{
	var f = document.getElementById("form_protocal");
	var s = document.getElementById("form_submit");
	
	s.protocal.value = f.value;
	s.protocal.name  = "-protocal";
}


function load_form_speed()
{
	var f = document.getElementById("form_speed");
	
	f.value = speed;          
}

function submit_form_speed()
{
	var f = document.getElementById("form_speed");
	var s = document.getElementById("form_submit");
	
	s.speed.value = f.value;
	s.speed.name  = "-speed";
}


function load_form_baud()
{
	var f = document.getElementById("form_baud");
	
	f.value = baud;
}

function submit_form_baud()
{
	var f = document.getElementById("form_baud");
	var s = document.getElementById("form_submit");
	
	s.baud.value = f.value;
	s.baud.name  = "-baud";
}

function load_form_databit()
{
	var f = document.getElementById("form_databit");
	
	f.value = databit;
}

function submit_form_databit()
{
	var f = document.getElementById("form_databit");
	var s = document.getElementById("form_submit");
	
	s.databit.value = f.value;
	s.databit.name  = "-databit";
}

function load_form_stopbit()
{
	var f = document.getElementById("form_stopbit");
	
	f.value = stopbit;
}

function submit_form_stopbit()
{
	var f = document.getElementById("form_stopbit");
	var s = document.getElementById("form_submit");
	
	s.stopbit.value = f.value;
	s.stopbit.name  = "-stopbit";
}

function load_form_check()
{
	var f = document.getElementById("form_check");
	
	f.value = check;
}

function submit_form_check()
{
	var f = document.getElementById("form_check");
	var s = document.getElementById("form_submit");
	
	s.check.value = f.value;
	s.check.name  = "-check";
}



