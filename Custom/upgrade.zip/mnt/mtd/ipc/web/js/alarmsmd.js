﻿function load_form_smdenable()
{
	var f0 = document.getElementById("form_smdenable0");
  var f1 = document.getElementById("form_smdenable1");
	
  if (smd_enable == "1")
  {
   		f0.checked = true;
  }
  else
	{
		f1.checked = true;
	}
}

function change_form_witch()
{
	var f = document.getElementById("form_smdenable0");
	
	if (f.checked == true)
	{
		document.getElementById('form_rectenable0').disabled=false;
		document.getElementById('form_rectenable1').disabled=false;
   	document.getElementById('smdthreshold').disabled=false;
   	document.getElementById('form_mdalarmtype').disabled=false;
  }
	else
	{
		document.getElementById('form_rectenable0').disabled=true;
		document.getElementById('form_rectenable1').disabled=true;
		document.getElementById('smdthreshold').disabled=true;
		document.getElementById('form_mdalarmtype').disabled=true;
	}
}

function submit_form_smdenable()
{
	var f = document.getElementById("form_smdenable0");
	var s = document.getElementById("form_submit");
	
	if (f.checked)
		s.smd_enable.value="1";
	else
		s.smd_enable.value="0";
	s.smd_enable.name = "-smd_enable";
}

function load_form_smdthreshold()
{
	var f = document.getElementById("form_smdthreshold");
	
	f.value = smd_gthresh;
}

function submit_form_smdthreshold()
{
	var f = document.getElementById("form_smdthreshold");
	var s = document.getElementById("form_submit");

  s.smd_threshold.value = f.value;
	s.smd_threshold.name = "-smd_gthresh";
}

function check_form_smdthreshold()
{
	var f = document.getElementById("form_smdthreshold");
	
	if ((f.value < 1) || (f.value > 1024))
	{
		alert(str_err_volume);
		f.select();
		return false;
	}

	return true;
}

function load_form_smdrect()
{
	var f0 = document.getElementById("form_rectenable0");
  var f1 = document.getElementById("form_rectenable1");
	
  if (smd_rect == "1")
  {
   		f0.checked = true;
  }
  else
	{
		f1.checked = true;
	}
}

function submit_form_smdrect()
{
	var f = document.getElementById("form_rectenable0");
	var s = document.getElementById("form_submit");
	
	if (f.checked)
		s.smd_rect.value="1";
	else
		s.smd_rect.value="0";
	s.smd_rect.name = "-smd_rect";
}

function load_form_md_type()
{
	var f = document.getElementById("form_mdalarmtype");
	
	if (md_alarm_type == "on")
	{
	   f.options[1].selected = true;
	}
	else
	{
		f.options[0].selected = true;
	}
}

function submit_form_md_type()
{
	var f = document.getElementById("form_mdalarmtype");
	var s  = document.getElementById("form_submit");
	
	s.ids1.value  = "type";
	
	if (f.selectedIndex == 1)
	{
		s.turn1.value = "on";
	}
	else
	{
		s.turn1.value = "off";
	}
	
}

