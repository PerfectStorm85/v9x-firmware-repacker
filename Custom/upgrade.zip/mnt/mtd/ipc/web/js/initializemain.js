﻿var initLength = 1;
var speed = 2;
var intval = 1000;
var maxLength = 1000;
var maxTimes = 0;
var maxMilliSeconds = 250000;
var intID;
var currentLength = initLength;
var currentTimes = 0;
var currentMilliSeconds = 0;
	
function addMore() 
{
	currentLength += speed;
	currentTimes ++;
	currentMilliSeconds += intval;
	
	if (maxLength > 0 && currentLength > maxLength)
		currentLength = initLength;
	document.getElementById("tb").width  = currentLength;
	if (maxTimes > 0 && currentTimes>= maxTimes )
		stopIt();
	if (maxMilliSeconds > 0 && currentMilliSeconds > maxMilliSeconds ) 
		stopIt();
}

function startIt() 
{		
	document.getElementById("upgrdwait").style.display = "block";
	document.getElementById("upgrdinfo").style.display = "block";
	document.getElementById("content").style.display = "none";
	 
	intID = window.setInterval(addMore, intval);
}

function stopIt() 
{
	window.clearInterval(intID);
	alert(str_note_upgradeok);
	window.location="http://"+window.location.host;
}


function do_reboot() 
{
	var s = document.getElementById("form_submit1");

    if (confirm(str_ask_reboot) == true) 
	{
        s.action= "cgi-bin/hi3510/param.cgi";
        s.submit();
    }
    else
	{
        return false;
    }
}

function do_reset()
{
	var s = document.getElementById("form_submit2");

    if (confirm(str_ask_recoverdef) == true)
	{
        s.action = "cgi-bin/hi3510/param.cgi";
        s.submit();
    }
    else 
	{
        return false;
    }
}

function do_savetofile() 
{
    parent.retframe.location.href = "cgi-bin/hi3510/backup.cgi";
}

function do_upload() 
{
	var f = document.getElementById("form_bakfile");

	if (f.value == "") 
	{
	    alert(str_note_inputpath);
	    return false;
	}
	if (confirm(str_ask_recoverbak) == true) 
	{
	    return true;
	}
	else 
	{
	    return false;
	}
}

function do_upgrade() 
{
	var f = document.getElementById("form_sysfile");
	var s = document.getElementById("form_upgrade");

	var filename;

	if (f.value == "") 
	{
	    alert(str_ask_syspath);
	    return false;
	}

	filename = f.value;
	filename = filename.substr(filename.lastIndexOf('\\') + 1);

	if (confirm(str_ask_upgradesys) == true) 
	{
	    s.action = "cgi-bin/hi3510/upgrade.cgi?-filename=" + filename;
	    setTimeout("startIt()", 500);
	    return true;
	}
	else 
	{
	    return false;
	}
}

function load_form_language()
{
	var f = document.getElementById("form_language");
	if (lancode == 0)
	{
		f.options[0].selected = true;
	}
	else if(lancode == 1)
	{
		f.options[1].selected = true;
	}
	else if(lancode == 2)
	{
		f.options[2].selected = true;
	}
	else if(lancode == 3)
	{
		f.options[3].selected = true;
	}
	else if(lancode == 4)
	{
		f.options[4].selected = true;
	}
	else if(lancode == 5)
	{
		f.options[5].selected = true;
	}
	else if(lancode == 6)
	{
		f.options[6].selected = true;
	}
	else if(lancode == 7)
	{
		f.options[7].selected = true;
	}
	else if(lancode == 8)
	{
		f.options[8].selected = true;
	}
	else if(lancode == 9)
	{
		f.options[9].selected = true;
	}
	 else
	{
		f.options[0].selected = true;
	}
}

function submit_form_language()
{
	var f = document.getElementById("form_language");
	var s = document.getElementById("form_submitlng");
	
	s.lancode.value = f.value;
	s.lancode.name  = "-lancode";
	
	s.cururl.value = document.URL;
	
	s.action = "cgi-bin/hi3510/param.cgi";
  s.submit();
}

function load_form_lenstype()
{
	var f = document.getElementById("form_lenstype");
	if (lenstype == 0)
	{
		f.options[0].selected = true;
	}	
	else if(lenstype == 1)
	{
		f.options[1].selected = true;
	}
	else if(lenstype == 2)
	{
		f.options[2].selected = true;
	}
	else if(lenstype == 3)
	{
		f.options[3].selected = true;
	}
	else if(lenstype == 4)
	{
		f.options[4].selected = true;
	}
	else if(lenstype == 6)
	{
		f.options[5].selected = true;
	}
	else if(lenstype == 7)
	{
		f.options[6].selected = true;
	}
	else if(lenstype == 8)
	{
		f.options[7].selected = true;
	}
	else if(lenstype == 9)
	{
		f.options[8].selected = true;
	}
	else if(lenstype == 10)
	{
		f.options[9].selected = true;
	}
	else if(lenstype == 11)
	{
		f.options[10].selected = true;
	}
	else if(lenstype == 12)
	{
		f.options[11].selected = true;
	}
	else
	{
		f.options[3].selected = true;
	}
}

function submit_form_lenstype()
{
  var f = document.getElementById("form_lenstype");
	var s = document.getElementById("form_submitlenstype");
	
	s.lenstype.value = f.value;
	s.lenstype.name  = "-lenstype";
	
  if(s.lenstype.value != lenstype)
  {
	alert(str_note_needreset);
  }
  
	s.cururl.value = document.URL;
	
	s.action = "cgi-bin/hi3510/param.cgi";
  s.submit();
}