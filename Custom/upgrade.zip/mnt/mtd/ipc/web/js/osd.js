﻿
function load_form_region0()
{
	//show
	var f1 = document.getElementById("form_region0_on");
	var f0 = document.getElementById("form_region0_off");
	
	//place
	var e0 = document.getElementById("form_region0_tl");
	var e1 = document.getElementById("form_region0_tr");
	var e2 = document.getElementById("form_region0_bl");
	var e3 = document.getElementById("form_region0_br");

	//show
	if(show_0 == 1)
	{
		f1.checked=true;
	}
	else
	{
		f0.checked=true;
	}
	
	//place
	if(place_0 == 0)
	{
		e0.checked=true;
	}
	else if(place_0 == 1)
	{
		e1.checked=true;
	}
	else if(place_0 == 2)
	{
		e2.checked=true;
	}
	else
	{
		e3.checked=true;
	}
}

function submit_form_region0()
{
	var s = document.getElementById("form_submit");
	var f = document.getElementById("form_region0_on");
	
	var e0 = document.getElementById("form_region0_tl");
	var e1 = document.getElementById("form_region0_tr");
	var e2 = document.getElementById("form_region0_bl");
	var e3 = document.getElementById("form_region0_br");
	
	//show
	if(f.checked == true)
	{
		s.show0.value=1;
	}
	else
	{
		s.show0.value=0;
	}
  
	//place
	if(e0.checked == true)
	{
		s.place0.value=0;
	}
	if(e1.checked == true)
	{
		s.place0.value=1;
	}
	if(e2.checked == true)
	{
		s.place0.value=2;
	}
	if(e3.checked == true)
	{
		s.place0.value=3;
	}

	s.region0.value = 0;
	s.region0.name  = "-region";
	s.show0.name    = "-show";
        s.place0.name   = "-place";
}

function load_form_region1()
{
	//show
	var f0 = document.getElementById("form_region1_off");
	var f1 = document.getElementById("form_region1_on");
	var fn = document.getElementById("form_region1_name");
	
	//place
	var e0 = document.getElementById("form_region1_tl");
	var e1 = document.getElementById("form_region1_tr");
	var e2 = document.getElementById("form_region1_bl");
	var e3 = document.getElementById("form_region1_br");
	
	//show
	if(show_1==1)
	{
		f1.checked=true;
	}
	else
	{
		f0.checked=true;
	}
	
	//place
	if(place_1 == 0)
	{
		e0.checked=true;
	}
	else if(place_1 == 1)
	{
		e1.checked=true;
	}
	else if(place_1 == 2)
	{
		e2.checked=true;
	}
	else
	{
		e3.checked=true;
	}
	
	fn.value = name_1;
}

function check_form_region1()
{
	var f = document.getElementById("form_region1_name");

	if (f.value == "")
	{
		alert(str_err_noname);
		f.select();
		return false;
	}

    
     if (checkProhibitedCharacter3(f,f.value) == false)
	{
		f.select();
		return false;
	}       

	/*var clen = checkLen(f.value);
	if (clen > 18)
	{
		alert(str_err_osdname);
		f.select();
		return false;
	}*/

	return true;
}

function submit_form_region1()
{
	var s = document.getElementById("form_submit");
	var f = document.getElementById("form_region1_on");
	var n = document.getElementById("form_region1_name");
	
	var e0 = document.getElementById("form_region1_tl");
	var e1 = document.getElementById("form_region1_tr");
	var e2 = document.getElementById("form_region1_bl");
	var e3 = document.getElementById("form_region1_br");
	
	//show
	if(f.checked == true)
	{
		s.show1.value = 1;
	}
	else
	{
		s.show1.value = 0;
	}
	
	//place
	if(e0.checked == true)
	{
		s.place1.value=0;
	}
	if(e1.checked == true)
	{
		s.place1.value=1;
	}
	if(e2.checked == true)
	{
		s.place1.value=2;
	}
	if(e3.checked == true)
	{
		s.place1.value=3;
	}
	
	s.region1.value = 1;
	s.name1.value = n.value;
	
	s.region1.name="-region";
	s.show1.name="-show";
	s.name1.name = "-name";
        s.place1.name = "-place";
}