// JavaScript Document
function load_form_runmode()
{
	var f = document.getElementById("form_runmode");
	
	if (g4_runmode == "1")
	{
		f.options[1].selected = true;
	}
  else
	{
		f.options[0].selected = true;
	}
}

function submit_form_runmode()
{
	var f = document.getElementById("form_runmode");
	var s = document.getElementById("form_submit");
	s.runmode.value = f.value;
}

function load_form_apn()
{
	var f = document.getElementById("form_apn");
	f.value = g4_apn;
}

function submit_form_apn()
{
	var f = document.getElementById("form_apn");
	var s = document.getElementById("form_submit");
  s.apn.value = f.value;	
}

function load_form_authtype()
{
	var fa = document.getElementById("form_authtype");
	fa.value = g4_authtype;
}

function submit_form_authtype()
{
	var f = document.getElementById("form_authtype");
	var s = document.getElementById("form_submit");
  s.authtype.value = f.value;
}

function load_form_username()
{
	var fu = document.getElementById("form_username");	
	fu.value = g4_username;
}

function submit_form_username()
{
	var f = document.getElementById("form_username");
	var s = document.getElementById("form_submit");
  s.username.value = f.value;
}

function load_form_password()
{
	var fp = document.getElementById("form_password");
	fp.value = g4_password;
}

function submit_form_password()
{
	var f = document.getElementById("form_password");
	var s = document.getElementById("form_submit");
  s.password.value = f.value;
}

function load_form_simcard()
{
	var f = document.getElementById("form_simcard");
		
	if(g4_simcard == 1)
		f.value = str_havesd;
	else
		f.value = str_nothavesd;
}

function load_form_version()
{
	var f = document.getElementById("form_version");
	f.value = g4_ver;
}

function load_form_quality()
{
	var f = document.getElementById("form_quality");
	f.value = g4_quality;
}

function load_form_mcc()
{
	var f = document.getElementById("form_mcc");
	f.value = g4_mcc;
}

function load_form_mnc()
{
	var f = document.getElementById("form_mnc");
	f.value = g4_mnc;
}

function load_form_carrier()
{
	var f = document.getElementById("form_carrier");
	f.value = g4_carrier;
}

function load_form_imei()
{
	var f = document.getElementById("form_imei");
	f.value = g4_imei;
}

function load_form_iccid()
{
	var f = document.getElementById("form_iccid");
	f.value = g4_iccid;
}

function load_form_status()
{
	var f = document.getElementById("form_status");
	f.value = g4_status;
}
