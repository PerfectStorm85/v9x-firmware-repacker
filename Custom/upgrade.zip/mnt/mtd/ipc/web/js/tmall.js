﻿function load_form_tmallenable()
{
	var f0 = document.getElementById("form_tmallenable0");
  var f1 = document.getElementById("form_tmallenable1");
	
  if (tmall_enable == "1")
  {
   		f0.checked = true;
  }
  else
	{
		f1.checked = true;
	}
}

function submit_form_tmallenable()
{
	var f = document.getElementById("form_tmallenable0");
	var s = document.getElementById("form_submit");
	
	if (f.checked)
		s.tmall_enable.value="1";
	else
		s.tmall_enable.value="0";
	s.tmall_enable.name = "-tmall_enable";
}
