// JavaScript Document
function load_form_mode()
{
	var f = document.getElementById("form_mode");
	
	f.options[wf_mode].selected=true; 
}



function submit_form_mode()
{
	var f = document.getElementById("form_mode");
	var s = document.getElementById("form_submit");
	
	s.wf_mode.value = f.selectedIndex;
		
	
}

function load_form_speed()
{
	var f = document.getElementById("form_speed");
	
	f.value = wf_speed;	
}


function submit_form_speed()
{
	var f = document.getElementById("form_speed");
	var s = document.getElementById("form_submit");

	s.wf_speed.value = f.value;	
	
}

function load_form_channel()
{
	var f = document.getElementById("form_channel");
	
	f.value = wf_chn;	
}



function submit_form_channel()
{
	var f = document.getElementById("form_channel");
	var s = document.getElementById("form_submit");

	s.wf_chn.value = f.value;	
	
}

function load_form_power()
{
	var f = document.getElementById("form_power");
	
	f.value = wf_power;	
}



function submit_form_power()
{
	var f = document.getElementById("form_power");
	var s = document.getElementById("form_submit");

	s.wf_power.value = f.value;	
	
}