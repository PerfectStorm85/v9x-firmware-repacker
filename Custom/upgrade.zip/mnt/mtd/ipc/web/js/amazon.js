﻿function load_form_amazonenable()
{
	var f0 = document.getElementById("form_amazonenable0");
  var f1 = document.getElementById("form_amazonenable1");
	
  if (amazon_enable == "1")
  {
   		f0.checked = true;
  }
  else
	{
		f1.checked = true;
	}
}

function submit_form_amazonenable()
{
	var f = document.getElementById("form_amazonenable0");
	var s = document.getElementById("form_submit");
	
	if (f.checked)
		s.amazon_enable.value="1";
	else
		s.amazon_enable.value="0";
	s.amazon_enable.name = "-amazon_enable";
}
