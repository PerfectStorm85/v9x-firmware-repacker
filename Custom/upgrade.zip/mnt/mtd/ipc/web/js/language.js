var user;
var pwd;

function getcookie(name)
{
    var strCookie=document.cookie;
    var arrCookie=strCookie.split('; ');
    for (var i=0;i<arrCookie.length;i++)
    {
		var arr=arrCookie[i].split('=');
        if (arr[0]==name)
			return unescape(arr[1]);
    }
    return '';
}
function setcookie(name,value,expirehours)
{
	var cookieString=name+'='+escape(value);
    if (expirehours>0)
    {
		var date=new Date();
        date.setTime(date.getTime()+expirehours*3600*1000);
        cookieString=cookieString+'; expires='+date.toGMTString();
	}
    document.cookie=cookieString;
}

if (lancode=='1')
    document.write('<script src="/web/english/language.js"><\/script>');
else if (lancode=='2')
    document.write('<script src="/web/francaise/language.js"><\/script>');
else if (lancode=='3')
    document.write('<script src="/web/deutsch/language.js"><\/script>');
else if (lancode=='4')
    document.write('<script src="/web/italiano/language.js"><\/script>');
else if (lancode=='5')
    document.write('<script src="/web/spanish/language.js"><\/script>');
else if (lancode=='6')
    document.write('<script src="/web/russian/language.js"><\/script>');
else if (lancode=='7')
    document.write('<script src="/web/japanese/language.js"><\/script>');
else if (lancode=='8')
    document.write('<script src="/web/korean/language.js"><\/script>');
else if (lancode=='9')
    document.write('<script src="/web/poland/language.js"><\/script>');
else
    document.write('<script src="/web/chinese/language.js"><\/script>');