// JavaScript Document
function load_form_enable()
{
	var f1 = document.getElementById("form_enable1");
	var f0 = document.getElementById("form_enable0");
	
	if (sr_enable == "1")
		f1.checked = true;
	else
		f0.checked = true;
}

function change_form_enable()
{
	var f = document.getElementById("form_enable1");
	var i;
	
	if(f.checked == true)
	{
		for (i = 0; i < 2; i++)
		{
       		document.getElementById('layer' + i).style.visibility = "visible";
   		}
	}
	else
	{
		for (i = 0; i < 2; i++)
		{
       		document.getElementById('layer' + i).style.visibility = "hidden";
   		}
	}
}

function submit_form_enable()
{
	var f = document.getElementById("form_enable1");
	var s = document.getElementById("form_submit");
	
	if (f.checked == true)
		s.enable.value = 1;
	else
		s.enable.value = 0;
}

function load_form_day()
{
        var f = document.getElementById("form_day");
	f.options[sr_day].selected = true;
}

function submit_form_day()
{
    var f = document.getElementById("form_day");
    var s = document.getElementById("form_submit");
    s.day.value = f.selectedIndex;
}

function load_form_restarttime()
{
        var f = document.getElementById("form_restarttime");
	f.options[sr_hour].selected = true;
}

function submit_form_restarttime()
{
    var f = document.getElementById("form_restarttime");
    var s = document.getElementById("form_submit");
    s.restarttime.value = f.selectedIndex;
}
