﻿function load_form_cloudenable()
{
	var f0 = document.getElementById("form_cloudenable0");
  var f1 = document.getElementById("form_cloudenable1");
	
  if (cloud_enable == "1")
  {
   		f0.checked = true;
  }
  else
	{
		f1.checked = true;
	}
}

function submit_form_cloudenable()
{
	var f = document.getElementById("form_cloudenable0");
	var s = document.getElementById("form_submit");
	
	if (f.checked)
		s.cloud_enable.value="1";
	else
		s.cloud_enable.value="0";
	s.cloud_enable.name = "-cloud_enable";
}
