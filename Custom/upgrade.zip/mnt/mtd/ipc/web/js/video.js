﻿//制式设置
function load_form_vinorm()
{
	var f = document.getElementById("form_vinorm");
	
	if(vinorm == "P")
	{
		f.options[0].selected = true;
	}
	else
	{
		f.options[1].selected = true;
	}
}

function submit_form_vinorm()
{
	var f = document.getElementById("form_vinorm");
	var s = document.getElementById("form_submit");
		
	switch (f.selectedIndex)
	{
		case 0:
			s.vinorm.value = "P";
			break;
		case 1:
			s.vinorm.value = "N"; 
			break;
		default:
			break;
	}

 	
	s.vinorm.name="-vinorm"; 
}

function load_form_profile()
{
	var f = document.getElementById("form_profile");
	
	if(profile == 0)
	{
		f.options[0].selected = true;
	}
	else if(profile == 1)
	{
		f.options[1].selected = true;
	}
	else if(profile == 2)
	{
		f.options[2].selected = true;
	}
	else
	{
		f.options[3].selected = true;
	}
}

function submit_form_profile()
{
	var f = document.getElementById("form_profile");
	var s = document.getElementById("form_submit");
	
	s.profile.value = f.selectedIndex;
	s.profile.name="-profile"; 
}

function change_form_size1max()
{
	 var f = document.getElementById("form_size1max");
	 
	 if(f.selectedIndex == 0)
	 {
		document.getElementById('size2min').style.display="none";
		document.getElementById('size2max').style.display="";
	 }
	 else
	 {
		document.getElementById('size2min').style.display="";
		document.getElementById('size2max').style.display="none";
	 }
}

//第一码流分辨率设置
function load_form_size1()
{
	var f1max = document.getElementById("form_size1max");
	var f1min = document.getElementById("form_size1min");
	
	if (height_1 == 1920)
	{
		f1max.options[0].selected = true;
		document.getElementById('size1min').style.display="none";
		document.getElementById('size2min').style.display="none";
	}
	else if(height_1 == 1440)
	{
		f1max.options[1].selected = true;
		document.getElementById('size1min').style.display="none";
		document.getElementById('size2max').style.display="none";
	}
	else if(height_1 == 1296)
	{
		f1min.options[0].selected = true;
		document.getElementById('size1max').style.display="none";
		document.getElementById('size2max').style.display="none";
	}
	else
	{
		f1min.options[1].selected = true;
		document.getElementById('size1max').style.display="none";
		document.getElementById('size2max').style.display="none";
	}
}

//第二码流分辨率设置
function load_form_size2()
{
	var f2max = document.getElementById("form_size2max");
	var f2min = document.getElementById("form_size2min");

	if (height_2 == 600 || height_2 == 576 || height_2 == 480 || height_2 == 448)
	{
		f2max.options[0].selected = true;
		f2min.options[0].selected = true;
	}
	else
	{
		f2max.options[1].selected = true;
		f2min.options[1].selected = true;
	}
}

//提交主次码流分辨率设置
function submit_form_videomode()
{
	var f1max = document.getElementById("form_size1max");
	var f1min = document.getElementById("form_size1min");
	var f2max = document.getElementById("form_size2max");
	var f2min = document.getElementById("form_size2min");
	var s  = document.getElementById("form_submit");
	
	var a=f1max.selectedIndex;
	var b=f1min.selectedIndex;
	var c=f2max.selectedIndex;
	var d=f2min.selectedIndex;
	var v = 0;
	
	if ((b==1)&&(d==0)){v=45;}
	else if((b==1)&&(d==1)){v=41;}
	else {v=41;}
	
	s.videomode.value = v;
	s.videomode.name  = "-videomode";
}

//第一码流码率
function load_form_bps1()
{
	var f = document.getElementById("form_bps1");
	
	f.value = bps_1;
}

function submit_form_bps1()
{
	var f = document.getElementById("form_bps1");
	var s = document.getElementById("form_submit");
	
	s.bps1.value = f.value;
	s.bps1.name  = "-bps";
}

//第二码流码率
function load_form_bps2()
{
	var f = document.getElementById("form_bps2");
	
	f.value = bps_2;
}

function submit_form_bps2()
{
	var f = document.getElementById("form_bps2");
	var s = document.getElementById("form_submit");
	
	s.bps2.value = f.value;
	s.bps2.name  = "-bps";
}

//第一码流帧率
function load_form_fps1()
{
	var f = document.getElementById("form_fps1");
	
	f.options[fps_1-1].selected = true;
}

//第二码流帧率
function load_form_fps2()
{
	var f = document.getElementById("form_fps2");
	
	f.options[fps_2-1].selected = true;
}

function submit_form_fps1()
{
	var f = document.getElementById("form_fps1");
	var s = document.getElementById("form_submit");
	
	s.fps1.value = f.selectedIndex + 1;
	s.fps1.name  = "-fps";
}

function submit_form_fps2()
{
	var f = document.getElementById("form_fps2");
	var s = document.getElementById("form_submit");
	
	s.fps2.value = f.selectedIndex + 1;
	s.fps2.name  = "-fps";
}

function change_form_fps1()
{
	var f1 = document.getElementById("form_fps1");
	var f2 = document.getElementById("form_gop1");
	
	if(f1.value <= 20){
		f2.value = f1.value * 8;
	}else{
		f2.value = 160;
	}
}

function change_form_fps2()
{
	var f1 = document.getElementById("form_fps2");
	var f2 = document.getElementById("form_gop2");

	if(f1.value <= 20){
		f2.value = f1.value * 8;
	}else{
		f2.value = 160;
	}
}

// 检测帧率与制式是否冲突
function check_form_fps1()
{
	var f1 = document.getElementById("form_fps1");
	var f2 = document.getElementById("form_vinorm");

	if ((f2.selectedIndex == 0) && (f1.value > 25))
	{
		alert(str_note_maxframerate);
		f1.focus();
		return false;
	}
	
	return true;
}

function check_form_fps2()
{
	var f1 = document.getElementById("form_fps2");
	var f2 = document.getElementById("form_vinorm");

	if ((f2.selectedIndex == 0) && (f1.value > 25))
	{
		alert(str_note_maxframerate);
		f1.focus();
		return false;
	}

	return true;
}

//主次码流主帧间隔
function load_form_gop1()
{
	var f = document.getElementById("form_gop1");
	
	f.value = gop_1;
}

function load_form_gop2()
{
	var f = document.getElementById("form_gop2");
	
	f.value = gop_2;
}

function submit_form_gop1()
{
	var f = document.getElementById("form_gop1");
	var s = document.getElementById("form_submit");

	s.gop1.value = f.value;
	s.gop1.name  = "-gop";
}

function submit_form_gop2()
{
	var f = document.getElementById("form_gop2");
	var s = document.getElementById("form_submit");

	s.gop2.value = f.value;
	s.gop2.name  = "-gop";
}

//码率范围检测
function check_form_bps1()
{
	var m = document.getElementById("form_bps1");
	
	if ((m.value<32) || (m.value > 6144))
	{
		alert(str_note_maxbps);
		return false;
	}

	return true;
}

function check_form_bps2()
{
	var f1 = document.getElementById("form_bps2");

	if ((f1.value<32) || (f1.value > 2048))
	{
		alert(str_note_maxbps2);
		f1.select();
		return false;
	}

	return true;
}

// 主帧间隔范围检测
function check_form_gop1()
{
	var f = document.getElementById("form_gop1");
	
	if ((f.value < 2) || (f.value > 300))
	{
		alert(str_err_framegap);
		f.select();
		return false;
	}

	return true;
}

function check_form_gop2()
{
	var f = document.getElementById("form_gop2");
	
	if ((f.value < 2) || (f.value > 300))
	{
		alert(str_err_framegap);
		f.select();
		return false;
	}  

	return true;
}

//视频编码控制 0 固定编码，可变编码
function load_form_brmode1()
{
	var f0 = document.getElementById("form_brmode1_0");
	var f1 = document.getElementById("form_brmode1_1");
	
	if(brmode_1 == 1)
	{
		f1.checked = true;
	}
	else
	{
		f0.checked = true;
	}
}

function load_form_brmode2()
{
	var f0 = document.getElementById("form_brmode2_0");
	var f1 = document.getElementById("form_brmode2_1");
	
	if(brmode_2 == 1)
	{
		f1.checked = true;
	}
	else
	{
		f0.checked = true;
	}	
}

function submit_form_brmode1()
{
	var f = document.getElementById("form_brmode1_0");
	var s = document.getElementById("form_submit");
	
	if(f.checked == true)
	{
		s.brmode1.value = "0";
	}
	else
	{
		s.brmode1.value = "1";
	}

	s.brmode1.name = "-brmode";
}

function submit_form_brmode2()
{
	var f = document.getElementById("form_brmode2_0");
	var s = document.getElementById("form_submit");
	
	if(f.checked == true)
	{
		s.brmode2.value = "0";
	}
	else
	{
		s.brmode2.value = "1";
	}
	
	s.brmode2.name = "-brmode";	
}

//主次码流视频编码质量
function load_form_imagegrade1()
{
	var f = document.getElementById("form_imagegrade1");
	
	f.options[imagegrade_1 - 1].selected=true;
}

function load_form_imagegrade2()
{
	var f = document.getElementById("form_imagegrade2");

	f.options[imagegrade_2 - 1].selected=true;	
}


function submit_form_imagegrade1()
{
	var f = document.getElementById("form_imagegrade1");
	var s = document.getElementById("form_submit");
	
	s.imagegrade1.value = f.selectedIndex + 1;
	s.imagegrade1.name  = "-imagegrade";
}

function submit_form_imagegrade2()
{
	var f = document.getElementById("form_imagegrade2");
	var s = document.getElementById("form_submit");
	
	s.imagegrade2.value = f.selectedIndex + 1;
	s.imagegrade2.name  = "-imagegrade";
}
