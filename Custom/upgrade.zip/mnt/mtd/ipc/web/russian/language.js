﻿// JavaScript Document
//punct
var colon    = ":";
var period   = ".";
var comma    = ",";
var blank    = "&nbsp;";
var exclamation = "!";

//deviceinfo
var str_devname    = "ID уст-ва";
var str_devtype    = "Тип устр-ва";
var str_netstat    = "Подключение к сети";
var str_connnum    = "Текущий клиент";
var str_softver    = "Версия ПО";
var str_webware    = "Версия WEB";
var str_rs485ver   = "PTZ Версия";
var str_macaddr    = "MAC адрес";
var str_ipaddr     = "IP адрес";
var str_submask    = "Маска подсети";
var str_gateway    = "Шлюз";
var str_1stdns     = "Первичный DNS";
var str_2nddns     = "Вторичный DNS";
var str_upnpstatus = "UPnP статус";
var str_facddnsstatus="DDNS статус производителя";
var str_th3ddnsstatus="DDNS статус третьей стороны";
var success           = "Успешно";
var unenable          = "Не активен";
var fail              = "Ошибка";
var str_sysstart   = "Время старта";
var str_sdstat     = "SD статус";
var str_connwireless = "WiFi";
var str_connwired    = "LAN";
var str_dnsset     = "Тип конфигурации DNS";
var str_manualdns  = "Ручной DNS";
var str_autodns    = "С DHCP сервера";
var str_httpport   = "HTTP номер порта";
var str_rtspport   = "RTSP порт";
var str_rtmpport   = "RTMP порт";
var str_rtspauth   = "RTSP проверка разреш.";
var str_cap_cvbs  = "CVBS настройка";
var str_cloud = "Настройка облачности";
var str_cloudstat = "Статус облака";
var str_notpurchased = "Не куплено";
var str_retention  = "срок хранения"
var str_exptime = "Время истечения";

//terminal
var str_addrcode   = "Адрес";
var str_protocol   = "Протокол"; 
var str_portset    = "COM настройка";
var str_485portset = 485 + str_portset;
var str_485set     = "485 Настройка";
var str_baudrate   = "Битрейт";
var str_databit    = "Бит";
var str_stopbit    = "Стоп бит";
var str_check      = "Тип провер.";
var str_none       = "Нет";
var str_oddcheck   = "Нечет.";
var str_evencheck  = "Четн.";
var str_tiltscope='(1-50)';
var str_tiltno='Повторы тура не могут быть пустыми!';
var tilttes="PTZ скор.";
var tiltnum="Круги тура";
var tiltmunmax="Диапазон повтора:1-50";
var tiltcenter="Проверка по центру";
var str_speed0="Быстро";
var str_speed1="Средне";
var str_speed2="Медленно";
var str_ptzalarm="Закрыть сигнал. движения PTZ";
var str_lenmodetip='Реж. отобр. индикатора';
var str_lenmode1='Включить';
var str_lenmode2='Выключить';
var str_smartrack="Умное слеж.";

//FTP 
var str_pasvmode   = "Пассив. реж.";
var str_ftppic_name="Имя снимка";
var str_time_name  ="Имя времени";
var str_fixed_name ="Фикс. имя";
var str_alampic_name ="Имя снимка трев.";
var str_timepic_name ="Имя снимка врем.";
var str_filename_set ="Имя файла";
var str_autocreatedir ="Авто. созд. каталога";

//server
var str_server     = "Адрес сервера";
var str_port       = "Порт сервера";
var str_username   = "Имя";
var str_password   = "Пароль";
var str_repassword = "Повторить пароль";
var str_auth       = "Аутентификация";
var str_ftp_path   = "Путь";
var str_ftp_test   ="Тест FTP настроек";
var str_email_test   ="Тест Email настроек";

//email 
var str_emailset   = "Email настройки";
var str_smtpserv   = "SMTP имя сервера:";
var str_sendto     = "Отправить";
var str_emailaddr  = "E-Mail адрес"
var str_sendaddr   = "Отправитель";
var str_subject    = "Тема";
var str_info       = "Сообщение";
var str_max127c    = "макс. длинна 127";
var str_safelink="Безопасная ссылка";
var str_massl0="Нет";
var str_massl1="SSL";
var str_massl2="TLS";
var str_massl3="STARTTLS";

//autosnap
var str_timeint    = "Интервал снимка";
var str_sendemail  = "Отправить E-mail";
var str_savepic    = "Сохранить изображение на SD-карте";
var str_ftpsnap    = "Сохранить изображение на FTP сервер";
var str_cloudsnap  = "Сохр. изобр. на облачный сервер";

//Record Setting
var str_recsetup   = "Настройки записи";
var str_recfile    = "Длинна записи";
var str_recplan    = "Расписание записи";
var str_allday     = "Запись все время";
var str_allclear   = "Не записывать";
var str_timearea   = "Указанное время записи";
var str_recswitch  = "Открывать запись";
var str_all_area   ='Выбрать все';
var str_no_area    ='Отчистить';
var str_recformat='Формат записи';

//alarmin
var str_offenon    = "Отк.";
var str_offenoff   = "Закр.";
var str_alarmex    = "Внеш. трев.";
var str_alarmimode = "Режим внеш. трев.";

//audio alarm
var str_alarmaudio ="Аудио тревога";
var str_audiorange ="Диап. громк.";

//smd
var str_alarmsmd ="Трев. челов.";
var str_smdrecognition ="Умное распозн. челов";
var str_smdthreshold ="Предел";
var str_smdrect ="Человеч. образ";

//audio
var str_audioset   = "Настр. аудио";
var str_collecta   = "Настр. аудио";
var str_auformat   = "Тип аудио";
var str_audioin    = "Режим ввода";
var str_volumein   =  "Вх. громк.";
var str_volumeout   = "Вых. громк.";
var str_inoption   = "Аудио вход";
var str_intype     = "Тип входа";
var str_aumicin    = "МИК";
var str_aulinein   = "Линен.";

//time
var str_timenow    = "Текущ. дата и время";
var str_timedev    = "Время идата устр.";
var str_change     = "Регулир.";
var str_manualset  = "Руч. настр.";
var str_date       = "Дата";
var str_time       = "Время";
var str_dateformat = "(гг-мм-дд)";
var str_timeformat = "(чч:мм:сс)";
var str_daterange  = "(1971-01-01 ~ 2036-12-31)";
var str_syncfrompc = "Синхр времени с ПК";
var str_syncfrompc1 = "Синхр времени с ПК";
var str_pctime     = "Время ПК";
var str_ntserver   = "Сетевой протокол времени";
var str_ntpserver  = "NTP сервер";
var str_synctime   = "Интервал";
var str_hour       = "часы";
var str_keeptmset  = "Сохр. ткущ. настр.";
var str_timezone   = "Часовой пояс";
var str_autotime   = "Автоматически настроить часы для изменения летнего времени";

//video
var str_videoset   = "Настройки видео";
var str_videomode  = "Частота";
var str_videocoding = "Кодирование";
var str_resolution = "Разрешение";
var str_streamrate = "Битрейт";
var str_framerate  = "Кол-во кадров";
var str_framegap   = "Интервал";
var str_vcodectrl  = "Тип битрейта";
var str_fixedcr    = "CBR";
var str_variablecr = "VBR";
var str_vcodequa   = "Кач-во. избр.";
var str_osdset     = "OSD";
var str_osdopt     = "Параметры OSD";
var str_osdtime    = "Отм. врем.";
var str_osdname    = "Имя камеры";
var str_name       = "Имя";
var str_maxchn     = "Круп. видеоканал кодир.";
var str_colour      = "Цвет";
var str_timeshow    ="Показ. врем.";
var str_nameshow    ="Показ. имени.";
var str_tl    ="Слева вверх";
var str_tr    ="Справа верх";
var str_bl    ="Внизу слева";
var str_br    ="Внизу справа";

//platform
var str_plcon      = "Активировать";
var str_puidnum    = "PUID";
var str_asp        = "Доступ к порту сервера";
var str_asa        = "Доступ к адресу сервера";
var str_fsp        = "Порт сервера пересылки";
var str_fsa        = "Адрес сервера пересылки";
var str_gpsi       = "Интервал отпр. информации GPS";
var str_msec       = "(миллисек.)";
var str_loginid    = "ID устр.";
var str_loginpass  = "Пароль";
var str_serverport = "Порт";
var str_serveraddr = "Сервер";
var str_timeout    = "Таймаут";
var str_constate   = "Состояние соединения";
var str_devnum     = "ID устр.";
var str_dvsn       = "Серийн. №";
var str_atransfer  = "Передача звука";
var str_alarmtrans = "Передача информации о тревоге";
var str_uid        = "UID";
var str_server1   = "Сервер1";
var str_server2   = "Сервер2";
var str_server3   = "Сервер3";
var str_server4   = "Сервер4";

//onvif
var str_onvifenable = "ONVIF";
var str_offcheck     ="Не проверять";
var str_timecheck    ="Настройки часового пояса";
var str_videocheck   ="Настр. избр.";
var str_allow        ="Разр.";
var str_prohibit     ="Запретить"; 
var str_onvifchn     ="Способ обращения подкода";
var str_onvifsnap     ="Захват канала";
var str_onvifnvctype ="NVC тип";
var str_normal ="Норм.";
var str_uniview ="Универс.";

//alarm
var str_emailalarm = "Отпр. снимок тревоги на E-mail";
var str_sendpic    = "Отправить с изображением";
var str_saverecftp = "Сохр. видео на FTP сервер";
var str_relayout   = "Реле выход";
var str_savevideo  = "Сохранить видео на SD-карте";
var str_cloudrecord  = "Сохр.видео на облачном сервере";
var str_ftpservset = "Настройки FTP сервера";
var str_alarmplan  = "Время тревоги";
var str_alarmday   = "Постоян трев.";
var str_alarmclear = "Нет трев.";
var str_alermarea  = "Указ. время трев.";
var str_mdalarm_type    ="Трев.триггер";
var str_mdalarm_single    ="Особый триггер";
var str_mdalarm_union    ="Триггер связи";
var str_linkset    ="Настр. привяз.";
var str_snapset    ="Захват изображения";
var str_snapnum    ="Номер захвата изображения";
var str_alarmpreset ="Преднастр. соед.";
var str_alarmsound   = "Звук соед.";
var str_alarmbell   = "Тревога";
var str_alarmdog   = "Слежение";
var str_alarmcustom   = "Обычный";

//network
var str_manualip   = "Фиксированный IP";
var str_autoip     = "Динамический IP";
var str_lnset      = "Настройки LAN";
var str_ipget      = "Тип конфигурации IP";
var str_internetip = "Интернет IP-адрес";
var str_netip      = "Интернет IP-адрес";
var str_proddnsset = "Главный DDNS ";
var str_hostname   = "Ваш домен";
var str_3thdnsset  = "3тий DDNS";
var str_servprov   = "Провайдер";
var str_autoupnp   = "UPnP перенаправ. порта";
var str_wlcheck    = "Проверить Wi-Fi настр.";
var str_wlsuccess  = "Успешно подключено к WiFi.";
var str_applywl    = "Выбрать &quot;Применить&quot; для сохр. настр.";
var str_wlfailed   = "Не удалось подкл. к Wi-Fi";

//schdule
var str_weekmode     = "Исп. реж. недели";
var str_weekendmode  = "Исп. реж. работы";
var str_alltimemode  = "Все время";
var str_week         = "день";
var str_begintime    = "старт";
var str_endtime      = "конец";
var str_workday      = "рабочий день";
var str_freeday      = "выходной";
var str_everyday     = "каждый день";
var str_sunday       = "ВС";
var str_monday       = "ПН";
var str_tuesday      = "ВТ";
var str_wednesday    = "СР";
var str_thursday     = "ЧТ";
var str_friday       = "ПТ";
var str_saturday     = "СБ";

//Navigation
var str_rtview   = "Просмотр";
var str_config   = "Настройки";
var str_avargs   = "Медиа";
var str_videoa   = "Видео";
var str_imagea   = "Изобр.";
var str_audioa   = "Аудио";
var str_netset   = "Сеть";
var str_wlset    = "Wi-Fi";
var str_ddnsset  = "DDNS";
var str_plset    = "Платформ.";
var str_onvif    = "ONVIF";
var str_p2pset   = "P2P";
var str_alarmset = "Тревога";
var str_alarmin  = "Внешн. тревога";
var str_mdset    = "Детек. движ.";
var str_alaction = "Тревога";
var str_altime   = "Расписание";
var str_advset   = "Продвинутые";
var str_userset  = "Пользователь";
var str_timesnap = "Авто снап";
var str_timerec  = "Таймер записи";
var str_email    = "Email";
var str_ftpset   = "FTP";
var str_ptzset   = "Терминал";
var str_sysset   = "Система";
var str_timeset  = "Время";
var str_initset  = "Инициализация";
var str_devinfo  = "Информ. уст-ва.";
var str_systemlog = "Системный журнал";
var str_videoshade ="Маска";

//sd op
var str_sdview   = "Просмотр SD-карты";
var str_sdfat32  = "Формат. SD карты в fat32";
var str_sdstop   = "Откл. SD-карту";

//sd stat
var str_havesd     = "Карта";
var str_nothavesd  = "Нет карты";
var str_freespace  = "свободно"
var str_totalspace = "общее" 

//system bak up
var str_reboot     = "Перезаг.";
var str_recoverdef = "Заводские наст.";
var str_backup     = "Резерв. коп. данных";
var str_recoverbak = "Воостанов.";
var str_upgradesys = "Обновить";
var str_lenstype ="Тип объектива";

//button
var str_btn_reboot     = "&nbsp;Перезагр.&nbsp;";
var str_btn_save       = "&nbsp;Сохр.&nbsp;";
var str_btn_confirm    = "&nbsp;ОК&nbsp;";
var str_btn_query      = "&nbsp;показ.&nbsp;";
var str_btn_advanced   = "&nbsp;Продвинут.&nbsp;";
var str_btn_recoverdef = "Заводск.";
var str_btn_apply      = "&nbsp;Применить&nbsp;";
var str_btn_cancel     = "Отмена";
var str_btn_clear      = "&nbsp;Отчистить&nbsp;";
var str_btn_default    = "По умолчанию";
var str_btn_search     = "&nbsp;Поиск&nbsp;";
var str_btn_check      = "&nbsp;Провер.&nbsp;";
var str_btn_close      = "&nbsp;Закрыть&nbsp;";
var str_btn_refresh    = "&nbsp;Обновить&nbsp;";
var str_btn_test       = "Тест";
var str_btn_cleanlog   = "Отчистить";

//prompt
var str_note_upgrade       = "&nbsp;IP-камера обновляется, пожалуйста, не выключайте камеру.";
var str_note_upgradeok     = "IP камера обновлена!";
var str_note_needreset     = "Примечание: измените настройки, система автоматически перезагрузится";
var str_note_needreset0    = "(Примечание: измените настройки, система автоматически перезагрузится)";
var str_note_needreset1    = "Примечание: измените настройки, перезагрузите устройство";
var str_note_needreset2    = "(Примечание: измените настройки, перезагрузите устройство)";
var str_note_astreamnote   = "(мобильный)";
var str_note_wlsetting     = "Проверка WiFi, пожалуйста, подождите около 30 секунд.";
var str_note_inputpath     = "Пожалуйста, укажите путь к файлу";
var str_note_inputipaddr   = "Пожалуйста, введите IP-адрес";
var str_note_inputsubmask  = "Пожалуйста, введите адрес маски подсети";
var str_note_inputgateway  = "Пожалуйста, укажите шлюз";
var str_note_inputhostname = "Пожалуйста, введите домен";
var str_note_inputusername = "Пожалуйста, введите имя пользователя";
var str_note_inputpassword = "пожалуйста, введите пароль";
var str_note_inputport     = "Пожалуйста, введите порт сервера";
var str_note_inputpath     = "Пожалуйста, введите корневой путь ./";
var str_note_testtitle     = "Пожалуйста, сначала установите, а затем проверьте.";
var str_note_inputservaddr = "Пожалуйста, введите адрес сервера";
var str_note_inputservname = "Пожалуйста, введите имя сервера";
var str_note_inputemail    = "Пожалуйста, введите адрес";
var str_note_inputsendaddr = "Пожалуйста, введите адрес от";
var str_note_inputasp      = "Пожалуйста, введите порт сервера";
var str_note_inputasa      = "Пожалуйста, введите адрес доступа";
var str_note_inputfsp      = "Пожалуйста, введите порт сервера пересылки";
var str_note_inputfsa      = "Пожалуйста, введите адрес отправителя";
var str_note_inputtimeout  = "Пожалуйста, введите значение тайм-аута";
var str_note_inputgpsi     = "Пожалуйста, введите интервал отправки по GPS";
var str_note_noinpublicip  = "Интернет-адрес IP: NULL";
var str_note_internetipis  = "Интернет-адрес IP:";
var str_note_vcodequa      = "(Меньше значение, тем лучше качество изображения)";
var str_note_mbsize        = "Разр. мобильного избр.";
var str_note_mdoff         = "Примеч.: обнаружение движ. будет откл., когда первый поток будет 320х176";
var str_note_maxframerate  = "Частота кадров более 25.";
var str_note_maxbps        = "Диапазон битрейта 32-6144.";
var str_note_maxbps1        = "Диапазон битрейта 32-8192.";
var str_note_maxbps2        = "Диапазон битрейта 32-2048.";
var str_note_maxbps3        = "Диапазон битрейта 32-512.";
var str_note_maxbps4        = "Диапазон битрейта 32-256.";
var str_note_atransfer     = "(Перед открытием передачи аудио, на странице настроек аудио и видео, установите второй аудиопоток включения, формат AMR)";
var str_note_ipportchange  = "IP или порт был изменен, пожалуйста, переподкл.";
var str_note_rhportsame    = "http и rtsp используют один и тот же порт";
var str_note_inputdate     = "Пожалуйста, введите дату";
var str_note_inputtime     = "Пожалуйста, введите время";
var str_note_routemode     = "(Выберите режим инфрастр. при использ. беспровод. маршрутизатора.)";
var str_note_inputascii    = "Пожалуйста, введите ASCII (длина  5 или 13)";
var str_note_inputascii2   = "Пожалуйста, введите ASCII (длина от 8 до 63)";
var str_note_inputhex      = "Пожалуйста, введите HEX (длина 10 или 26 )";
var str_note_inputssid     = "Пожалуйста, введите SSID";
var str_note_inputkey      = "Пожалуйста, введите ключ";
var str_note_inputrekey    = "Пожалуйста, введите ключ повторно";
var str_note_nosupportp2p  = "WPA / WPA2 не поддерживается в режиме «точка-точка».";
var str_note_turnoffmd     = "Разр. видео 320х176, обнаруж. движ. откл.";
var str_note_autoreboot    = "Устр. будет перезагружено!";
var str_test_success       = "Тест ...... успешно.";
var str_test_fail          = "Тест......ошибка.";
var str_note_mdalarmtype   = "(Аварийн. сигнал. триггера требует вкл. обнаружения движения и челов. трев.)";



//err
var str_err_invaildc   = "Введен недопустимый символ";
var str_err_invaildc2  = "Введен недопустимый символ.(&,=,\",\\\)";
var str_err_username   = "Ошибка имени пользователя";
var str_err_hostname   = "Ошибка имени хоста";
var str_err_servname   = "Ошибка имени сервера";
var str_err_password   = "Ошибка пароля";
var str_err_port       = "Ошибка порта";
var str_err_userinfo   = "Ошибка информации о пользователе, пожалуйста, введите снова";
var str_err_servbusy   = "Сервер занят, пожалуйста, подождите немного";
var str_err_addrcode   = "Адрес вне диапазона";
var str_err_port       = "Ошибка порта"
var str_err_servaddr   = "Ошибка адреса";
var str_err_smptserv   = "Ошибка порта";
var str_err_emailaddr  = "Ошибка адреса";
var str_err_tooshort   = "Длина адреса должна быть больше 5";
var str_err_noat       = "Адрес должен содержать символ «@»";
var str_err_addr1      = "Ошибка адреса";
var str_err_addr2      = "";
var str_err_addr3      = "";
var str_err_sendaddr   = "Ошибка с адреса";
var str_err_subject    = "Ошибка темы";
var str_err_info       = "Ошибка сообщения";
var str_err_snapint    = "Интервал должен быть 5-86400.";
var str_err_recfile    = "Диапазон времени 15-900 секунд";
var str_err_recfile1    = "Диапазон времени 15-600 секунд";
var str_err_pwdconfirm = "Введите пароль еще раз.";
var str_err_framegap   = "Ключевые кадры 2-300";
var str_err_osdname    = "Количество слов больше 18.";
var str_err_gopframe   = "частота кадров ключа меньше";
var str_err_noname     = "Пожалуйста, введите название камеры";
var str_err_noblank    = "В имени не могут быть все пробелы";
var str_err_puid       = "Ошибка ввода PUID";
var str_err_asp        = "Access server port error";
var str_err_asa        = "Access address error";
var str_err_fsp        = "Ошибка порта сервера пересылки";
var str_err_fsa        = "Ошибка адреса пересылки";
var str_err_username   = "Ошибка имени пользователя";
var str_err_timeout    = "Ошибка ввода тайм-аута";
var str_err_tooutrange = "Тайм-аут вне диапазона";
var str_err_devnum     = "Ошибка ID устройства";
var str_err_servaddr   = "Ошибка адреса сервера";
var str_err_input      = " Ошибка ввода \ n \ n";
var str_err_addrrange1 = "Неверный адрес, первый номер";
var str_err_addrrange2 = "Неверный адрес, второй номер";
var str_err_addrrange3 = "Неверный адрес, третий номер";
var str_err_addrlast   = "Неверный адрес, последний номер"
var str_err_addr       = "Неверный адрес";
var str_err_value      = "Неверное значение";
var str_err_pctime     = "Время вашего ПК недействительно, время должно быть между 1970-01-01 и 2037-12-31";
var str_err_dateformat = "Неверный формат даты";
var str_err_dfinput    = "Формат должен быть гггг-мм-дд";
var str_err_reinputd   = "дата неверна, пожалуйста, введите заново";
var str_err_invaildtmf = "Неверный формат даты";
var str_err_timeformat = "формат должен быть чч: мм: сс";
var str_err_imvaildtm  = "неверный формат времени";
var str_err_key        = "длина ключа wep - ошибка. Hex - 10 или 26; ASCII 5 или 13";
var str_err_ssid       = "ssid - ошибка, включены недопустимые символы";
var str_err_rekey      = "Ошибка при повторном вводе ключа";
var str_err_ssid       = "ssid - ошибка, включены недопустимые символы";
var str_err_ip2gateway = "IP и шлюз не в одном сегменте сети";
var str_err_volume     = "Громкость вне диапазона (1-100), пожалуйста, сбросьте";
var str_err_username   ="Имя пользователя не может быть таким же"; 
var str_err_nameerr    ="Имя пользователя может содержать только буквы и цифры";
var str_err_nousername     = "пожалуйста, введите имя пользователя";
var str_error_none         ="Неизвестная ошибка";
var str_error_server       ="Не удается подключиться к серверу";
var str_error_namepwd      ="Неверный пользователь или пароль";
var str_error_dir          ="Ошибка пути";
var str_error_ssl          ="Ошибка настройки SSL";


var str_bps32_2048 = "Битрейт первого потока 32-2048 кбит/с";
var str_bps32_512  = "Битрейт первого потока 32-512 кбит/с";
var str_bps32_256  = "Битрейт первого потока 32-256 кбит/с";

//range
var str_1_65535 = "1-65535";
var str_1_223_127 =" должно быть от 1 до 223, а не 127";
var str_0_255   = " должно быть от 0 до 255";
var str_1_255   = " должно быть от 1 до 255";
var str_0_254   = " должно быть от 0 до 254";
var str_1_254   = " должно быть от 1 до 254"
var str_80or1024_49151 = "(80 или 1024~49151)";
var str_554or1024_49151 = "(554 или 1024~49151)";
var str_1935or1024_49151 = "(1935 или 1024~49151)";
var str_daterange  = "дата должна быть между 1971-01-01 и 2036-12-31, пожалуйста, введите заново";
var str_drange  = "(1971-01-01 ~ 2036-12-31)";

//no ins
var str_noins0 = "Появление этой страницы показывает:";
var str_noins1 = "1. Вы не установили элемент управления ActiveX.";
var str_noins2 = "2. Вы установили, но это обновленная версия элемента управления ActiveX, которую необходимо загрузить.";
var str_noins3 = "3. Вы должны подключиться к Интернету.";
var str_noins4 = "Пожалуйста нажмите";
var str_noins5 = "Скачать ActivX";
var str_noins6 = "и нажать";
var str_noins7 = "запуск";
var str_noins8 = "Установите расширение ActiveX, после обновите страницу чтобы просмотреть видео";

//in common use
var str_readonly  = "только для чтения";
var str_rate      = "темп";
var str_auto      = "авто";
var str_view      = "просмотр";
var str_minute    = "минуты";
var str_stream    = "Поток";
var str_1ststream = "Первый поток";
var str_2ndstream = "Второй поток";
var str_3thstream = "Третий поток";
var str_on        = "Вкл.";
var str_off       = "Выкл.";
var str_online    = "Онлайн";
var str_offline   = "Офлайн";
var str_sec       = "сек."
var str_language_ex  = "Язык";
var str_ch_ex        = "Chinese";
var str_en_ex        = "English";
var str_fr_ex        = "Français";
var str_de_ex        = "Deutsch";
var str_it_ex        = "Italiano";
var str_sp_ex        = "Español";
var str_ru_ex        = "русский язык";
var str_ja_ex        = "日本語";
var str_kr_ex        = "Korean";
var str_pl_ex        = "Polska";
var str_language  = "Язык";
var str_chinese   = "Chinese";
var str_english   = "English";
var str_francaise = "French";
var str_deutsch   = "Germany";
var str_italiano  = "Italian";
var str_spanish   = "Spanish";
var str_russian   = "русский язык";
var str_japan    = "日本語";
var str_korean   = "Korean";
var str_poland    = "Polska";
var str_add       = "Действие";
var str_encrypt   = "Шифровать";
var str_authen    = "Аут.";
var str_connetm   = "Тип сети";
var str_channel   = "Канал";
var str_confirm   = "Присоед."; 
var str_purview   ="Область"; 


//time zone
var str_GMT1  = 'International Date Line West';
var str_GMT2  = 'Samoa';
var str_GMT3  = 'Hawaii';
var str_GMT4  = 'Alaska';
var str_GMT5  = 'Pacific Time (U.S. and Canada)';
var str_GMT6  = 'Chihuahua,';
var str_GMT7  = 'Mountain Time (U.S. and Canada)';
var str_GMT8  = 'Arizona';
var str_GMT9  = 'Saskatchewan';
var str_GMT10 = 'Guadalajars,Mexico City,Monterrey';
var str_GMT11 = 'Central Time (U.S. and Canada)';
var str_GMT12 = 'Central America';
var str_GMT13 = 'Indians (East)';
var str_GMT14 = 'Eastern Time (U.S. and Canada)';
var str_GMT15 = 'Bogota,Lima,Quita';
var str_GMT16 = 'Carcacas';
var str_GMT17 = 'Santiago';
var str_GMT18 = 'Atlantic Time (Canada)';
var str_GMT19 = 'Newfoundland';
var str_GMT20 = 'Montevideo';
var str_GMT21 = 'Buenos Aires';
var str_GMT22 = 'Brasilia';
var str_GMT23 = 'Mid-Atlantic';
var str_GMT24 = 'Cape Verde Islands';
var str_GMT25 = 'Azores';
var str_GMT26 = 'Dublin,Edinburgh,Lisbon,London';
var str_GMT27 = 'Casablance';
var str_GMT28 = 'Amsterdam,Berlin,Bern,Rome,Stockholm,Vienna';
var str_GMT29 = 'Белгород,Bratislava,Budapest,Ljubljana,Prague';
var str_GMT30 = 'Brussels,Copenhagen,Madrid,Paris';
var str_GMT31 = 'Sarajevo,Skopje,Warsaw,Zagreb';
var str_GMT32 = 'West Central Africa';
var str_GMT33 = 'Athens,Bucharest,Istanbul';
var str_GMT34 = 'Bucharest';
var str_GMT35 = 'Cairo';
var str_GMT36 = 'Harare,Pretoria';
var str_GMT37 = 'Helsinki,Киев,Рига,Sofia,Vilnius,Talinn';
var str_GMT38 = 'Jerusalem';
var str_GMT39 = 'Baghdad';
var str_GMT40 = 'Kuwait,Riyadh';
var str_GMT41 = 'Москва,Санкт-Петербург,Волгоград';
var str_GMT42 = 'Nairobi';
var str_GMT43 = 'Tehran';
var str_GMT44 = 'Abu_Dhabi,Muscat';
var str_GMT45 = 'Baku';
var str_GMT46 = 'Kabul';
var str_GMT47 = 'Екатеринбург';
var str_GMT48 = 'Islamabad,Карачи';
var str_GMT49 = 'Chennai,Kolkata,Mumbai,New Delhi';
var str_GMT50 = 'Katmandu';
var str_GMT51 = 'Новосибирск';
var str_GMT52 = 'Dhaka';
var str_GMT53 = 'Нурсултан';
var str_GMT54 = 'Rangoon';
var str_GMT55 = 'Bangkok,Hanoi,Jakarta';
var str_GMT56 = 'Красноярск';
var str_GMT57 = 'Beijing,Chongqing,Hong Kong,Urumqi';
var str_GMT58 = 'Иркутск';
var str_GMT59 = 'Kuala Lumpur,Singapore';
var str_GMT60 = 'Perth';
var str_GMT61 = 'Taipei';
var str_GMT62 = 'Osaka,Sapporo,Tokyo';
var str_GMT63 = 'Seoul';
var str_GMT64 = 'Якутск';
var str_GMT65 = 'Adelaide';
var str_GMT66 = 'Brisbane';
var str_GMT67 = 'Canberra,Melbourne,Sydney';
var str_GMT68 = 'Guam,Port Moresby';
var str_GMT69 = 'Hobart';
var str_GMT70 = 'Владивосток';
var str_GMT71 = 'Магадан';
var str_GMT72 = 'Auckland,Wellington';
var str_GMT73 = 'Fiji';
var str_GMT74 = 'Nuku_alofa';


//query
var str_ask_sdfat32    = "SD-карта будет отформатирована как fat32. Вы уверены?";
var str_ask_sdstop     = "SD-карта будет остановлена. Вы уверены?";
var str_ask_recoverbak = "IP-камера будет восстановлена. Вы уверены?";
var str_ask_syspath    = "пожалуйста, введите путь к файлу";
var str_ask_upgradesys = "IP-камера будет обновлена. Вы уверены?";
var str_ask_reboot     = "IP-камера будет перезагружена. Вы уверены?";
var str_ask_recoverdef = "Данные настройки будут инициализированы. Вы уверены?";


/// display
var str_adjustneff  = "(Настр. ночной эффект)";
var str_nightmode   = "Ночная модель";
var str_adjustnl    = "Ночная регулировка освещенности";
var str_nlight      = "Ночная освещенность";
var str_brightness  = "Яркость";
var str_saturation  = "Насыщенность";
var str_contrast    = "Контраст";
var str_sharpness   = "Резкость";
var str_hue         = "Оттенок";
var str_shutter     = "Затвор";
var str_ldcratio    = "Искажение";
var str_ae          = "AE";
var str_targety     = "Экспозиция";
var str_gamma       = "Гамма";
var str_dnt         = "Чувствительность";
var str_lumi        = "Освещенность";
var str_imageset    = "Настройки изображения";
var str_updown      = "Переворот";
var str_leftright   = "Зеркало";
var str_wdr     = "WDR";
var str_onmode      ="Режим";
var str_mode        ="Режим";
var str_black       ="Черный и Белый";
var str_color       ="Цвет";
var str_aemode      ="Ae режим";
var str_auto        ="Авто";
var str_indoor      ="В помещении";
var str_outdoor     ="На улице";
var str_lightprior  = "AE";
var str_highlight   ="Яркое освещение";
var str_lowlight    ="Слабое освещение";
var str_imgmode     ="Реж.избр.";
var str_framerate1   ="FPS";
var str_inance      ="Освещенность";
var str_ircut       ="ИК-фильтр";
var str_ircutye     ="(1-1024, чем больше, тем дольше время перекл.)";
var str_sensitivity = "Чувствительность";
var str_wdrmode     = "WDR";
var str_wdrvalue    = "WDR Значение";
var str_lightmode     = "световой режим";
var str_changing      = "свет";
var str_manual       = "руководство";
var str_lightness    = "лёгкий";
var str_window      = "Окно";
var str_safetype    = "Режим чувствительности";
var str_encway      = "WPA Алгоритм"; 
var str_key         = "Ключ";
var str_confirmkey  = "Повторный ввод ключа";
var str_checkwl     = "Проверка настроек беспр. сети";
var str_hwctrl      = "ИК LED Контроль";
var str_noise       = "Шум";
var str_noisetye   = "(0-100, ниже по работе)";
var str_lamp       = "Режим ночного видения";
var str_lamp0       = "Норм.";
var str_lamp1       = "Все цвета";
var str_lamp2       = "Умный";
var str_display_mode = "Реж.дисплея";
var str_linemode = "Линейн.модель";

// wireless
var str_wlenable    = "Вкл. Wi-Fi";
var str_conmode     = "Режим";
var str_route       = "Инфраструктура";
var str_p2p         = "Точка-Точка";

var str_welcome     = "Выберите, действие:";
var str_pcview      = "ПК обзор";
var str_mbview      = "Мобильный обзор";
var str_setupsoft   = "Установка ПО (первый раз)";

var str_sd          ="SD карта";
var str_snap        ="Снимок";
var str_record      ="Запись";
var str_playback    ="Воспр.";
var str_up          ="Вверх";
var str_down        ="Вниз";
var str_right       ="Вправо";
var str_left        ="Влево";
var str_center      ="Центр";
var str_ud          ="Тур по вертикали";
var str_lr          ="Тур по горизонтали";
var str_preset       ="Предустановка";
var str_zoomin      ="Зум +";
var str_zoomout     ="Зум -";
var str_focusin      ="Фокус+";
var str_focusout     ="Фокус-";
var str_posset         ="Задать";
var str_poscall        ="Вызов";
var str_refresh     ="Обновить";
//gb28181
var str_err_svrport    ="Диапазон портов сервера от 1 до 65535.";
var str_gb28181      ="GB28181";
var str_gb_gb28181   ="GB28181";
var str_svrid        ="Сервер ID";
var str_svrip        ="Сервер адрес";
var str_svrport      ="Сервер порт";
var str_devid        ="ID устройства";
var str_devport      ="Порт уст-ва";
var str_devpwd       ="Пароль уст-ва";
var str_alarmid      ="ID тревоги";
var str_heartcycle   ="Kreislauf des Herzschlags";
var str_heartcount   ="Максимальное количество перерывов сердцебиения";
var str_regtime      ="срок действия регистрации";

//Multiple settings
var str_addport ='Добав.устр-в';
var str_addportset ='Добав. устр-в';
var str_local_host = "Хост";
var str_refesh = "Обновить";
var str_local_network = "Поиск LAN";
var str_first_dev = "Устройство 1";
var str_second_dev = "Устройство 2";
var str_third_dev = "Устройство 3";
var str_fourth_dev = "Устройство 4";
var str_fifth_dev = "Устройство 5";
var str_sixth_dev = "Устройство 6";
var str_seventh_dev = "Устройство 7";
var str_eighth_dev = "Устройство 8";
var str_ninth_dev = "Устройство 9";
var str_add = "Добав.";
var str_remove = "Удалить";
var str_set = "Отправить";
var str_cancel= "Отмена";
var str_none = 'Отсутствует';
var str_overlay_name='Имя камеры:';
var str_ip_address='IP:';
var str_http_port='Порт:';
var str_user_name='Пользователь:';
var str_user_psw='Пароль:';
var str_anonymous = '';
var str_err_selected ="Хост не существует, пожалуйста, выберите снова!" 
var str_err_hostnum  ="Пожалуйста, выберите операцию на хосте!"; 

//wifi_mode
var str_wifi_mode ='Wifi режим';
var str_wifimode ='Режим';
var str_wifi_speed ='Скор.';
var str_wifi_channel ='Канал';
var str_wifi_power ='Питание';
var str_wifimode0='Немодулированный непрерывный TX режим';
var str_wifimode1='Модулированный непрерывный TX режим';
var str_wifimode2='Непрерывный RX режим';

//4G
var str_4gset ='4G settings';
var str_4grunmode ='APN mode';
var str_4gauto ='Auto';
var str_4gmanual ='Manual';
var str_4gapn ='APN';
var str_4gsimcard ='SIM card';
var str_4gversion ='Module version';
var str_4gquality ='Signal quality';
var str_4gmcc ='Country code';
var str_4gmnc ='Network code';
var str_4gstatus ='Status code';
var str_4gauthtype ='Encryption type';
var str_4gcarrier ='Operator';
var str_4gimei ='IMEI';
var str_4giccid ='ICCID';

//restart timer
var str_restarttime="Таймер перезапуска";
var str_oclock="Часы";

//Tmall Genie
var str_tmall="Tmall Джини";

//Amazon Echo
var str_amazon="Amazon эхо";