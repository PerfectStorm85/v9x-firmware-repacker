﻿// JavaScript Document
//punct
var colon    = ":";
var period   = ".";
var comma    = ",";
var blank    = "&nbsp;";
var exclamation = "!";

//deviceinfo
var str_devname = "ID du périphérique";
var str_devtype = "Type de périphérique";
var str_netstat = "Connexion réseau";
var str_connnum = "Client actuel";
var str_softver = "Version du logiciel";
var str_webware = "Version Webware";
var str_rs485ver   = "Version PTZ";
var str_macaddr = "Adresse Mac";
var str_ipaddr = "Adresse IP";
var str_submask = "Masque de sous-réseau";
var str_gateway = "Passerelle";
var str_1stdns = "DNS primaire";
var str_2nddns = "DNS secondaire";
var str_upnpstatus = "UPnPstatus";
var str_facddnsstatus = "Statut DDNS du fabricant";
var str_th3ddnsstatus = "Statut DDNS tiers";
var success = "Succès";
var unenable = "Non activé";
var fail = "Échec";
var str_sysstart = "Heure de début";
var str_sdstat = "Statut SD";
var str_connwireless = "Wi-Fi";
var str_connwired = "LAN";
var str_conn4g     = "4G";
var str_dnsset = "Type de configuration DNS";
var str_manualdns = "DNS manuel";
var str_autodns = "À partir du serveur DHCP";
var str_httpport = "Numéro de port HTTP";
var str_rtspport = "Port RTSP";
var str_rtmpport = "Port RTMP";
var str_rtspauth = "Contrôle d'autorisation RTSP";
var str_cap_cvbs = "Réglages CVBS";
var str_cloud = "Réglages Cloud";
var str_cloudstat = "Statut Cloud";
var str_notpurchased = "Not Purchased";
var str_retention = "Jours de rétention"
var str_exptime = "Expiration Time";

//Terminal
var str_addrcode = "Adresse";
var str_protocol = "Protocal";
var str_portset = "Réglage Com";
var str_485portset = 485 + str_portset;
var str_485set = "485 Réglages";
var str_baudrate = "Vitesse de transmission";
var str_databit = "Bit de données";
var str_stopbit = "Bit d'arrêt";
var str_check = "Type de vérification";
var str_none = "Aucun";
var str_oddcheck = "Impair";
var str_evencheck = "Pair";
var str_tiltscope = '(1-50)';
var str_tiltno = 'Les tours de croisière ne peuvent pas être vides';
var tilttes = "Vitesse PTZ";
var tiltnum = "Tours de croisière";
var tiltmunmax = "Plage du cercle de croisière : 1-50";
var tiltcenter = "Centré pendant l'auto-vérification";
var str_speed0 = "Rapide";
var str_speed1 = "Moyenne";
var str_speed2 = "Lent";
var str_ptzalarm = "Fermer le mouvement PTZ de l'alarme";
var str_lenmodetip = "Mode d'affichage de l'indicateur";
var str_lenmode1 = 'Toujours allumé';
var str_lenmode2 = 'Toujours éteint';
var str_smartrack="Orbite intelligente";

//FTP 
var str_pasvmode   = "Mode passive";
var str_ftppic_name="Nom du fichier image";
var str_time_name  ="Date et nom du temps";
var str_fixed_name ="Nom de fichier fixe";
var str_alampic_name ="Nom de l'alarme";
var str_timepic_name ="Nom instantané du temps";
var str_filename_set ="Nom de fichier défini";
var str_autocreatedir ="Création automatique du répertoire";

//Serveur
var str_server     = "Adresse du serveur";
var str_port       = "Port du serveur";
var str_username   = "Nom d'utilisateur";
var str_password   = "Mot de passe";
var str_repassword = "Re-saisir le mot de passe";
var str_auth       = "Authentification";
var str_ftp_path   = "Chemin";
var str_ftp_test   ="Test des Réglages FTP";
var str_email_test   ="Test des Réglages E-mail";

//E-mail 
var str_emailset   = "Réglages E-mail";
var str_smtpserv   = "Nom du serveur SMTP :";
var str_sendto     = "Envoyer à";
var str_emailaddr  = "Adresse E-mail"
var str_sendaddr   = "Expéditeur";
var str_subject    = "Sujet";
var str_info       = "Message";
var str_max127c    = "la longueur maximum est de 127 caractères.";
var str_safelink="Lien sécurisé";
var str_massl0="Aucun";
var str_massl1="SSL";
var str_massl2="TLS";
var str_massl3="STARTTLS";

//Capture automatique
var str_timeint = "Intervalle de capture";
var str_sendemail = "Envoyer un e-mail";
var str_savepic = "Enregistrer l'image sur la carte SD";
var str_ftpsnap = "Enregistrer l'image sur le serveur FTP";
var str_cloudsnap  = "Enregistrer l'image sur le serveur Cloud";

//Réglages de l'enregistrement
var str_recsetup = "Paramètres d'enregistrement";
var str_recfile = "Durée des fichiers enregistrés";
var str_recplan = "Enregistrement programmé";
var str_allday = "Enregistrement dans le temps";
var str_allclear = "Pas d'enregistrement";
var str_timearea = "Enregistrement de temps spécifié";
var str_recswitch = "Activer l'enregistrement";
var str_all_area = 'Tout sélectionner';
var str_no_area = 'Tout effacer';
var str_recformat = "Format d'enregistrement";

//Alarme
var str_offenon = "Ouvert";
var str_offenoff = "Fermer";
var str_alarmex = "Alarme externe";
var str_alarmimode = "Mode d'alarme externe";

//audio alarm
var str_alarmaudio = "Alarme sonore";
var str_audiorange = "Plage de volume";

//smd
var str_alarmsmd ="Détection humaine";
var str_smdrecognition ="Reconnaissane intelligente humaine";
var str_smdthreshold ="Threshold";
var str_smdrect ="Rectangle détection";

//Audio
var str_audioset = "Paramètres audio";
var str_collecta = "Collection audio";
var str_auformat = "Type audio";
var str_audioin = "Mode d'entrée";
var str_volumein = "Volume d'entrée";
var str_volumeout = "Volume de sortie";
var str_inoption = "Entrée audio";
var str_intype = "Type d'entrée";
var str_aumicin = "MIC";
var str_aulinein = "Entrée linéaire";

//Temps
var str_timenow = "Date et heure actuelles";
var str_timedev = "Date et heure de la caméra";
var str_change = "Réglages";
var str_manualset = "Réglages manuels";
var str_date = "Date";
var str_time = "Heure";
var str_dateformat = "(aaaa-mm-jj)";
var str_timeformat = "(hh: mm: ss)";
var str_daterange = "(1971-01-01 ~ 2036-12-31)";
var str_syncfrompc = "Synchroniser avec l'heure de l'ordinateur";
var str_syncfrompc1 = "Synchroniser avec l'heure du PC";
var str_pctime = "Heure du PC";
var str_ntserver = "Protocole heure réseau";
var str_ntpserver = "serveur NTP";
var str_synctime = "Intervalle";
var str_hour = "Heures";
var str_keeptmset = "Conserver les paramètres actuels";
var str_timezone = "Fuseau horaire";
var str_autotime = "Ajuster automatiquement l'heure";

//Vidéo
var str_videoset = "Paramètres vidéo";
var str_videomode = "Format vidéo";
var str_videocoding = "Codage vidéo";
var str_resolution = "Résolution";
var str_streamrate = "Débit binaire";
var str_framerate = "Fréquence d'images maximale";
var str_framegap = "Intervalle de l'image principale";
var str_vcodectrl = "Contrôle du débit binaire";
var str_fixedcr = "CBR";
var str_variablecr = "VBR";
var str_vcodequa = "Qualité d'image";
var str_osdset = "Paramétrage OSD";
var str_osdopt = "Options de parenthèse";
var str_osdtime = "Date&heure";
var str_osdname = "Nom caméra";
var str_name = "Nom";
var str_maxchn = "Le plus grand canal de codage vidéo";
var str_colour = "Couleur";
var str_timeshow = "Position date&heure";
var str_nameshow = "Position du nom";
var str_tl = "En haut à gauche";
var str_tr = "En haut à droite";
var str_bl = "En bas à gauche";
var str_br = "En bas à droite";

//Plate-forme
var str_plcon = "Activer";
var str_puidnum = "PUID";
var str_asp = "Port du serveur d'accès";
var str_asa = "Adresse du serveur d'accès";
var str_fsp = "Port du serveur de transfert";
var str_fsa = "Adresse du serveur de transfert";
var str_gpsi = "intervalle de transmission des informations GPS";
var str_msec = "(milliseconde)";
var str_loginid = "ID de périphérique";
var str_loginpass = "Mot de passe";
var str_serverport = "Port";
var str_serveraddr = "Serveur";
var str_timeout = "Délai d'attente";
var str_constate = "Statut de la connexion";
var str_devnum = "ID de périphérique";
var str_dvsn = "Numéro de série";
var str_atransfer = "Transmission audio";
var str_alarmtrans = "Transmission d'informations d'alarme";
var str_uid = "UID";
var str_server1 = "Serveur 1";
var str_server2 = "Serveur 2";
var str_server3 = "Serveur 3";
var str_server4 = "Serveur 4";

//Onvif
var str_onvifenable = "Onvif";
var str_offcheck = "Pas de vérification";
var str_timecheck = "Paramètres du fuseau horaire";
var str_videocheck = "Paramètres d'image";
var str_allow = "Autoriser";
var str_prohibit = "Interdire";
var str_onvifchn = "Voie de circulation du sous-code";
var str_onvifsnap = "Capturer le canal";
var str_onvifnvctype = "Type de NVC";
var str_normal = "Normal";
var str_uniview = "Uniview";

//Alarme
var str_emailalarm = "Alarme par courrier électronique et envoi d'une image";
var str_sendpic = "Envoyer une photo";
var str_saverecftp = "Enregistrer la vidéo sur le serveur FTP";
var str_relayout = "Sortie relais";
var str_savevideo = "Enregistrer la vidéo sur la carte SD";
var str_cloudrecord  = "Paramètres du serveur Cloud";
var str_ftpservset = "Paramètres du serveur FTP";
var str_alarmplan = "Alarme horaire";
var str_alarmday = "Alarme permanente";
var str_alarmclear = "Pas d'alarme";
var str_alermarea = "Alarme de l'heure spécifiée";
var str_mdalarm_type    ="Alarme Trigger";
var str_mdalarm_single    ="Separate trigger";
var str_mdalarm_union    ="Linkage trigger";
var str_linkset = "Paramétrage de liaison";
var str_snapset = "Capture d'image";
var str_snapnum = "Nombre de cliché photo";
var str_alarmpreset = "Position préréglée";
var str_alarmsound = "Son de liaison";
var str_alarmbell = "Alarme";
var str_alarmdog = "Chien";
var str_alarmcustom = "Personnaliser";

//Réseau
var str_manualip = "Adresse IP fixe";
var str_autoip = "Adresse IP dynamique";
var str_lnset = "Paramètres LAN";
var str_ipget = "Type de configuration IP";
var str_internetip = "Adresse IP Internet";
var str_netip = "Adresse IP Internet";
var str_proddnsset = "DDNS principal";
var str_hostname = "Votre domaine";
var str_3thdnsset = "3ème DDNS";
var str_servprov = "Fournisseur";
var str_autoupnp = "Transfert de port UPnP";
var str_wlcheck = "Vérifier les paramètres sans fil";
var str_wlsuccess = "Connecté au Wi-Fi avec succès.";
var str_applywl = "Cliquez sur &quot;Fermer&quot; puis sur &quot; Appliquer&quot; pour enregistrer vos changements.";
var str_wlfailed = "La connexion Wi-Fi a échoué.";

//Programme
var str_weekmode = "Utiliser le mode semaine";
var str_weekendmode = "Utiliser le mode de travail";
var str_alltimemode = "Mode tout temps";
var str_week = "Jour";
var str_begintime = "Heure de début";
var str_endtime = "Heure de fin";
var str_workday = "Journée de travail";
var str_freeday = "weekend";
var str_everyday = "Tous les jours";
var str_sunday = "Dimanche";
var str_monday = "Lundi";
var str_tuesday = "Mardi";
var str_wednesday = "Mercredi";
var str_thursday = "Jeudi";
var str_friday = "Vendredi";
var str_saturday = "Samedi";

//Navigation
var str_rtview = "Moniteur";
var str_config = "Paramètres";
var str_avargs = "Média";
var str_videoa = "Vidéo";
var str_imagea = "Image";
var str_audioa = "Audio";
var str_netset = "Adressage réseau";
var str_wlset = "Sans fil";
var str_ddnsset = "Ddns";
var str_plset = "Identifiant P2P";
var str_onvif = "ONVIF";
var str_p2pset = "P2P";
var str_alarmset = "Alarme";
var str_alarmin = "Entrée d'alarme";
var str_mdset = "Zone détection";
var str_alaction = "Alarme";
var str_altime = "Agenda détection";
var str_advset = "Avancé";
var str_userset = "Utilisateur";
var str_timesnap = "Enregistrement auto photo";
var str_timerec = "Enregistrement auto vidéo";
var str_email = "E-mail";
var str_ftpset = "FTP";
var str_ptzset = "Terminal";
var str_sysset = "Système";
var str_timeset = "Date et heure";
var str_initset = "Initialiser";
var str_devinfo = "Informations caméra";
var str_systemlog = "Log système";
var str_videoshade = "Zone masquée";

//Sd op
var str_sdview = "Accéder à la carte SD";
var str_sdfat32 = "Formater la carte SD en fat32";
var str_sdstop = "Déconnecter la carte SD";

//Sd stat
var str_havesd = "Carte";
var str_nothavesd = "Pas de carte";
var str_freespace = "Espace libre"
var str_totalspace = "Espace total"

//Système bak up
var str_reboot = "Redémarrer";
var str_recoverdef = "Réglages d'usine";
var str_backup = "Sauvegarder la configuration";
var str_recoverbak = "Restaurer";
var str_upgradesys = "Mise à niveau";
var str_lenstype = "Type d'objectif";

//Bouton
var str_btn_reboot = "&nbsp; Redémarrer &nbsp;";
var str_btn_save = "&nbsp; Enregistrer &nbsp;";
var str_btn_confirm = "&nbsp; Ok &nbsp;";
var str_btn_query = "&nbsp; Afficher &nbsp;";
var str_btn_advanced = "&nbsp; Avancé &nbsp;";
var str_btn_recoverdef = "Paramètres par défaut";
var str_btn_apply = "&nbsp; Appliquer &nbsp;";
var str_btn_cancel = "Annuler";
var str_btn_clear = "&nbsp; Effacer &nbsp;";
var str_btn_default = "Par défaut";
var str_btn_search = "&nbsp; Recherche &nbsp;";
var str_btn_check = "&nbsp; Vérifier &nbsp;";
var str_btn_close = "&nbsp; Fermer &nbsp;";
var str_btn_refresh = "&nbsp; Actualiser &nbsp;";
var str_btn_test = "Test";
var str_btn_cleanlog = "Effacer le journal";

//Prompt
var str_note_upgrade = "&nbsp; La caméra IP est en cours de mise à niveau, veuillez ne pas l'éteindre.";
var str_note_upgradeok = "Mise à niveau de la caméra IP avec succès !";
var str_note_needreset = "Note : Modifiez les paramètres, le système redémarrera automatiquement";
var str_note_needreset0 = "(Note : Modifiez les paramètres, le système redémarrera automatiquement)";
var str_note_needreset1 = "Remarque : modifiez les paramètres, redémarrez le périphérique";
var str_note_needreset2 = "(Remarque: modifiez les paramètres, redémarrez le périphérique)";
var str_note_astreamnote = "(mobile)";
var str_note_wlsetting = "Vérification du Wi-Fi, veuillez patienter svp.";
var str_note_inputpath = "Veuillez saisir le chemin du fichier";
var str_note_inputipaddr = "Veuillez saisir l'adresse IP";
var str_note_inputsubmask = "Veuillez saisir l'adresse du masque de sous-réseau";
var str_note_inputgateway = "Veuillez saisir l'adresse de la passerelle";
var str_note_inputhostname = "Veuillez saisir le domaine";
var str_note_inputusername = "Veuillez saisir le nom d'utilisateur";
var str_note_inputpassword = "Veuillez saisir le mot de passe";
var str_note_inputport = "Veuillez saisir le port du serveur";
var str_note_inputpath = "Veuillez saisir le chemin racine ./";
var str_note_testtitle = "Veuillez définir d'abord, puis tester.";
var str_note_inputservaddr = "Veuillez saisir l'adresse du serveur";
var str_note_inputservname = "Veuillez saisir le nom du serveur";
var str_note_inputemail = "Veuillez saisir l'adresse e-mail";
var str_note_inputsendaddr = "Veuillez saisir l'adresse de l'expéditeur";
var str_note_inputasp = "Veuillez saisir le port du serveur";
var str_note_inputasa = "Veuillez saisir l'adresse d'accès";
var str_note_inputfsp = "Veuillez saisir le port du serveur de redirecteur";
var str_note_inputfsa = "Veuillez saisir l'adresse du transitaire";
var str_note_inputtimeout = "Veuillez saisir une valeur de délai d'attente";
var str_note_inputgpsi = "Veuillez saisir un intervalle de transmission des informations GPS";
var str_note_noinpublicip = "Adresse IP Internet : NULL";
var str_note_internetipis = "Adresse IP Internet :";
var str_note_vcodequa = "(Plus la valeur est petite, meilleure est la qualité d'image et plus le contrôle de flux est grand)";
var str_note_mbsize = "Résolution de l'image en mouvement";
var str_note_mdoff = "Remarque : la détection de mouvement sera désactivée lorsque le premier flux aura une taille de 320x176";
var str_note_maxframerate = "La cadence est supérieure à 25.";
var str_note_maxbps = "La plage de débits binaires est comprise entre 32 et 6144.";
var str_note_maxbps1 = "La plage de débits binaires est comprise entre 32-8192.";
var str_note_maxbps2 = "La plage de débit binaire est 32-2048.";
var str_note_maxbps3 = "La plage de débits binaires est comprise entre 32 et 512.";
var str_note_maxbps4 = "La plage de débits binaires est comprise entre 32-256.";
var str_note_atransfer = "(Avant d'ouvrir la transmission audio, accédez à la page de paramètres audio et vidéo, définissez le deuxième flux audio sur le mode activé, format AMR)";
var str_note_ipportchange = "L'IP ou le port a été modifié, veuillez vous reconnecter";
var str_note_rhportsame = "http et rtsp utilisent le même port";
var str_note_inputdate = "Veuillez saisir la date";
var str_note_inputtime = "Veuillez saisir l'heure";
var str_note_routemode = "(Sélectionnez le mode Infrastructure si vous utilisez un routeur sans fil.)";
var str_note_inputascii = "Veuillez saisir un caractère ASCII (la longueur est de 5 ou 13)";
var str_note_inputascii2 = "Veuillez saisir un caractère ASCII (la longueur est comprise entre 8 et 63)";
var str_note_inputhex = "Veuillez saisir un caractère HEX (la longueur est de 10 ou 26)";
var str_note_inputssid = "Veuillez saisir le ssid";
var str_note_inputkey = "Veuillez saisir la clé";
var str_note_inputrekey = "Veuillez saisir la clé de confirmation";
var str_note_nosupportp2p = "WPA / WPA2 ne prend pas en charge le mode point à point.";
var str_note_turnoffmd = "La résolution vidéo est 320x176, la détection de mouvement est désactivée";
var str_note_autoreboot = "La machine sera redémarrée !";
var str_test_success = "Test ...... Succès.";
var str_test_fail = "Test ...... a échoué.";
var str_note_mdalarmtype   = "(The union alarm requires both motion detection and smart alarm to be activated : L’alarme Union nécessitel’activation des 2 alarmes (détection de mouvement et alarmeintelligente)";



//Erreur
var str_err_invaildc = "Inclure le caractère invalide";
var str_err_invaildc2 = "Inclure le caractère invalide. (&, =, \", \\\) ";
var str_err_username = "Erreur du nom d'utilisateur";
var str_err_hostname = "Erreur du nom d'hôte";
var str_err_servname = "Erreur du nom de serveur";
var str_err_password = "Erreur du mot de passe";
var str_err_port = "Erreur du port";
var str_err_userinfo = "Erreur d'information de l'utilisateur, veuillez saisir à nouveau";
var str_err_servbusy = "Le serveur est occupé, veuillez patienter un instant";
var str_err_addrcode = "Adresse en dehors des limites";
var str_err_port = "Erreur de port"
var str_err_servaddr = "Erreur de l'adresse";
var str_err_smptserv = "Erreur du port";
var str_err_emailaddr = "Adresse invalide";
var str_err_tooshort = "La longueur de l'adresse doit être supérieure à 5";
var str_err_noat = "L'adresse doit inclure le caractère '@' ";
var str_err_addr1 = "Erreur de l'adresse du destinataire";
var str_err_addr2 = "";
var str_err_addr3 = "";
var str_err_sendaddr = "Erreur de l'adresse de l'expéditeur";
var str_err_subject = "Erreur du sujet";
var str_err_info = "Erreur du message";
var str_err_snapint = "L'intervalle devrait être entre 5-86400.";
var str_err_recfile = "La plage de temps est de 15 à 900 secondes";
var str_err_recfile1    = "La plage de temps est de 15 à 600 secondes";
var str_err_pwdconfirm = "Erreur de confirmation du mot de passe.";
var str_err_framegap = "Le cadre principal correspond à 2-300";
var str_err_gopframe   = "Key frame are less than framerate";
var str_err_osdname = "Le nombre de mots est supérieur à 18.";
var str_err_noname = "Veuillez saisir le nom de la caméra";
var str_err_noblank = "Le nom ne peut pas contenir tous les espaces";
var str_err_puid = "Erreur d'entrée du PUID";
var str_err_asp = "Erreur de port du serveur d'accès";
var str_err_asa = "Erreur d'adresse d'accès";
var str_err_fsp = "Erreur de port du serveur de transfert";
var str_err_fsa = "Erreur d'adresse de transfert";
var str_err_username = "Erreur du nom d'utilisateur";
var str_err_timeout = "Erreur de valeur du délai d'attente d'entrée";
var str_err_tooutrange = "Délai d'expiration hors limites";
var str_err_devnum = "Erreur d'identification du périphérique d'entrée";
var str_err_servaddr = "Erreur d'adresse du serveur";
var str_err_input = "Erreur de saisie \ n \ n";
var str_err_addrrange1 = "Adresse invalide, le premier numéro";
var str_err_addrrange2 = "Adresse invalide, le deuxième numéro";
var str_err_addrrange3 = "Adresse invalide, le troisième numéro";
var str_err_addrlast = "Adresse invalide, le dernier numéro"
var str_err_addr = "Adresse invalide";
var str_err_value = "Valeur invalide";
var str_err_pctime = "L'heure de votre ordinateur n'est pas valide, l'heure doit se situer entre 1970-01-01 et 2037-12-31";
var str_err_dateformat = "Format de date invalide";
var str_err_dfinput = "Le format doit être aaaa-mm-jj";
var str_err_reinputd = "Date invalide, merci de re-saisir";
var str_err_invaildtmf = "Format de date invalide";
var str_err_timeformat = "Le format doit être hh: mm: ss";
var str_err_imvaildtm = "Format d'heure invalide";
var str_err_key = "Erreur de la longueur de la clé wep. Hex est égal à 10 ou 26 ; ASCII est égal à 5 ou 13";
var str_err_ssid = "Erreur ssid, veuillez entrer un caractère valide";
var str_err_rekey = "Erreur de la clé de confirmation";
var str_err_ssid = "Erreur ssid, veuillez entre un caractère valide";
var str_err_ip2gateway = "L'IP et la passerelle ne font pas partie du même segment de réseau";
var str_err_volume = "Le volume est en dehors des limites (1-100), veuillez réinitialiser";
var str_err_username = "Le nom d'utilisateur ne peut pas être identique";
var str_err_nameerr = "Le nom d'utilisateur ne peut contenir que des lettres et des chiffres";
var str_err_nousername = "Veuillez saisir le nom d'utilisateur";
var str_error_none = "Erreur inconnue";
var str_error_server = "Impossible de se connecter au serveur";
var str_error_namepwd = "Utilisateur ou mot de passe incorrect";
var str_error_dir = "Erreur de chemin";
var str_error_ssl = "Erreur de paramétrage SSL";


var str_bps32_2048 = "Le débit binaire du premier flux est de 32-2048 kbps";
var str_bps32_512 = "Le débit binaire du premier flux est de 32-512 kbit / s";
var str_bps32_256 = "Le débit binaire du premier flux est de 32-256 kbit / s";

//Intervalle
var str_1_65535 = "1-65535";
var str_1_223_127 = "doit être compris entre 1 et 223 et non 127";
var str_0_255 = "doit être compris entre 0 et 255";
var str_1_255 = "doit être compris entre 1 et 255";
var str_0_254 = "doit être compris entre 0 et 254";
var str_1_254 = "doit être compris entre 1 et 254"
var str_80or1024_49151 = "(80 ou 1024 ~ 49151)";
var str_554or1024_49151 = "(554 ou 1024 ~ 49151)";
var str_1935or1024_49151 = "(1935 ou 1024 ~ 49151)";
var str_daterange = "La date doit être entre 1971-01-01 au 2036-12-31, veuillez entrer de nouveau";
var str_drange = "(1971-01-01 ~ 2036-12-31)";

//No ins
var str_noins0 = "L'émergence de cette page indique :";
var str_noins1 = "1. Vous n'avez pas installé ce contrôle ActiveX.";
var str_noins2 = "2. Vous avez installé, mais ceci une mise à jour du contrôle ActiveX que vous devez télécharger.";
var str_noins3 = "3. Trois.Vous devez vous connecter à Internet.";
var str_noins4 = "Cliquez.";
var str_noins5 = "Télécharger ActivX";
var str_noins6 = "et cliquez sur";
var str_noins7 = "run";
var str_noins8 = "Dans la boîte de message contextuelle pour installer ce contrôle ActiveX, actualiser cette page Web, démarrer un périphérique, puis afficher la vidéo";

//Dans l'usage commun
var str_readonly = "Lecture seule";
var str_rate = "Vitesse";
var str_auto = "Auto";
var str_view = "Voir";
var str_minute = "Minutes";
var str_stream = "Flux vidéo";
var str_1ststream = "Premier flux";
var str_2ndstream = "Deuxième flux";
var str_3thstream = "Troisième flux";
var str_on = "On";
var str_off = "Off";
var str_online = "En ligne";
var str_offline = "Hors ligne";
var str_sec = "Seconde"
var str_language_ex = "Langue";
var str_ch_ex        = "Chinese";
var str_en_ex        = "English";
var str_fr_ex        = "Français";
var str_de_ex        = "Deutsch";
var str_it_ex        = "Italiano";
var str_sp_ex        = "Español";
var str_ru_ex        = "русский язык";
var str_ja_ex        = "日本語";
var str_kr_ex        = "Korean";
var str_pl_ex        = "Polski";
var str_language = "Langue";
var str_chinese = "Chinois";
var str_english = "Anglais";
var str_francaise = "Français";
var str_deutsch   = "Allemand";
var str_italiano  = "Italien";
var str_spanish   = "Espagnol";
var str_russian   = "русский язык";
var str_japan    = "日本語";
var str_korean   = "coréen";
var str_poland    = "Polski";
var str_add = "Action";
var str_encrypt = "Crypter";
var str_authen = "Auth";
var str_connetm = "Type de réseau";
var str_channel = "Channel";
var str_confirm = "Rejoindre";
var str_purview = "Permission";


//Fuseau horaire
var str_GMT1 = 'Ligne de date internationale Ouest';
var str_GMT2 = 'Samoa';
var str_GMT3 = 'Hawaii';
var str_GMT4 = 'Alaska';
var str_GMT5 = 'Heure du Pacifique (États-Unis et Canada)';
var str_GMT6 = 'Chihuahua,';
var str_GMT7 = 'Heure des Rocheuses (États-Unis et Canada)';
var str_GMT8 = 'Arizona';
var str_GMT9 = 'Saskatchewan';
var str_GMT10 = 'Guadalajars, Mexico, Monterrey';
var str_GMT11 = 'Heure centrale (États-Unis et Canada)';
var str_GMT12 = 'Amérique centrale';
var str_GMT13 = 'Indiens (Est)';
var str_GMT14 = "Heure de l'Est (États-Unis et Canada)";
var str_GMT15 = 'Bogota, Lima, Quita';
var str_GMT16 = 'Carcacas';
var str_GMT17 = 'Santiago';
var str_GMT18 = 'Heure Atlantique (Canada)';
var str_GMT19 = 'Terre-Neuve';
var str_GMT20 = 'Montevideo';
var str_GMT21 = 'Buenos Aires';
var str_GMT22 = 'Brésil';
var str_GMT23 = 'Mi-Atlantique';
var str_GMT24 = 'Iles du Cap Vert';
var str_GMT25 = 'Açores';
var str_GMT26 = 'Dublin, Edimbourg, Lisbonne, Londres';
var str_GMT27 = 'Casablance';
var str_GMT28 = 'Amsterdam, Berlin, Berne, Rome, Stockholm et Vienne';
var str_GMT29 = 'Belgrade, Bratislava, Budapest, Ljubljana, Prague';
var str_GMT30 = 'Bruxelles, Copenhague, Madrid, Paris';
var str_GMT31 = 'Sarajevo, Skopje, Varsovie, Zagreb';
var str_GMT32 = 'Afrique centrale occidentale';
var str_GMT33 = 'Athènes, Bucarest, Istanbul';
var str_GMT34 = 'Bucarest';
var str_GMT35 = 'Cairo';
var str_GMT36 = 'Harare, Pretoria';
var str_GMT37 = 'Helsinki, Kiev, Riga, Sofia, Vilnius, Talinn';
var str_GMT38 = 'Jerusalem';
var str_GMT39 = 'Bagdad';
var str_GMT40 = 'Koweït, Riyad';
var str_GMT41 = 'Moscou, Saint-Pétersbourg, Volgograd';
var str_GMT42 = 'Nairobi';
var str_GMT43 = 'Téhéran';
var str_GMT44 = 'Abu_Dhabi, Muscat';
var str_GMT45 = 'Baku';
var str_GMT46 = 'Kaboul';
var str_GMT47 = 'Iekaterinbourg';
var str_GMT48 = 'Islamabad, Karachi';
var str_GMT49 = 'Chennai, Calcutta, Mumbai, New Delhi';
var str_GMT50 = 'Katmandu';
var str_GMT51 = 'Novosibirsk';
var str_GMT52 = 'Dhaka';
var str_GMT53 = 'Astana';
var str_GMT54 = 'Rangoon';
var str_GMT55 = 'Bangkok, Hanoï, Jakarta';
var str_GMT56 = 'Krasnoyarsk';
var str_GMT57 = 'Pékin, Chongqing, Hong Kong, Urumqi';
var str_GMT58 = 'Irkutsk';
var str_GMT59 = 'Kuala Lumpur, Singapour';
var str_GMT60 = 'Perth';
var str_GMT61 = 'Taipei';
var str_GMT62 = 'Osaka, Sapporo, Tokyo';
var str_GMT63 = 'Séoul';
var str_GMT64 = 'Yakutsk';
var str_GMT65 = 'Adelaide';
var str_GMT66 = 'Brisbane';
var str_GMT67 = 'Canberra, Melbourne, Sydney';
var str_GMT68 = 'Guam, Port Moresby';
var str_GMT69 = 'Hobart';
var str_GMT70 = 'Vladivostok';
var str_GMT71 = 'Magadan';
var str_GMT72 = 'Auckland, Wellington';
var str_GMT73 = 'Fidji';
var str_GMT74 = 'Nuku_alofa';


//Question
var str_ask_sdfat32 = "Êtes-vous sûr de vouloir formaté la carte SD en fat32 ?";
var str_ask_sdstop = "Êtes-vous sûr de vouloir arrêter la carte SD ?";
var str_ask_recoverbak = "Êtes-vous sûr de vouloir restaurer l'ipcam ?";
var str_ask_syspath = "Veuillez saisir le chemin du fichier";
var str_ask_upgradesys = "Êtes-vous sûr de vouloir mettre à niveau l'ipcam ?";
var str_ask_reboot = "Êtes-vous sûr de vouloir redémarré l'ipcam ?";
var str_ask_recoverdef = "Êtes-vous sûr de vouloir réinitialisé les données de configuration ?";


/// Afficher
var str_adjustneff = "(Réglage de l'effet nocturne)";
var str_nightmode = "Modèle de nuit";
var str_adjustnl = "Réglage de la luminance nocturne";
var str_nlight = "Luminance nocturne";
var str_brightness = "Luminosité";
var str_saturation = "Saturation";
var str_contrast = "Contraste";
var str_sharpness = "Netteté";
var str_hue = "Nuance";
var str_shutter = "Obturateur";
var str_ldcratio = "Distortion";
var str_ae = "Exposition minimale";
var str_targety = "Exposition";
var str_gamma = "Gamma";
var str_dnt = "Sensibilité";
var str_lumi = "Luminance";
var str_imageset = "Paramètres d'image";
var str_updown = "Retourner";
var str_leftright = "Miroir";
var str_wdr = "WDR";
var str_onmode = "Mode";
var str_mode = "Mode";
var str_black = "Noir et Blanc";
var str_color = "Couleur";
var str_aemode = "Mode d'exposition";
var str_auto = "Auto";
var str_indoor = "Intérieur";
var str_outdoor = "Extérieur";
var str_imgmode = "Mode priorité image";
var str_framerate1 = "Fréquence d'images";
var str_inance = "Priorité d'éclairage";
var str_ircut = "IRCut";
var str_ircutye = "(1-1024, plus la valeur est grande, plus le temps de commutation est long)";
var str_sensitivity = "Sensibilité";
var str_wdrmode = "WDR";
var str_wdrvalue = "Valeur WDR";
var str_lightmode     = "Mode lumière";
var str_changing      = "Changement";
var str_manual       = "Manuel";
var str_lightness    = "Léger";
var str_window = "Fenêtre";
var str_safetype = "Mode de sécurité";
var str_encway = "Algorithme WPA";
var str_key = "Clé";
var str_confirmkey = "Clé de confirmation";
var str_checkwl = "Vérifier la configuration sans fil";
var str_hwctrl = "Contrôle DEL IR";
var str_noise = "Bruit";
var str_noisetye = "(0-100, inférieur en fonction du travail)";
var str_lamp       = "Mode Vision de Nuit";
var str_lamp0       = "Normal";
var str_lamp1       = "Couleur";
var str_lamp2       = "Intelligent";

// Sans fil
var str_wlenable = "Activer le sans fil";
var str_conmode = "Mode";
var str_route = "Infrastructure";
var str_p2p = "Point à point";

var str_welcome = "Sélectionnez ce que vous voulez faire:";
var str_pcview = "Visualiser sur PC";
var str_mbview = "Vue mobile";
var str_setupsoft = "Plugin d'installation (première utilisation)";

var str_sd = "Carte SD";
var str_snap = "Capture";
var str_record = "Enregistrer";
var str_playback = "Lecture";
var str_up = "Haut";
var str_down = "Bas";
var str_right = "Droite";
var str_left = "Gauche";
var str_center = "Centre";
var str_ud = "Monter et descendre";
var str_lr = "Croisant à gauche et à droite";
var str_preset = "Préréglage";
var str_zoomin = "Zoom avant";
var str_zoomout = "Zoom arrière";
var str_focusin = "Focus +";
var str_focusout = "Focus-";
var str_posset = "Réglages";
var str_poscall = "Appel";
var str_refresh = "Actualiser";
// gb28181
var str_err_svrport = "La plage de ports est comprise entre 1 et 65535.";
var str_gb28181 = "GB28181";
var str_gb_gb28181 = "GB28181";
var str_svrid = "ID du serveur";
var str_svrip = "Adresse du serveur";
var str_svrport = "Port du serveur";
var str_devid = "ID de périphérique";
var str_devport = "ID du serveur";
var str_devpwd = "Mot de passe de l'appareil";
var str_alarmid = "ID de l'alarme";
var str_heartcycle   ="Cycle cardiaque";
var str_heartcount   ="Temps d'arrêt cardiaque maximal";
var str_regtime      ="Validité de l'enregistrement";

//Paramètres multiples
var str_addport = 'Multi caméras';
var str_addportset = 'Paramètres multi caméras';
var str_local_host = "Native";
var str_refesh = "Actualiser";
var str_local_network = "Recherche sur le réseau local";
var str_first_dev = "Le premier périphérique";
var str_second_dev = "Le 2ème périphérique";
var str_third_dev = "Le 3ème périphérique";
var str_fourth_dev = "Le 4ème périphérique";
var str_fifth_dev = "Le 5ème périphérique";
var str_sixth_dev = "Le 6ème périphérique";
var str_seventh_dev = "Le 7ème périphérique";
var str_eighth_dev = "Le 8ème périphérique";
var str_ninth_dev = "Le 9ème périphérique";
var str_add = "Ajouter";
var str_remove = "Supprimer";
var str_set = "Soumettre";
var str_cancel = "Annuler";
var str_none = 'Aucun';
var str_overlay_name = 'Nom de la caméra :';
var str_ip_address = 'IP :';
var str_http_port = 'Port :';
var str_user_name = 'Utilisateur :';
var str_user_psw = 'Mot de passe :';
var str_anonymous = '';
var str_err_selected = "L'hôte n'existe pas, merci de choisir à nouveau !"
var str_err_hostnum = "Veuillez sélectionner l'hôte à exploiter !";

//Mode Wi-Fi
var str_wifi_mode = 'Mode Wi-Fi';
var str_wifimode = 'Mode';
var str_wifi_speed = 'Vitesse';
var str_wifi_channel = 'Canal';
var str_wifi_power = 'Puissance';
var str_wifimode0 = 'Mode TX continu non modulé';
var str_wifimode1 = 'Mode TX continu modulé';
var str_wifimode2 = 'Mode RX continu';

//4G
var str_4gset ='Paramètres 4G';
var str_4grunmode ='Mode APN';
var str_4gauto ='Automatique';
var str_4gmanual ='Manuellement';
var str_4gapn ='APN';
var str_4gsimcard ='Carte SIM';
var str_4gversion ='Version modulaire';
var str_4gquality ='Qualité du signal';
var str_4gmcc ='Code de pays';
var str_4gmnc ='Code réseau';
var str_4gstatus ='Code d état';
var str_4gauthtype ='Type de chiffrement';
var str_4gcarrier ='Opérateur';
var str_4gimei ='IMEI';
var str_4giccid ='ICCID';

//Redémarrer la minuterie
var str_restarttime = "Redémarrage";
var str_oclock = "Heure";

//Tmall Genie
var str_tmall="Tmall Genie";

//Amazon Echo
var str_amazon="Amazon Echo";