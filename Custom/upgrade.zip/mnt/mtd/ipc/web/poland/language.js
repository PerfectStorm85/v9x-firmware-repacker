﻿// JavaScript Document
//punct
var colon    = ":";
var period   = ".";
var comma    = ",";
var blank    = "&nbsp;";
var exclamation = "!";

//deviceinfo
var str_devname    = "Identyfikator";
var str_devtype    = "Typ urządzenia";
var str_netstat    = "Połączenie Sieciowe";
var str_connnum    = "Użytkownicy";
var str_softver    = "Wersja oprogramowania";
var str_webware    = "Wersja wtyczki";
var str_rs485ver   = "Wersja PTZ";
var str_macaddr    = "Adres MAC";
var str_ipaddr     = "Adres IP";
var str_submask    = "Maska Sieci";
var str_gateway    = "Brama Sieci";
var str_1stdns     = "Serwer DNS";
var str_2nddns     = "Pomocniczy DNS";
var str_upnpstatus="Status UPnP";
var str_facddnsstatus="Fabryczny DDNS";
var str_th3ddnsstatus="Własny DDNS";
var success           = "Zakończono powodzeniem";
var unenable          = "Wył.";
var fail              = "Zakończono niepowodzeniem";
var str_sysstart   = "Data fabryczna";
var str_sdstat     = "Status karty SD";
var str_connwireless = "WiFi";
var str_connwired    = "LAN";
var str_conn4g     = "4G";
var str_dnsset     = "Typ konfiguracji DNS";
var str_manualdns  = "Ręczny DNS";
var str_autodns    = "Z serwera DHCP";
var str_httpport   = "Port HTTP";
var str_rtspport   = "Port RTSP";
var str_rtmpport   = "Port RTMP";
var str_rtspauth   = "Uwierzytelnianie RTSP";
var str_cap_cvbs  = "Ustawienia CVBS";
var str_cloud = "Ustawienia Chmury";
var str_cloudstat = "Status Chmury";
var str_notpurchased = "Nie wykupiono";
var str_retention  = "Dni przechowywania"
var str_exptime = "Ważne do";

//terminal
var str_addrcode   = "Adres";
var str_protocol   = "Protokół"; 
var str_portset    = "Ustawienia COM";
var str_485portset = 485 + str_portset;
var str_485set     = "485Set";
var str_baudrate   = "Baudrate";
var str_databit    = "Data bit";
var str_stopbit    = "Stop bit";
var str_check      = "Sprawdzaj";
var str_none       = "Brak";
var str_oddcheck   = "Nieparzyste";
var str_evencheck  = "Parzyste";
var str_tiltscope='(1-50)';
var str_tiltno='Musisz ustawić punkty trasy';
var tilttes="Prędkość PTZ";
var tiltnum="Powtarzanie trasy";
var tiltmunmax="Zakres auto-trasy:1-50";
var tiltcenter="Wróć do punktu 0 po samo-diagnozie";
var str_speed0="Szybko";
var str_speed1="Normalnie";
var str_speed2="Wolno";
var str_ptzalarm="Wyłącz Alarm podczas ręcznej kontroli";
var str_lenmodetip='Diody złącza RJ45';
var str_lenmode1='Włącz';
var str_lenmode2='Wyłącz';
var str_smartrack="Śledzenie postaci";

//FTP 
var str_pasvmode   = "Pasywne";
var str_ftppic_name="Nazwa pliku zrzutu";
var str_time_name  ="Nazwa pliku";
var str_fixed_name ="Stała nazwa";
var str_alampic_name ="Nazwa pliku Alarmu";
var str_timepic_name ="Nazwa pliku Harmon.";
var str_filename_set ="Ustaw. nazw plików";
var str_autocreatedir ="Automatycznie twórz folder";

//server
var str_server     = "Adres Serwera";
var str_port       = "Port Serwera";
var str_username   = "Login";
var str_password   = "Hasło";
var str_repassword = "Powtórz Hasło";
var str_auth       = "Uwierzytelnianie";
var str_ftp_path   = "Ścieżka";
var str_ftp_test   =" Test FTP";
var str_email_test   ="Test e-mail";

//email 
var str_emailset   = "Ustawienia e-mail";
var str_smtpserv   = "Serwer SMTP:";
var str_sendto     = "Wyślij do";
var str_emailaddr  = "Adres e-mail"
var str_sendaddr   = "Nadawca";
var str_subject    = "Temat";
var str_info       = "Treść wiadomości";
var str_max127c    = "Maks. długość to 127 znaków";
var str_safelink="Szyfrowanie";
var str_massl0="Brak";
var str_massl1="SSL";
var str_massl2="TLS";
var str_massl3="STARTTLS";

//autosnap
var str_timeint    = "Częstotliwość";
var str_sendemail  = "Wyślij e-mail";
var str_savepic    = "Zapisz Zdjęcie na kartę SD";
var str_ftpsnap    = "Zapisz Zdjęcie na serwerze FTP";
var str_cloudsnap  = "Zapisz Zdjęcie w Chmurze";

//Record Setting
var str_recsetup   = "Ustawienia Nagrywania";
var str_recfile    = "Długość plików nagrań";
var str_recplan    = "Harmonogram nagrań";
var str_allday     = "Nagrywanie ciągłe";
var str_allclear   = "Brak nagrywania";
var str_timearea   = "Nagrywanie wg. czasu";
var str_recswitch  = "Włącz nagrywanie";
var str_all_area   ='Wszystko';
var str_no_area    ='Wyczyść';
var str_recformat='Format pliku';

//alarmin
var str_offenon    = "Otwarty";
var str_offenoff   = "Zamkniety";
var str_alarmex    = "Zew. Czujka Alarm";
var str_alarmimode = "Tryb pracy";

//audio alarm
var str_alarmaudio ="Alarm Dźwiękowy";
var str_audiorange ="Zakres głośności";

//smd
var str_alarmsmd ="Wykrywanie Postaci";
var str_smdrecognition ="Inteligentne Wykrywanie Postaci";
var str_smdthreshold ="Czułość";
var str_smdrect ="Ramka postaci";

//audio
var str_audioset   = "Ustawienia Dźwięku";
var str_collecta   = "Ustawienia Dźwięku";
var str_auformat   = "Kodek";
var str_audioin    = "Tryb wej.";
var str_volumein   =  "Głośność wej.";
var str_volumeout   = "Głośność wyj.";
var str_inoption   = "Urządzenie Wejściowe";
var str_intype     = "Typ wejścia";
var str_aumicin    = "Mikrofon";
var str_aulinein   = "Line in";

//time
var str_timenow    = "Bierząca Data i Czas";
var str_timedev    = "Data i Czas urządzenia";
var str_change     = "Ustawienia";
var str_manualset  = "Ręczna konfiguracja";
var str_date       = "Data";
var str_time       = "Harmonogram";
var str_dateformat = "(rrrr-mm-dd)";
var str_timeformat = "(gg:mm:ss)";
var str_daterange  = "(1971-01-01 ~ 2036-12-31)";
var str_syncfrompc = "Synchronizuj z PC";
var str_syncfrompc1 = "Synchronizuj z PC";
var str_pctime     = "Czas na PC";
var str_ntserver   = "Czas z Internetu";
var str_ntpserver  = "Serwer NTP";
var str_synctime   = "Odśwież co";
var str_hour       = "godziny";
var str_keeptmset  = "Zachowaj bieżące";
var str_timezone   = "Strefa Casu";
var str_autotime   = "Automatycznie uwzględnij zmiany czasu";

//video
var str_videoset   = "Ustawienia Video";
var str_videomode  = "Odświeżanie";
var str_videocoding = "Kodek";
var str_resolution = "Rozdzielczość";
var str_streamrate = "Bitrate";
var str_framerate  = "Max. klatek na sekundę";
var str_framegap   = "Częstotliwość I-Frame";
var str_vcodectrl  = "Tryb Bitrate";
var str_fixedcr    = "CBR";
var str_variablecr = "VBR";
var str_vcodequa   = "Jakość Video";
var str_osdset     = "Nakładka Ekranu";
var str_osdopt     = "Nakładka Ekranu (OSD)";
var str_osdtime    = "Pokaż czas";
var str_osdname    = "Nazwa kamery";
var str_name       = "Nazwa";
var str_maxchn     = "Kodowanie Strumienia Głównego";
var str_colour      = "Kolor";
var str_timeshow    ="Pokaż czas";
var str_nameshow    ="Pokaż nazwę";
var str_tl    ="Góra, lewo";
var str_tr    ="Góra, prawp";
var str_bl    ="Dół, lewo";
var str_br    ="Dół, prawo";

//platform
var str_plcon      = "Dostęp zdalny";
var str_puidnum    = "PUID";
var str_asp        = "Adres serwera";
var str_asa        = "Port serwera";
var str_fsp        = "Przekierowany port serwera";
var str_fsa        = "Przekierowany adres serwera";
var str_gpsi       = "Interwał wysyłania info. GPS";
var str_msec       = "(milisekunky)";
var str_loginid    = "ID Urządzenia";
var str_loginpass  = "Hasło";
var str_serverport = "Port";
var str_serveraddr = "Serwer";
var str_timeout    = "Timeout";
var str_constate   = "Status połączenia";
var str_devnum     = "ID Urządzenia";
var str_dvsn       = "Numer Seryjny";
var str_atransfer  = "Przekazywanie dźwieku";
var str_alarmtrans = "Przekazywanie alarmu";
var str_uid        = "UID";
var str_server1   = "Serwer1";
var str_server2   = "Serwer2";
var str_server3   = "Serwer3";
var str_server4   = "Serwer4";

//onvif
var str_onvifenable = "ONVIF";
var str_offcheck     ="Domyślnie";
var str_timecheck    ="Zmiana ust. Czasu";
var str_videocheck   ="Zmiana ust. Obrazu";
var str_allow        ="Zezwól";
var str_prohibit     ="Odmów"; 
var str_onvifchn     ="Przekaz. kodu podrzednego";
var str_onvifsnap     ="Przechwytywanie kanału";
var str_onvifnvctype ="Tryb NVC";
var str_normal ="Normalny";
var str_uniview ="Uniview";

//alarm
var str_emailalarm = "Wysyłaj email ze zdjęciem";
var str_sendpic    = "Wyślij ze zdjęciem";
var str_saverecftp = "Zapisz nagranie na FTP";
var str_relayout   = "Ust. przekazywania";
var str_savevideo  = "Zapisz nagranie na kartę SD";
var str_cloudrecord  = "Zapisz nagranie w Chmurze";
var str_ftpservset = "Ustawienia FTP";
var str_alarmplan  = "Harmonogram Alarmu";
var str_alarmday   = "Wszystko";
var str_alarmclear = "Wyczyść";
var str_alermarea  = "W wybranym czasie";
var str_mdalarm_type    ="Tryb uruchomienia";
var str_mdalarm_single    ="Uruchom osobno";
var str_mdalarm_union    ="Połącz Alarmy";
var str_linkset    ="Powiązane akcje";
var str_snapset    ="Ustawienia Zdjęć";
var str_snapnum    ="Ilość zdjęć";
var str_alarmpreset ="Idź do punktu";
var str_alarmsound   = "Komunikat dźwiękowy";
var str_alarmbell   = "Alarm";
var str_alarmdog   = "Szczekanie psa";
var str_alarmcustom   = "Własne nagranie";

//network
var str_manualip   = "Ręczna konfiguracja";
var str_autoip     = "Pobierz z DHCP";
var str_lnset      = "Ustawienia Sieci";
var str_ipget      = "Ustawienia IP";
var str_internetip = "Zewnętrzny adres IP";
var str_netip      = "Zewnętrzny adres IP";
var str_proddnsset = "Fabryczny DDNS ";
var str_hostname   = "Twoja Domena";
var str_3thdnsset  = "Inny DDNS";
var str_servprov   = "Usługodawca";
var str_autoupnp   = "Przekierowanie portów UPnP";
var str_wlcheck    = "Sprawdź połączenie";
var str_wlsuccess  = "Połączono z Siecią WiFi.";
var str_applywl    = "Wybierz &quot;Zapisz &quot; aby zachować bieżącą konfigurację.";
var str_wlfailed   = "Nie udało się połączyć z Siecią WiFi.";

//schdule
var str_weekmode     = "Wszystkie dni tygodnia";
var str_weekendmode  = "Tylko dni pracujące";
var str_alltimemode  = "Cały czas";
var str_week         = "Dzień";
var str_begintime    = "Start";
var str_endtime      = "Koniec";
var str_workday      = "Dzień pracujący";
var str_freeday      = "Weekend";
var str_everyday     = "Codziennie";
var str_sunday       = "Niedziela";
var str_monday       = "Poniedziałek";
var str_tuesday      = "Wtorek";
var str_wednesday    = "Środa";
var str_thursday     = "Czwartek";
var str_friday       = "Piątek";
var str_saturday     = "Sobota";

//Navigation
var str_rtview   = "PODGLĄD";
var str_config   = "OPCJE";
var str_avargs   = "OBRAZ i DŹWIĘK";
var str_videoa   = "VIDEO";
var str_imagea   = "OBRAZ";
var str_audioa   = "DŹWIĘK";
var str_netset   = "SIEĆ";
var str_wlset    = "WiFi";
var str_ddnsset  = "DDNS";
var str_plset    = "DOSTĘP ZDALNY";
var str_onvif    = "ONVIF";
var str_p2pset   = "P2P";
var str_alarmset = "ALARM";
var str_alarmin  = "WEJŚCIA ALARMOWE";
var str_mdset    = "WYKRYWANIE RUCHU";
var str_alaction = "POWIĄZANE AKCJE";
var str_altime   = "HARMONOGRAM";
var str_advset   = "ZAAWANSOWANE";
var str_userset  = "UŻYTKOWNIK";
var str_timesnap = "ZDJĘCIA AUTO.";
var str_timerec  = "NAGRYWANIE CIĄGŁE";
var str_email    = "EMAIL";
var str_ftpset   = "FTP";
var str_ptzset   = "PTZ";
var str_sysset   = "SYSTEM";
var str_timeset  = "DATA i CZAS";
var str_initset  = "KONSERWACJA";
var str_devinfo  = "INFORMACJE";
var str_systemlog = "DZIENNIK ZDARZEŃ";
var str_videoshade ="STREFY PRYWATNOŚCI";

//sd op
var str_sdview   = "Przeglądaj pliki";
var str_sdfat32  = "Formatuj kartę SD";
var str_sdstop   = "Odłącz kartę SD";

//sd stat
var str_havesd     = "Wykryto kartę SD";
var str_nothavesd  = "Brak karty SD";
var str_freespace  = "Wolne miejsce"
var str_totalspace = "Całkowita pojemność" 

//system bak up
var str_reboot     = "Uruchom ponownie";
var str_recoverdef = "Reset do fabrycznych";
var str_backup     = "Twórz kopię konfiguracji";
var str_recoverbak = "Przywróć";
var str_upgradesys = "Aktualizacja";
var str_lenstype ="Obiektyw";

//button
var str_btn_reboot     = "&nbsp;Reboot&nbsp;";
var str_btn_save       = "&nbsp;Zapisz&nbsp;";
var str_btn_confirm    = "&nbsp;OK&nbsp;";
var str_btn_query      = "&nbsp;Pokaż&nbsp;";
var str_btn_advanced   = "&nbsp;Zaawansowane&nbsp;";
var str_btn_recoverdef = "Ustaw. Fabryczne";
var str_btn_apply      = "&nbsp;Zapisz&nbsp;";
var str_btn_cancel     = "Anuluj";
var str_btn_clear      = "&nbsp;Wyczyść&nbsp;";
var str_btn_default    = "Domyślne";
var str_btn_search     = "&nbsp;Szukaj&nbsp;";
var str_btn_check      = "&nbsp;Sprawdź&nbsp;";
var str_btn_close      = "&nbsp;Zamknij&nbsp;";
var str_btn_refresh    = "&nbsp;Odśwież&nbsp;";
var str_btn_test       = "Test";
var str_btn_cleanlog   = "Wyczyść Dziennik";

//prompt
var str_note_upgrade       = "&nbsp;Traw aktualizacja oprogramowania, nie wyłączaj urządzenia !";
var str_note_upgradeok     = "Pomyślnie zaktualizowano oprogramowanie.";
var str_note_needreset     = "UWAGA: Zmiana konfiguracji, nastąpi automatyczne uruchomienie ponowne urządzenia.";
var str_note_needreset0    = "(UWAGA: Zmiana konfiguracji spowoduje automatyczne uruchomienie ponowne urządzenia.)";
var str_note_needreset1    = "UWAGA: Zmiana konfiguracji, należy ponownie uruchomić urządzenie.";
var str_note_needreset2    = "(UWAGA: Zmiana ustawień będzie wymagała ponownego uruchomienia urządzenia";
var str_note_astreamnote   = "(Aplikacja na smartfon)";
var str_note_wlsetting     = "Trwa sprawdzanie Sieci WiFi, proces zajmie ok. 30-60sek.";
var str_note_inputpath     = "Podaj ścieżkę pliku, lub Przeglądaj aby wybrać plik";
var str_note_inputipaddr   = "Wprowadź adres IP";
var str_note_inputsubmask  = "Wprowadź Maskę Sieci";
var str_note_inputgateway  = "Wprowadź adres IP Bramy";
var str_note_inputhostname = "Wprowadź nazwę Domeny";
var str_note_inputusername = "Wprowadź nazwę użytkownika";
var str_note_inputpassword = "Wprowadź hasło";
var str_note_inputport     = "Wprowadź prawidłowy Port Serwera";
var str_note_inputpath     = "Wprowadź ścieżkę root ./";
var str_note_testtitle     = "Uzupełnij konfigurację, i skorzystaj z przycisku Test.";
var str_note_inputservaddr = "Wprowadź adres serwera";
var str_note_inputservname = "Wprowadź nazwę serwera";
var str_note_inputemail    = "Wprowadź adres e-mail odbiorcy";
var str_note_inputsendaddr = "Wprowadź adres e-mail nadawcy";
var str_note_inputasp      = "Wprowadź port serwera";
var str_note_inputasa      = "Wprowadź adres dostępu";
var str_note_inputfsp      = "Wprowadź port serwera przekierowań";
var str_note_inputfsa      = "Wprowadź adres przekierowań";
var str_note_inputtimeout  = "Musisz określić wartość Timeout";
var str_note_inputgpsi     = "Musisz określić częstotliwość wysyłania informacji GPS";
var str_note_noinpublicip  = "Zewnętrzny adres IP: NULL";
var str_note_internetipis  = "Zewnętrzny adres IP: ";
var str_note_vcodequa      = "(Im mniejsza wartość, tym lepsza jakość obrazu ale też większe wykorzystanie Sieci)";
var str_note_mbsize        = "Rozdzielczość obrazu w Aplikacji na smartfon";
var str_note_mdoff         = "UWAGA: Wykrywanie Ruchu zostanie wyłączone jeżeli pierwszy/główny strumień ma rozdzielczość 320x176";
var str_note_maxframerate  = "Maksymalna wartość FPS to 25, popraw ustawienia.";
var str_note_maxbps        = "Zakres wartości Bitrate to 32-6144";
var str_note_maxbps1        = "Zakres wartości Bitrate to 32-8192";
var str_note_maxbps2        = "Zakres wartości Bitrate to 32-2048";
var str_note_maxbps3        = "Zakres wartości Bitrate to 32-512";
var str_note_maxbps4        = "Zakres wartości Bitrate to 32-256";
var str_note_atransfer     = "(Zanim włączysz funkcję interkomu, musisz włączyć dźwięk dla drugiego/podrzędnego strumienia video w ustawieniach Obraz i Dźwięk)";
var str_note_ipportchange  = "Adres IP i/lub Port zostały zmienione. Użyj nowo-wprowadzonych ustawień aby ponownie połączyć się z urządzeniem.";
var str_note_rhportsame    = "UWAGA: HTTP i RTSP używają tych samych portów! Popraw konfigurację.";
var str_note_inputdate     = "Wprowadź datę";
var str_note_inputtime     = "Wprowadź czas";
var str_note_routemode     = "(Wybierz Tryb Infrastruktury jeżeli korzystasz z routera bezprzewodowego)";
var str_note_inputascii    = "Używaj tylko zwykłych (duże i małe) liter, bez znaków specjalnych (dopuszczalna długość to od 5 do 13 znaków)";
var str_note_inputascii2   = "Używaj tylko zwykłych (duże i małe) liter, bez znaków specjalnych (dopuszczalna długość to od 8 do 63 znaków)";
var str_note_inputhex      = "Używaj tylko zwykłych (duże i małe) liter i cyfr, bez znaków specjalnych (dopuszczalna długość to od 10 do 26 znaków)";
var str_note_inputssid     = "Wprowadź SSID";
var str_note_inputkey      = "Wprowadź hasło WiFi";
var str_note_inputrekey    = "Powtórz hasło WiFi";
var str_note_nosupportp2p  = "WPA/WPA2 nie jest wspierana w trybie Point to Point";
var str_note_turnoffmd     = "UWAGA: Rozdzielczość Video to 320x176, Wykrywanie Ruchu zostało wyłączone!";
var str_note_autoreboot    = "UWAGA: Urządzenie uruchomi się ponownie!";
var str_test_success       = "Test...... OK";
var str_test_fail          = "Test...... Zakończono niepowodzeniem";
var str_note_mdalarmtype   = "(Połącz Alarmy - tylko uruchomienie Wykrywania Postaci w obszarze Wykrywania Ruchu spowoduje uruchomienie alarmu)";



//err
var str_err_invaildc   = "BŁĄD: Zawiera niedopuszczalne znaki";
var str_err_invaildc2  = "BŁĄD: Zawiera niedopuszczalne znaki (&,=,\",\\\)";
var str_err_username   = "BŁĄD: Nieprawidłowa Nazwa Użytkownika/Login";
var str_err_hostname   = "BŁĄD: Nieprawidłowa nazwa Hosta";
var str_err_servname   = "BŁĄD: Nieprawidłowa nazwa Serwera";
var str_err_password   = "BŁĄD: Niepoprawne hasło";
var str_err_port       = "BŁĄD: Numer portu nie jest prawidłowy";
var str_err_userinfo   = "BŁĄD: Błędne dane Użytkownika, wprowadź ponownie";
var str_err_servbusy   = "Serwer jest zajęty, proszę czekać...";
var str_err_addrcode   = "BŁĄD: Adres jest poza zakresem Sieci!";
var str_err_port       = "BŁĄD: Nieprawidłowy port!"
var str_err_servaddr   = "BŁĄD: Błędny adres Serwera!";
var str_err_smptserv   = "BŁĄD: Nieprawidłowy port SMTP";
var str_err_emailaddr  = "BŁĄD: Niepoprawny adres e-mail";
var str_err_tooshort   = "Adres e-mail musi mieć min. 5 znaków";
var str_err_noat       = "Adres e-mail musi zawierać '@'";
var str_err_addr1      = "BŁĄD: Niepoprawny adres e-mail Odbiorcy";
var str_err_addr2      = "";
var str_err_addr3      = "";
var str_err_sendaddr   = "BŁĄD: Niepoprawny adres e-mail Nadawcy";
var str_err_subject    = "BŁĄD: Nieprawidłowy Temat wiadomości";
var str_err_info       = "BŁĄD: Nieprawidłowa Treść Wiadomości";
var str_err_snapint    = "Interwał może być ustawiony w zakresie 5-86400";
var str_err_recfile    = "Czas nagrań może byćustawiony z zakresu 15-900 sekund";
var str_err_recfile1    = "Czas nagrań może byćustawiony z zakresu 15-600 sekund";
var str_err_pwdconfirm = "BŁĄD: Hasła nie są takie same!";
var str_err_framegap   = "Możesz ustawić zakres I-Frame w granicach 2-300";
var str_err_gopframe   = "Klawisz jest mniejszy niż framerat";
var str_err_osdname    = "Maks. długość nazwy to 18 znaków";
var str_err_noname     = "Proszę wprowadzić nazwę kamery";
var str_err_noblank    = "Nazwa nie może zawierać samych spacji";
var str_err_puid       = "BŁĄD: Wprowadzony PUID jest nieprawidłowy!";
var str_err_asp        = "BŁĄD: Niewłaściwy Port dostępu do Serwera!";
var str_err_asa        = "BŁĄD: Niepoprawny Adres dostępudo Serwera!";
var str_err_fsp        = "BŁĄD: Niewłaściwy Port Serwera Przekierowań!";
var str_err_fsa        = "BŁĄD: Niepoprawny Adres Serwera Przekierowań!";
var str_err_username   = "BŁĄD: Niepoprawna Nazwa Użytkownika/Login";
var str_err_timeout    = "BŁĄD: Wprowadzono niewłaściwą wartość dla Timeout";
var str_err_tooutrange = "BŁĄD: Wartość Timeout poza dopuszczalnym zakresem";
var str_err_devnum     = "BŁĄD: Niewłaściwe ID urządzenia!";
var str_err_servaddr   = "BŁĄD: Niepoprawny adres Serwera";
var str_err_input      = " Input error\n\n";
var str_err_addrrange1 = "BŁĄD: Nieprawidłowy adres (pierwsza liczba)";
var str_err_addrrange2 = "BŁĄD: Nieprawidłowy adres (druga liczba)";
var str_err_addrrange3 = "BŁĄD: Nieprawidłowy adres (trzecia liczba)";
var str_err_addrlast   = "BŁĄD: Nieprawidłowy adres (ostatnia liczba)"
var str_err_addr       = "BŁĄD: Niepoprawny adres!";
var str_err_value      = "BŁĄD: Niewłaściwa wartość!";
var str_err_pctime     = "Czas komputera jest nieprawidłowy. Możesz ustawić datę z zakresu 1970-01-01 do 2036-12-31";
var str_err_dateformat = "BŁĄD: Niewłaściwy format Daty";
var str_err_dfinput    = "Możesz użyć tylko formatu rrrr-mm-dd";
var str_err_reinputd   = "BŁĄD: Data jest niepoprawna, wprowadź ponownie";
var str_err_invaildtmf = "BŁĄD: Niewłaściwy format Daty";
var str_err_timeformat = "Możesz użyć tylko formatu rrrr-mm-dd";
var str_err_imvaildtm  = "BŁĄD: Niewłaściwy format Czasu";
var str_err_key        = "BŁĄD: Długość klucza WEP jest niewłaściwa. Dla dużych i małych liter z liczbami dopuszczalna długość to od 10 do 26 znaków; Dla dużych i małych liter, bez cyfr to od 5 do 13 znaków. NIE UŻYWAJ ZNAKÓW SPECJALNYCH!";
var str_err_ssid       = "BŁĄD: SSID Sieci jest niepoprawny, zawiera niedopuszczalne znaki";
var str_err_rekey      = "BŁĄD: Hasła WiFi nie są takie same!";
var str_err_ssid       = "BŁĄD: SSID Sieci jest niepoprawny, zawiera niedopuszczalne znaki";
var str_err_ip2gateway = "BŁĄD: Adres IP i adres Bramy nie należą do tego samego segmentu Sieci!";
var str_err_volume     = "Poziom Głośności poza zakresem. Popraw wartości w granicach dopuszczalnego zakresu (1-100)";
var str_err_username   ="BŁĄD: Nazwy Użytkownika nie mogą być takie same!"; 
var str_err_nameerr    ="Nazwa Użytkownika może zawierać tylko litery i cyfry";
var str_err_nousername     = "Wprowadź Nazwę Użytkownika";
var str_error_none         ="Uups... Wystąpił nieznany błąd :(";
var str_error_server       ="Nie można nawiązać połączenia z Serwerem";
var str_error_namepwd      ="BŁĄD: Niepoprawne dane logowania!";
var str_error_dir          ="BŁĄD: Nieprawidłowa ścieżka!";
var str_error_ssl          ="Nieprawidłowe ustawienia SSL";


var str_bps32_2048 = "Zakres Bitrate Pierwszego Strumienia to 32-2048 kbps";
var str_bps32_512  = "Zakres Bitrate Drugiego Strumienia to 32-512 kbps";
var str_bps32_256  = "Zakres Bitrate Trzeciego Strumienia to 32-256 kbps";

//range
var str_1_65535 = "1-65535";
var str_1_223_127 =" Zakres od 1 do 223, nie może być 127";
var str_0_255   = " Zakres od 0 do 255";
var str_1_255   = " Zakres od 1 do 255";
var str_0_254   = " Zakres od 0 do 254";
var str_1_254   = " Zakres od 1 do 254";
var str_80or1024_49151 = "(80 lub 1024 - 49151)";
var str_554or1024_49151 = "(554 lub 1024 - 49151)";
var str_1935or1024_49151 = "(1935 lub 1024 - 49151)";
var str_daterange  = "Możesz ustawić datę z zakresu 1970-01-01 do 2036-12-31, proszę poprawić ustawienia";
var str_drange  = "(1971-01-01 - 2036-12-31)";

//no ins
var str_noins0 = "Dlaczego widzisz tą stronę?";
var str_noins1 = "1. Kontrolka ActiveX nie została zainstalowana.";
var str_noins2 = "2. Kontrolka została zainstalowana, jednakże urządzenie wymaga zainstalowania zaktualizowanej wersji ActiveX, którą musisz pobrać.";
var str_noins3 = "3. Nie masz połączenia z Internetem.";
var str_noins4 = "Kliknij";
var str_noins5 = "Pobierz ActiveX";
var str_noins6 = "następnie kliknij";
var str_noins7 = "Uruchom";
var str_noins8 = "w wyskakującym okienku, aby zainstalować wymaganą wersję kontrolki ActiveX. Po instalacji odśwież stronę aby wyświetlić podgląd.";

//in common use
var str_readonly  = "Tylko do odczytu";
var str_rate      = "Prędkość";
var str_auto      = "Auto";
var str_view      = "Strumień";
var str_minute    = "min.";
var str_stream    = "Strumień";
var str_1ststream = "Pierwszy";
var str_2ndstream = "Drugi";
var str_3thstream = "Trzeci";
var str_on        = "Wł.";
var str_off       = "Wył.";
var str_online    = "Połączono";
var str_offline   = "Brak połączenia";
var str_sec       = "sek."
var str_language_ex  = "Język";
var str_ch_ex        = "Chinese";
var str_en_ex        = "English";
var str_fr_ex        = "Français";
var str_de_ex        = "Deutsch";
var str_it_ex        = "Italiano";
var str_sp_ex        = "Español";
var str_ru_ex        = "русский язык";
var str_ja_ex        = "日本語";
var str_kr_ex        = "Korean";
var str_pl_ex        = "Polski";
var str_language  = "język";
var str_chinese   = "chiński";
var str_english   = "angielski";
var str_francaise = "Francuski";
var str_deutsch   = "Niemiecki";
var str_italiano  = "Włoskie";
var str_spanish   = "Hiszpański";
var str_russian   = "Rosyjski";
var str_japan    = "Japoński";
var str_korean   = "Koreański";
var str_poland    = "Polski";
var str_add       = "Działania";
var str_encrypt   = "Szyfrowanie";
var str_authen    = "Uwierzytelnianie";
var str_connetm   = "Typ Sieci";
var str_channel   = "Kanał";
var str_confirm   = "Połącz"; 
var str_purview   ="Purview"; 

//time zone
var str_GMT1  = 'International Date Line West';
var str_GMT2  = 'Samoa';
var str_GMT3  = 'Hawaii';
var str_GMT4  = 'Alaska';
var str_GMT5  = 'Pacific Time (U.S. and Canada)';
var str_GMT6  = 'Chihuahua,';
var str_GMT7  = 'Mountain Time (U.S. and Canada)';
var str_GMT8  = 'Arizona';
var str_GMT9  = 'Saskatchewan';
var str_GMT10 = 'Guadalajars,Mexico City,Monterrey';
var str_GMT11 = 'Central Time (U.S. and Canada)';
var str_GMT12 = 'Central America';
var str_GMT13 = 'Indians (East)';
var str_GMT14 = 'Eastern Time (U.S. and Canada)';
var str_GMT15 = 'Bogota,Lima,Quita';
var str_GMT16 = 'Carcacas';
var str_GMT17 = 'Santiago';
var str_GMT18 = 'Atlantic Time (Canada)';
var str_GMT19 = 'Newfoundland';
var str_GMT20 = 'Montevideo';
var str_GMT21 = 'Buenos Aires';
var str_GMT22 = 'Brasilia';
var str_GMT23 = 'Mid-Atlantic';
var str_GMT24 = 'Cape Verde Islands';
var str_GMT25 = 'Azores';
var str_GMT26 = 'Dublin,Edinburgh,Lisbon,London';
var str_GMT27 = 'Casablance';
var str_GMT28 = 'Amsterdam,Berlin,Bern,Rome,Stockholm,Vienna';
var str_GMT29 = 'Belgrade,Bratislava,Budapest,Ljubljana,Prague';
var str_GMT30 = 'Brussels,Copenhagen,Madrid,Paris';
var str_GMT31 = 'Warszawa,Sarajevo,Skopje,Zagreb';
var str_GMT32 = 'West Central Africa';
var str_GMT33 = 'Athens,Bucharest,Istanbul';
var str_GMT34 = 'Bucharest';
var str_GMT35 = 'Cairo';
var str_GMT36 = 'Harare,Pretoria';
var str_GMT37 = 'Helsinki,Kyiv,Riga,Sofia,Vilnius,Talinn';
var str_GMT38 = 'Jerusalem';
var str_GMT39 = 'Baghdad';
var str_GMT40 = 'Kuwait,Riyadh';
var str_GMT41 = 'Moscow,St.Petersburg,Volgograd';
var str_GMT42 = 'Nairobi';
var str_GMT43 = 'Tehran';
var str_GMT44 = 'Abu_Dhabi,Muscat';
var str_GMT45 = 'Baku';
var str_GMT46 = 'Kabul';
var str_GMT47 = 'Yekaterinburg';
var str_GMT48 = 'Islamabad,Karachi';
var str_GMT49 = 'Chennai,Kolkata,Mumbai,New Delhi';
var str_GMT50 = 'Katmandu';
var str_GMT51 = 'Novosibirsk';
var str_GMT52 = 'Dhaka';
var str_GMT53 = 'Astana';
var str_GMT54 = 'Rangoon';
var str_GMT55 = 'Bangkok,Hanoi,Jakarta';
var str_GMT56 = 'Krasnoyarsk';
var str_GMT57 = 'Beijing,Chongqing,Hong Kong,Urumqi';
var str_GMT58 = 'Irkutsk';
var str_GMT59 = 'Kuala Lumpur,Singapore';
var str_GMT60 = 'Perth';
var str_GMT61 = 'Taipei';
var str_GMT62 = 'Osaka,Sapporo,Tokyo';
var str_GMT63 = 'Seoul';
var str_GMT64 = 'Yakutsk';
var str_GMT65 = 'Adelaide';
var str_GMT66 = 'Brisbane';
var str_GMT67 = 'Canberra,Melbourne,Sydney';
var str_GMT68 = 'Guam,Port Moresby';
var str_GMT69 = 'Hobart';
var str_GMT70 = 'Vladivostok';
var str_GMT71 = 'Magadan';
var str_GMT72 = 'Auckland,Wellington';
var str_GMT73 = 'Fiji';
var str_GMT74 = 'Nuku_alofa';


//query
var str_ask_sdfat32    = "Karta SD zostanie sformatowana do FAT32. Czy na pewno chcesz sformatować?";
var str_ask_sdstop     = "Karta SD zostanie odłączona do ponownego uruchomienia kamery. Na pewno odłączyć?";
var str_ask_recoverbak = "UWAGA: Ustawienia zostaną przywrócone do wartości fabrycznych. Kontynuować?";
var str_ask_syspath    = "Wprowadź ścieżkę pliku";
var str_ask_upgradesys = "UWAGA: Oprogramowanie urządzenia zostanie zaktualizowane. Kontynuować?";
var str_ask_reboot     = "UWAGA: Urządzenie zostanie uruchomione ponownie. Kontynuować?";
var str_ask_recoverdef = "UWAGA: Konfiguracja urządzenia zostanie przywrócona z kopii. Kontynuować?";


/// display
var str_adjustneff  = "(Ustawienia trybu nocnego)";
var str_nightmode   = "Tryb nocny";
var str_adjustnl    = "Ustawienia światła nocnego";
var str_nlight      = "Światło nocne";
var str_brightness  = "Jasność";
var str_saturation  = "Nasycenie";
var str_contrast    = "Kontrast";
var str_sharpness   = "Ostrość";
var str_hue         = "Odcień";
var str_shutter     = "Migawka";
var str_ldcratio    = "Zakrzywienie";
var str_ae          = "AE";
var str_targety     = "Ekspozycja";
var str_gamma       = "Gamma";
var str_dnt         = "Czułość";
var str_lumi        = "Oświetlenie";
var str_imageset    = "Ustawienia Obrazu";
var str_updown      = "Odbij Poziomo";
var str_leftright   = "Odbij Pionowo";
var str_wdr     = "WDR";
var str_onmode      ="Tryb";
var str_mode        ="Tryb";
var str_black       =" Nocny";
var str_color       =" Dzienny";
var str_aemode      ="Tryb AE";
var str_auto        ="Auto";
var str_indoor      ="Wewnątrz";
var str_outdoor     ="Na zewnątrz";
var str_imgmode     ="Tryb Obrazu";
var str_framerate1   ="Liczba klatek";
var str_inance      ="Poziom światła";
var str_ircut       ="Filtr IR";
var str_ircutye     ="(Zakres: 1-1024. Czułość przełączania filtra; im mniejsza wartość tym szybsza reakcja filtra)";
var str_sensitivity = "Czułość";
var str_wdrmode     = "WDR";
var str_wdrvalue    = "Siła WDR";
var str_lightmode     = "Tryb oświetlenia";
var str_changing      = "Przyciemnianie";
var str_manual       = "Ręczne";
var str_lightness    = "Szybkość";
var str_window      = "Obszar";
var str_safetype    = "Security mode";
var str_encway      = "WPA Algorithm"; 
var str_key         = "Key";
var str_confirmkey  = "Re-type key";
var str_checkwl     = "Check  Wireless Setup";
var str_hwctrl      = "Ustaw. Podczerwieni";
var str_noise       = "Szum";
var str_noisetye   = "(Zakres: 0-100. Redukcja poziomu szumu)";
var str_lamp       = "Oświetlenie nocne";
var str_lamp0       = "Normalne";
var str_lamp1       = "Pełen kolor";
var str_lamp2       = "Inteligentne";

// wireless
var str_wlenable    = "Włącz WiFi";
var str_conmode     = "Tryb";
var str_route       = "Infrastruktury";
var str_p2p         = "Point to Point";

var str_welcome     = "Wybierz co chcesz zrobić:";
var str_pcview      = "Podgląd przez przeglądarkę";
var str_mbview      = "Podgląd na smartfon";
var str_setupsoft   = "Zainstaluj wtyczkę ActiveX (Wtyczka musi być zainstalowana, aby konfiguracja przez przeglądarkę była możliwa)";

var str_sd          ="KARTA SD";
var str_snap        ="ZDJĘCIE";
var str_record      ="NAGRAJ";
var str_playback    ="ODTWÓRZ";
var str_up          ="W górę";
var str_down        ="W dół";
var str_right       ="W prawo";
var str_left        ="W lewo";
var str_center      ="Wyśrodkuj";
var str_ud          ="Patrol Góra-Dół";
var str_lr          ="Patrol Lewo-Prawo";
var str_preset       ="Punkt";
var str_zoomin      ="Zoom +";
var str_zoomout     ="Zoom -";
var str_focusin      ="Ostrość +";
var str_focusout     ="Ostrość -";
var str_posset         ="Ustaw";
var str_poscall        ="Wywołaj";
var str_refresh     ="Odśwież";
//gb28181
var str_err_svrport    ="Zakres portów to od 1 do 65535.";
var str_gb28181      ="GB28181";
var str_gb_gb28181   ="GB28181";
var str_svrid        ="ID Serwera";
var str_svrip        ="IP Serwera";
var str_svrport      ="Port Serwera";
var str_devid        ="ID Urządzenia";
var str_devport      ="Port Urządzenia";
var str_devpwd       ="Hasło Urządzenia";
var str_alarmid      ="ID Alarmu";
var str_heartcycle   ="Cykl serca";
var str_heartcount   ="Maksymalny czas bicia serca";
var str_regtime      ="Ważność rejestracji";

//Multiple settings
var str_addport ='Urządzenia Równoległe';
var str_addportset ='Urządzenia Równoległe';
var str_local_host = "Sprzętowe";
var str_refesh = "Odśwież";
var str_local_network = "Szukaj w LAN";
var str_first_dev = "Urządzenie 1";
var str_second_dev = "Urządzenie 2";
var str_third_dev = "Urządzenie 3";
var str_fourth_dev = "Urządzenie 14";
var str_fifth_dev = "Urządzenie 5";
var str_sixth_dev = "Urządzenie 6";
var str_seventh_dev = "Urządzenie 7";
var str_eighth_dev = "Urządzenie 8";
var str_ninth_dev = "Urządzenie 9";
var str_add = "Dodaj";
var str_remove = "Usuń";
var str_set = "Zapisz";
var str_cancel= "Anuluj";
var str_none = 'Brak';
var str_overlay_name='Nazwa:';
var str_ip_address='IP:';
var str_http_port='Port:';
var str_user_name='Login:';
var str_user_psw='Hasło:';
var str_anonymous = '';
var str_err_selected ="Nie odnaleziono urządzenia pod wskazanym adresem. Wybierz inne urządzenie!";
var str_err_hostnum  ="Wybierz urządzenie aby nim zarządzać";

//wifi_mode
var str_wifi_mode ='Tryb Wifi';
var str_wifimode ='Tryb';
var str_wifi_speed ='Prędkość';
var str_wifi_channel ='Kanał';
var str_wifi_power ='Sygnał';
var str_wifimode0='None-Modulated Continuous TX Mode';
var str_wifimode1='Modulated Continuous TX Mode';
var str_wifimode2='Continuous RX Mode';

//4G
var str_4gset ='Ustawienia 4G';
var str_4grunmode ='Tryb APN';
var str_4gauto ='Auto';
var str_4gmanual ='Ręczne';
var str_4gapn ='APN';
var str_4gsimcard ='Karta SIM';
var str_4gversion ='Wersja Modułu';
var str_4gquality ='Jakość Sygnału';
var str_4gmcc ='Kod Kraju';
var str_4gmnc ='Kod Sieci';
var str_4gstatus ='Kod statusu';
var str_4gauthtype ='Szyfrowanie';
var str_4gcarrier ='Operator';
var str_4gimei ='IMEI';
var str_4giccid ='ICCID';

//restart timer
var str_restarttime="Auto-Restart";
var str_oclock="godzina";

//Tmall Genie
var str_tmall="Tmall Genie";

//Amazon Echo
var str_amazon="Amazon Echo";