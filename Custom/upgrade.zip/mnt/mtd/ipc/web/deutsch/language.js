﻿// JavaScript Document
//punct
var colon    = ":";
var period   = ".";
var comma    = ",";
var blank    = "&nbsp;";
var exclamation = "!";

//deviceinfo
var str_devname = "Geräte-ID";
var str_devtype = "Gerätetyp";
var str_netstat = "Netzwerkverbindung";
var str_connnum = "Aktueller Client";
var str_softver = "Software-Version";
var str_webware = "Webware-Version";
var str_rs485ver   = "PTZ-Version";
var str_macaddr = "Mac-Adresse";
var str_ipaddr = "IP-Adresse";
var str_submask = "Subnetzmaske";
var str_gateway = "Gateway";
var str_1stdns = "Primäres DNS";
var str_2nddns = "Sekundäres DNS";
var str_upnpstatus = "UPnPstatus";
var str_facddnsstatus = "Hersteller-DDNS-Status";
var str_th3ddnsstatus = "Drittanbieter-DDNS-Status";
var success = "Erfolg";
var unenable = "Unbenennbar";
var fail = "Fehlgeschlagen";
var str_sysstart = "Startzeit";
var str_sdstat = "SD-Status";
var str_connwireless = "WiFi";
var str_connwired = "LAN";
var str_conn4g     = "4G";
var str_dnsset = "DNS-Konfigurationstyp";
var str_manualdns = "Manuelles DNS";
var str_autodns = "Vom DHCP-Server";
var str_httpport = "HTTP-Portnummer";
var str_rtspport = "RTSP-Port";
var str_rtmpport = "RTMP-Port";
var str_rtspauth = "RTSP-Berechtigungsprüfung";
var str_cap_cvbs = "CVBS-Einstellung";
var str_cloud = "Cloud-Einstellung";
var str_cloudstat = "Cloud-Status";
var str_notpurchased = "Not Purchased";
var str_retention = "Tage der Aufbewahrung"
var str_exptime = "Expiration Time";

//Terminal
var str_addrcode = "Adresse";
var str_protocol = "Protokoll";
var str_portset = "Com-Einstellung";
var str_485portset = "485 Com-Einstellung";
var str_485set = "485 Einstellung";
var str_baudrate = "Baudrate";
var str_databit = "Datenbit";
var str_stopbit = "Stoppbit";
var str_check = "Überprüfungstyp";
var str_none = "Keine";
var str_oddcheck = "Ungerade";
var str_evencheck = "Gerade";
var str_tiltscope = '(1-50)';
var str_tiltno = 'Kreuzfahrten können nicht leer sein';
var tilttes = "PTZ-Geschwindigkeit";
var tiltnum = "Kreuzfahrt-Runden";
var tiltmunmax = "Kreuzfahrt-Reichweite: 1-50";
var tiltcenter = "Bei Selbstprüfung zentriert";
var str_speed0 = "Schnell";
var str_speed1 = "Mittel";
var str_speed2 = "Langsam";
var str_ptzalarm = "Den PTZ-Bewegungsalarm schließen";
var str_lenmodetip = 'Anzeigemodus';
var str_lenmode1 = 'Immer beleuchtet';
var str_lenmode2 = 'Immer gelöscht';
var str_smartrack="Smart Track";

//FTP 
var str_pasvmode = "Passiver Modus";
var str_ftppic_name = "Schnappschuss-Name";
var str_time_name = "Zeit-Name";
var str_fixed_name = "Fester Name";
var str_alampic_name = "Name des Alarm-Schnappschusses";
var str_timepic_name = "Name des Zeit-Schnappschusses";
var str_filename_set = "Dateiname-Einstellung";
var str_autocreatedir = "Verzeichnis automatisch erstellen";

//Server
var str_server = "Server-Adresse";
var str_port = "Serverport";
var str_username = "Benutzername";
var str_password = "Passwort";
var str_repassword = "Passwort erneut eingeben";
var str_auth = "Authentifizierung";
var str_ftp_path = "Pfad";
var str_ftp_test = "FTP-Einstellungen testen";
var str_email_test = "E-Mail-Einstellungen testen";

//Email
var str_emailset = "E-Mail-Einstellung";
var str_smtpserv = "SMTP-Servername:";
var str_sendto = "Senden an";
var str_emailaddr = "E-Mail-Adresse"
var str_sendaddr = "Absender";
var str_subject = "Betreff";
var str_info = "Nachricht";
var str_max127c = "Die maximale Länge beträgt 127";
var str_safelink = "Sichere Verbindung";
var str_massl0 = "Keine";
var str_massl1 = "SSL";
var str_massl2 = "TLS";
var str_massl3 = "STARTTLS";

// Auto-Schnappschuss
var str_timeint = "Schnappschuss-Intervall";
var str_sendemail = "E-Mail senden";
var str_savepic = "Bild auf SD-Karte speichern";
var str_ftpsnap = "Bild auf dem FTP-Server speichern";
var str_cloudsnap  = "Bild auf dem Cloud-Server speichern";

// Aufnahmeeinstellung
var str_recsetup = "Datensatzeinstellung";
var str_recfile = "Dauer der aufgezeichneten Dateien";
var str_recplan = "Geplante Aufzeichnung";
var str_allday = "Daueraufnahme";
var str_allclear = "Keine Aufzeichnung";
var str_timearea = "Festgelegte Zeitaufzeichnung";
var str_recswitch = "Ob Aufnahme geöffnet werden soll";
var str_all_area = 'Liste auswählen';
var str_no_area = 'Liste löschen';
var str_recformat = 'Aufzeichnungsformat';

//Alarm
var str_offenon = "Öffnen";
var str_offenoff = "Schließen";
var str_alarmex = "Externer Alarm";
var str_alarmimode = "Externer Alarmmodus";

//audio alarm
var str_alarmaudio = "Audioalarm";
var str_audiorange = "Volumenbereich";

//smd
var str_alarmsmd ="Humanoider Alarm";
var str_smdrecognition ="Intelligente humanoide Erkennung";
var str_smdthreshold ="Schwelle";
var str_smdrect ="Rahmen menschliche Form";

//Audio
var str_audioset = "Audioeinstellungen";
var str_collecta = "Audiosammlung";
var str_auformat = "Audiotyp";
var str_audioin = "Eingabemodus";
var str_volumein = "Eingangsvolumen";
var str_volumeout = "Ausgabevolumen";
var str_inoption = "Audio-Eingabe";
var str_intype = "Eingabetyp";
var str_aumicin = "MIC";
var str_aulinein = "Lineareingabe";

//Zeit
var str_timenow = "Aktuelles Datum und Uhrzeit";
var str_timedev = "Datumszeit des Geräts";
var str_change = "Anpassen";
var str_manualset = "Manuelle Einstellung";
var str_date = "Datum";
var str_time = "Zeit";
var str_dateformat = "(jjjj-mm-tt)";
var str_timeformat = "(ss: mm: ss)";
var str_daterange = "(1971-01-01 ~ 2036-12-31)";
var str_syncfrompc = "Mit Computerzeit synchronisieren";
var str_syncfrompc1 = "Mit PC-Zeit synchronisieren";
var str_pctime = "PC-Zeit";
var str_ntserver = "Netzwerkzeitprotokoll";
var str_ntpserver = "NTP-Server";
var str_synctime = "Intervall";
var str_hour = "Stunden";
var str_keeptmset = "Aktuelle Einstellung beibehalten";
var str_timezone = "Zeitzone";
var str_autotime = "Zeit automatisch anpassen";

//Video
var str_videoset = "Videoeinstellungen";
var str_videomode = "Videoformat";
var str_videocoding = "Videocodierung";
var str_resolution = "Auflösung";
var str_streamrate = "Bitrate";
var str_framerate = "Maximale Bildrate";
var str_framegap = "Hauptbildintervall";
var str_vcodectrl = "Bitratensteuerung";
var str_fixedcr = "CBR";
var str_variablecr = "VBR";
var str_vcodequa = "Bildqualität";
var str_osdset = "OSD-Einstellung";
var str_osdopt = "Parenthese-Optionen";
var str_osdtime = "Zeitstempel";
var str_osdname = "Name der Kamera";
var str_name = "Name";
var str_maxchn = "Größter Videocodierungskanal";
var str_colour = "Farbe";
var str_timeshow = "Zeit-Anzeige";
var str_nameshow = "Name-Anzeige";
var str_tl = "OBEN links";
var str_tr = "OBEN rechts";
var str_bl = "Unten links";
var str_br = "Unten rechts";

//Plattform
var str_plcon = "Aktivieren";
var str_puidnum = "PUID";
var str_asp = "Zugang zum Serverport";
var str_asa = "Adresse des Serverzugriffs";
var str_fsp = "Serverport weiterleiten";
var str_fsa = "Serveradresse weiterleiten";
var str_gpsi = "GPS-Informationsübertragungsintervall";
var str_msec = "(Millisekunde)";
var str_loginid = "Geräte-ID";
var str_loginpass = "Passwort";
var str_serverport = "Port";
var str_serveraddr = "Server";
var str_timeout = "Timeout";
var str_constate = "Verbindungsstatus";
var str_devnum = "Geräte-ID";
var str_dvsn = "Seriennummer";
var str_atransfer = "Audioübertragung";
var str_alarmtrans = "Alarminformationsübertragung";
var str_uid = "UID";
var str_server1 = "Server 1";
var str_server2 = "Server 2";
var str_server3 = "Server 3";
var str_server4 = "Server 4";

// Onvif
var str_onvifenable = "Onvif";
var str_offcheck = "Keine Prüfung";
var str_timecheck = "Zeitzoneneinstellungen";
var str_videocheck = "Bildeinstellungen";
var str_allow = "Zulassen";
var str_prohibit = "Verbieten";
var str_onvifchn = "Subcode-Umlaufweg";
var str_onvifsnap = "Kanal erfassen";
var str_onvifnvctype = "NVC-Typ";
var str_normal = "Normal";
var str_uniview = "Uniview";

//Alarm
var str_emailalarm = "E-Mail-Alarm und Bild senden";
var str_sendpic = "Bild senden";
var str_saverecftp = "Video auf dem FTP-Server speichern";
var str_relayout = "Weiterleiten";
var str_savevideo = "Video auf SD-Karte speichern";
var str_cloudrecord  = "Cloud-Server-Einstellung";
var str_ftpservset = "FTP-Server-Einstellung";
var str_alarmplan = "Zeitalarm";
var str_alarmday = "Allzeitalarm";
var str_alarmclear = "Keiner Alarm";
var str_alermarea = "Alarm für vorgegebene Uhrzeit";
var str_mdalarm_type    ="Alarm Trigger";
var str_mdalarm_single    ="Separate trigger";
var str_mdalarm_union    ="Linkage trigger";
var str_linkset = "Verknüpfungseinstellung";
var str_snapset = "Bilder erfassen";
var str_snapnum = "Bilderfassungsnummer";
var str_alarmpreset = "Voreinstellung der Verknüpfung";
var str_alarmsound = "Verbindungston";
var str_alarmbell = "Alarm";
var str_alarmdog = "Hund";
var str_alarmcustom = "Benutzerdefiniert";

//Netzwerk
var str_manualip = "Feste IP-Adresse";
var str_autoip = "Dynamische IP-Adresse";
var str_lnset = "LAN-Einstellungen";
var str_ipget = "IP-Konfigurationstyp";
var str_internetip = "Internet-IP-Adresse";
var str_netip = "Internet-IP-Adresse";
var str_proddnsset = "Haupt-DDNS";
var str_hostname = "Ihre Domäne";
var str_3thdnsset = "Das 3. DDNS";
var str_servprov = "Anbieter";
var str_autoupnp = "UPnP-Portweiterleitung";
var str_wlcheck = "Drahtlos-Einstellung überprüfen";
var str_wlsuccess = "Erfolgreich mit WLAN verbunden.";
var str_applywl = "Wählen Sie  &quot; Übernehmen Sie &quot; um diese Einstellungen zu speichern.";
var str_wlfailed = "WiFi-Verbindung fehlgeschlagen.";

//Zeitplan
var str_weekmode = "Wochenmodus verwenden";
var str_weekendmode = "Arbeitsmodus verwenden";
var str_alltimemode = "Zeitmodus";
var str_week = "Tag";
var str_begintime = "Start";
var str_endtime = "Ende";
var str_workday = "Arbeitstag";
var str_freeday = "Wochenende";
var str_everyday = "Jeden Tag";
var str_sunday = "Sonntag";
var str_monday = "Montag";
var str_tuesday = "Dienstag";
var str_wednesday = "Mittwoch";
var str_thursday = "Donnerstag";
var str_friday = "Freitag";
var str_saturday = "Samstag";

//Navigation
var str_rtview = "Überwachen";
var str_config = "Einstellungen";
var str_avargs = "Medien";
var str_videoa = "Video";
var str_imagea = "Bild";
var str_audioa = "Audio";
var str_netset = "Netzwerk";
var str_wlset = "Drahtlos";
var str_ddnsset = "Ddns";
var str_plset = "Plattform";
var str_onvif = "ONVIF";
var str_p2pset = "P2P";
var str_alarmset = "Alarm";
var str_alarmin = "Alarm in";
var str_mdset = "Bewegungserkennung";
var str_alaction = "Alarm";
var str_altime = "Zeitplan";
var str_advset = "Erweitert";
var str_userset = "Benutzer";
var str_timesnap = "Auto-Schnappschuss";
var str_timerec = "Timer-Aufnahme";
var str_email = "E-Mail";
var str_ftpset = "FTP";
var str_ptzset = "Terminal";
var str_sysset = "System";
var str_timeset = "Zeit";
var str_initset = "Initialisieren";
var str_devinfo = "Geräteinformationen";
var str_systemlog = "Systemprotokoll";
var str_videoshade = "Videofarbe";

// sd op
var str_sdview = "Browser-SD-Karte";
var str_sdfat32 = "SD-Karte als Fat32 formatieren";
var str_sdstop = "SD-Karte entfernen";

// sd stat
var str_havesd = "Karte";
var str_nothavesd = "Keine Karte";
var str_freespace = "freier Speicherplatz"
var str_totalspace = "Gesamtspeicherplatz"

// Systemsicherung
var str_reboot = "Neustart";
var str_recoverdef = "Werkseinstellung";
var str_backup = "Einstellungsdaten sichern";
var str_recoverbak = "Wiederherstellen";
var str_upgradesys = "Aktualisieren";
var str_lenstype = "Linsentyp";

//Taste
var str_btn_reboot     = "&nbsp; Neustart&nbsp;";
var str_btn_save       = "&nbsp; Speichern&nbsp;";
var str_btn_confirm    = "&nbsp;Okay&nbsp;";
var str_btn_query      = "&nbsp; Aufweisen&nbsp;";
var str_btn_advanced   = "&nbsp; Erweitert&nbsp;";
var str_btn_recoverdef = "Werkseinstellung";
var str_btn_apply      = "&nbsp;Übernehmen&nbsp;";
var str_btn_cancel     = "Abbrechen";
var str_btn_clear      = "&nbsp; Löschen&nbsp;";
var str_btn_default    = "Standard";
var str_btn_search     = "&nbsp;Suche&nbsp;";
var str_btn_check      = "&nbsp; Überprüfen&nbsp;";
var str_btn_close      = "&nbsp;Schließen&nbsp;";
var str_btn_refresh    = "&nbsp;Aktualisieren&nbsp;";
var str_btn_test       = "Testen";
var str_btn_cleanlog   = "Protokoll löschen";

// Prompt
var str_note_upgrade = "&nbsp; IP-Kamera wird aktualisiert, bitte schalten Sie die Kamera nicht aus.";
var str_note_upgradeok = "IP-Kamera-Aktualisierung erfolgreich!";
var str_note_needreset = "Hinweis: Ändern Sie die Einstellungen. Das System wird automatisch neu gestartet";
var str_note_needreset0 = "(Hinweis: Ändern Sie die Einstellungen. Das System wird automatisch neu gestartet)";
var str_note_needreset1 = "Hinweis: Einstellungen ändern, Gerät neu starten";
var str_note_needreset2 = "(Hinweis: Ändern Sie die Einstellungen, starten Sie das Gerät neu)";
var str_note_astreamnote = "(Mobil)";
var str_note_wlsetting = "WiFi wird überprüft, bitte warten Sie etwa 30 Sekunden.";
var str_note_inputpath = "Bitte geben Sie den Dateipfad ein";
var str_note_inputipaddr = "Bitte geben Sie die IP-Adresse ein";
var str_note_inputsubmask = "Bitte geben Sie die Adresse der Subnetzmaske ein";
var str_note_inputgateway = "Bitte geben Sie die Gateway-Adresse ein";
var str_note_inputhostname = "Bitte geben Sie die Domäne ein";
var str_note_inputusername = "Bitte geben Sie den Benutzernamen ein";
var str_note_inputpassword = "Bitte geben Sie das Passwort ein";
var str_note_inputport = "Bitte Server-Port eingeben";
var str_note_inputpath = "Bitte geben Sie den Stammpfad ein ./";
var str_note_testtitle = "Bitte zuerst einstellen und dann testen.";
var str_note_inputservaddr = "Bitte geben Sie die Serveradresse ein";
var str_note_inputservname = "Bitte geben Sie den Servernamen ein";
var str_note_inputemail = "Bitte geben Sie die E-Mail-Adresse ein";
var str_note_inputsendaddr = "Bitte geben Sie die Adresse des Absenders ein";
var str_note_inputasp = "Bitte Server-Port eingeben";
var str_note_inputasa = "Bitte geben Sie die Zugangsadresse ein";
var str_note_inputfsp = "Bitte geben Sie Port des Weiterleitungsservers ein";
var str_note_inputfsa = "Bitte geben Sie die Adresse des Weiterleiters ein";
var str_note_inputtimeout = "Bitte geben Sie den Timeout-Wert ein";
var str_note_inputgpsi = "Bitte geben Sie das GPS-Informationsübertragungsintervall ein";
var str_note_noinpublicip = "Internet-IP-Adresse: NULL";
var str_note_internetipis = "Internet-IP-Adresse:";
var str_note_vcodequa = "(Je kleiner der Wert ist, desto besser ist die Bildqualität und desto besser ist der Fluss.)";
var str_note_mbsize = "Auflösung von bewegten Bildern";
var str_note_mdoff = "Hinweis: Die Bewegungserkennung wird deaktiviert, wenn der erste Stream 320x176 ist.";
var str_note_maxframerate = "Die Frameraten liegen über 25.";
var str_note_maxbps = "Bitratenbereich ist 32-6144.";
var str_note_maxbps1 = "Bitratenbereich ist 32-8192.";
var str_note_maxbps2 = "Bitratenbereich ist 32-2048.";
var str_note_maxbps3 = "Bitratenbereich ist 32-512.";
var str_note_maxbps4 = "Bitratenbereich ist 32-256.";
var str_note_atransfer = "(Rufen Sie vor dem Öffnen der Audioübertragung die Seite mit den Audio- und Videoeinstellungen auf. Setzen Sie den zweiten Audiostream auf den Modus Einschalten, AMR-Format)";
var str_note_ipportchange = "IP oder Port wurde geändert, bitte erneut verbinden";
var str_note_rhportsame = "http und rtsp verwenden denselben Port";
var str_note_inputdate = "Bitte geben Sie das Datum ein";
var str_note_inputtime = "Bitte geben Sie die Uhrzeit ein";
var str_note_routemode = "(Wählen Sie den Infrastrukturmodus aus, wenn Sie einen Drahtlos-Router verwenden.)";
var str_note_inputascii = "Bitte geben Sie ein ASCII-Zeichen ein (Länge 5 oder 13)";
var str_note_inputascii2 = "Bitte geben Sie ein ASCII-Zeichen ein (Länge zwischen 8 und 63)";
var str_note_inputhex = "Bitte geben Sie ein HEX-Zeichen ein (Länge 10 oder 26)";
var str_note_inputssid = "Bitte geben Sie die ssid ein";
var str_note_inputkey = "Bitte geben Sie den Schlüssel ein";
var str_note_inputrekey = "Bitte geben Sie den Bestätigungsschlüssel ein";
var str_note_nosupportp2p = "WPA / WPA2 unterstützt den Point-to-Point-Modus nicht.";
var str_note_turnoffmd = "Die Videoauflösung ist 320x176, die Bewegungserkennung ist deaktiviert";
var str_note_autoreboot = "Die Maschine wird neu gestartet!";
var str_test_success = "Test ...... Erfolg.";
var str_test_fail = "Test ...... Gescheitert.";
var str_note_mdalarmtype   = "(Für den Verbindungsauslösealarm müssen sowohl die Bewegungserkennung als auch der humanoide Alarm aktiviert sein.)";



//Fehler
var str_err_invaildc = "ungültiges Zeichen einfügen";
var str_err_invaildc2 = "ungültiges Zeichen einschließen. (&, =, \", \\\) ";
var str_err_username = "Benutzername-Fehler";
var str_err_hostname = "Hostname-Fehler";
var str_err_servname = "Servernamenfehler";
var str_err_password = "Passwortfehler";
var str_err_port = "Der Port ist fehlerhaft";
var str_err_userinfo = "Fehler bei der Benutzerinformation, bitte erneut eingeben";
var str_err_servbusy = "Server ist beschäftigt, bitte warten Sie einen Moment";
var str_err_addrcode = "Adresse außerhalb des Bereichs";
var str_err_port = "Portfehler"
var str_err_servaddr = "Ihre Adresse ist fehlerhaft";
var str_err_smptserv = "Der Port ist fehlerhaft";
var str_err_emailaddr = "Ungültige Adresse";
var str_err_tooshort = "Die Adresslänge muss größer als 5 sein";
var str_err_noat = "Die Adresse muss ein '@'  -Zeichen enthalten";
var str_err_addr1 = "Empfängeradresse ist Fehler";
var str_err_addr2 = "";
var str_err_addr3 = "";
var str_err_sendaddr = "Absenderadresse-Fehler";
var str_err_subject = "Betreff-Fehler";
var str_err_info = "Nachricht-Fehler";
var str_err_snapint = "Das Intervall sollte 5-86400 sein.";
var str_err_recfile = "Der Zeitbereich von 15 bis 900 Sekunden";
var str_err_recfile1 = "Der Zeitbereich von 15 bis 600 Sekunden";
var str_err_pwdconfirm = "Passwortfehler bestätigen.";
var str_err_framegap = "Hauptrahmen sind 2-300";
var str_err_gopframe   = "Key frame are less than framerate";
var str_err_osdname = "Anzahl der Wörter 'ist größer als 18.";
var str_err_noname = "Bitte geben Sie den Namen der Kamera ein";
var str_err_noblank = "Name darf nicht aus Leerzeichen bestehen";
var str_err_puid = "PUID-Fehler der Eingabe";
var str_err_asp = "Fehler beim Zugriff auf den Port des Servers";
var str_err_asa = "Fehler bei der Adressadresse";
var str_err_fsp = "Fehler beim Weiterleitungsserver-Port";
var str_err_fsa = "Fehler bei der Weiterleitungsadresse";
var str_err_username = "Benutzername-Fehler";
var str_err_timeout = "Fehler beim Zeitüberschreitungswert der Eingabe";
var str_err_tooutrange = "Zeitüberschreitung außerhalb des Bereichs";
var str_err_devnum = "Fehler bei der Eingabe der Geräte-ID";
var str_err_servaddr = "Serveradressenfehler";
var str_err_input = "Eingabefehler \ n \ n";
var str_err_addrrange1 = "Ungültige Adresse, die erste Zahl";
var str_err_addrrange2 = "Ungültige Adresse, die zweite Nummer";
var str_err_addrrange3 = "Ungültige Adresse, die dritte Nummer";
var str_err_addrlast = "Ungültige Adresse, letzte Zahl"
var str_err_addr = "Ungültige Adresse";
var str_err_value = "Ungültiger Wert";
var str_err_pctime = "Ihre PC-Zeit ist ungültig, die Zeit muss zwischen 1970-01-01 bis 2037-12-31 liegen";
var str_err_dateformat = "Ungültiges Datumsformat";
var str_err_dfinput = "Das Format muss JJJJ-MM-TT sein";
var str_err_reinputd = "Das Datum ist ungültig, bitte erneut eingeben";
var str_err_invaildtmf = "Ungültiges Datumsformat";
var str_err_timeformat = "Das Format muss ss: mm: ss sein";
var str_err_imvaildtm = "Ungültiges Zeitformat";
var str_err_key = "Wep-Schlüssellänge ist fehlerhaft. Hex ist 10 oder 26; ASCII ist 5 oder 13";
var str_err_ssid = "Ssid ist fehlerhaft, ungültiges Zeichen enthalten";
var str_err_rekey = "Der Bestätigungsschlüssel ist fehlerhaft";
var str_err_ssid = "Ssid-Fehler, ungültiges Zeichen enthalten";
var str_err_ip2gateway = "IP und Gateway befinden sich nicht im selben Netzwerksegment";
var str_err_volume = "Das Volume ist außerhalb des Bereichs (1-100), bitte zurücksetzen";
var str_err_username = "Der Benutzername darf nicht gleich sein";
var str_err_nameerr = "Benutzername darf nur Buchstaben und Zahlen enthalten";
var str_err_nousername = "Bitte geben Sie den Benutzernamen ein";
var str_error_none = "Ein unbekannter Fehler";
var str_error_server = "Verbindung zum Server kann nicht hergestellt werden";
var str_error_namepwd = "Falscher Benutzer oder Passwort";
var str_error_dir = "Pfadfehler";
var str_error_ssl = "SSL-Einstellungsfehler";


var str_bps32_2048 = "Die Bitrate des ersten Streams beträgt 32-2048 kbps";
var str_bps32_512 = "Die Bitrate für den ersten Stream beträgt 32-512 kbps";
var str_bps32_256 = "Die Bitrate des ersten Streams beträgt 32-256 kbps";

//Angebot
var str_1_65535 = "1-65535";
var str_1_223_127 = "Muss zwischen 1 und 223 und nicht 127";
var str_0_255 = "Muss zwischen 0 und 255";
var str_1_255 = "Muss zwischen 1 und 255";
var str_0_254 = "Muss zwischen 0 und 254";
var str_1_254 = "Muss zwischen 1 und 254"
var str_80or1024_49151 = "(80 oder 1024 - 49151)";
var str_554or1024_49151 = "(554 oder 1024 - 49151)";
var str_1935or1024_49151 = "(1935 oder 1024 - 49151)";
var str_daterange = "Das Datum muss zwischen 1971-01-01 bis 2036-12-31 liegen, bitte erneut eingeben";
var str_drange = "(1971-01-01 ~ 2036-12-31)";

// Kein Plugin
var str_noins0 = "Das Erscheinen dieser Seite zeigt:";
var str_noins1 = "1. Sie installieren dieses ActiveX-Steuerelement nicht.";
var str_noins2 = "2. Sie haben eine installierte Version des ActiveX-Steuerelements installiert, das Sie herunterladen müssen.";
var str_noins3 = "3. Sie müssen sich mit dem Internet verbinden.";
var str_noins4 = "Bitte klicken";
var str_noins5 = "ActivX herunterladen";
var str_noins6 = "Und klicken Sie auf";
var str_noins7 = "Aktivieren";
var str_noins8 = "Im Popup-Meldungsfeld, um dieses ActiveX-Steuerelement zu installieren, die Webseite zu aktualisieren, diese Webseite zu aktualisieren, ein Gerät zu starten und das Video anzuzeigen";

//Im allgemeinen Gebrauch
var str_readonly = "Nur Lesen";
var str_rate = "Rate";
var str_auto = "Auto";
var str_view = "View";
var str_minute = "Minuten";
var str_stream = "Stream";
var str_1ststream = "Erster Stream";
var str_2ndstream = "Zweiter Stresm";
var str_3thstream = "Dritter Stresm";
var str_on = "Ein";
var str_off = "Aus";
var str_online = "Online";
var str_offline = "Offline";
var str_sec = "Sekunde"
var str_language_ex = "Language";
var str_ch_ex = "Chinese";
var str_en_ex = "English";
var str_fr_ex = "Français";
var str_de_ex = "Deutsch";
var str_it_ex = "Italiano";
var str_sp_ex = "Español";
var str_ru_ex = "русский язык";
var str_ja_ex = "日本語";
var str_kr_ex    = "Korean";
var str_pl_ex    = "Polski";
var str_language = "Sprache";
var str_chinese = "Chinesisch";
var str_english = "Englisch";
var str_francaise = "Französisch";
var str_deutsch   = "Deutsch";
var str_italiano  = "Italienisch";
var str_spanish   = "Spanisch";
var str_russian   = "русский язык";
var str_japan    = "日本語";
var str_korean   = "Koreanisch";
var str_poland    = "Polski";
var str_add = "Aktion";
var str_encrypt = "Verschlüsseln";
var str_authen = "Authentizieren";
var str_connetm = "Netzwerktyp";
var str_channel = "Kanal";
var str_confirm = "Verbinden";
var str_purview = "Zuständigkeit";


//Zeitzone
var str_GMT1 = 'Internationale Datumszeile Westen';
var str_GMT2 = 'Samoa';
var str_GMT3 = 'Hawaii';
var str_GMT4 = 'Alaska';
var str_GMT5 = 'Pazifische Zeit (USA und Kanada)';
var str_GMT6 = 'Chihuahua';
var str_GMT7 = 'Bergzeit (USA und Kanada)';
var str_GMT8 = 'Arizona';
var str_GMT9 = 'Saskatchewan';
var str_GMT10 = 'Guadalajars, Mexiko-Stadt, Monterrey';
var str_GMT11 = 'Zentrale Zeit (USA und Kanada)';
var str_GMT12 = 'Zentralamerika';
var str_GMT13 = 'Inder (Osten)';
var str_GMT14 = 'Osterzeit (USA und Kanada)';
var str_GMT15 = 'Bogota, Lima, Quita';
var str_GMT16 = 'Carcacas';
var str_GMT17 = 'Santiago';
var str_GMT18 = 'Atlantische Zeit (Kanada)';
var str_GMT19 = 'Neufundland';
var str_GMT20 = 'Montevideo';
var str_GMT21 = 'Buenos Aires';
var str_GMT22 = 'Brasilien';
var str_GMT23 = 'Mittel-Atlantik';
var str_GMT24 = 'Kapverdische Inseln';
var str_GMT25 = 'Azoren';
var str_GMT26 = 'Dublin, Edinburgh, Lissabon, London';
var str_GMT27 = 'Casablance';
var str_GMT28 = 'Amsterdam, Berlin, Bern, Rom, Stockholm, Wien';
var str_GMT29 = 'Belgrad, Bratislava, Budapest, Ljubljana, Prag';
var str_GMT30 = 'Brüssel, Kopenhagen, Madrid, Paris';
var str_GMT31 = 'Sarajevo, Skopje, Warschau, Zagreb';
var str_GMT32 = 'Westzentralafrika';
var str_GMT33 = 'Athen, Bukarest, Istanbul';
var str_GMT34 = 'Bukarest';
var str_GMT35 = 'Kairo';
var str_GMT36 = 'Harare, Pretoria';
var str_GMT37 = 'Helsinki, Kiew, Riga, Sofia, Vilnius, Talinn';
var str_GMT38 = 'Jerusalem';
var str_GMT39 = 'Bagdad';
var str_GMT40 = 'Kuwait, Riad';
var str_GMT41 = 'Moskau, St. Petersburg, Wolgograd';
var str_GMT42 = 'Nairobi';
var str_GMT43 = 'Teheran';
var str_GMT44 = 'Abu_Dhabi, Muscat';
var str_GMT45 = 'Baku';
var str_GMT46 = 'Kabul';
var str_GMT47 = 'Jekaterinburg';
var str_GMT48 = 'Islamabad, Karachi';
var str_GMT49 = 'Chennai, Kolkata, Mumbai, Neu-Delhi';
var str_GMT50 = 'Katmandu';
var str_GMT51 = 'Nowosibirsk';
var str_GMT52 = 'Dhaka';
var str_GMT53 = 'Astana';
var str_GMT54 = 'Rangoon';
var str_GMT55 = 'Bangkok, Hanoi, Jakarta';
var str_GMT56 = 'Krasnojarsk';
var str_GMT57 = 'Peking, Chongqing, Hongkong, Urumqi';
var str_GMT58 = 'Irkutsk';
var str_GMT59 = 'Kuala Lumpur, Singapur';
var str_GMT60 = 'Perth';
var str_GMT61 = 'Taipei';
var str_GMT62 = 'Osaka, Sapporo, Tokio';
var str_GMT63 = 'Seoul';
var str_GMT64 = 'Jakutsk';
var str_GMT65 = 'Adelaide';
var str_GMT66 = 'Brisbane';
var str_GMT67 = 'Canberra, Melbourne, Sydney';
var str_GMT68 = 'Guam, Port Moresby';
var str_GMT69 = 'Hobart';
var str_GMT70 = 'Vladivostok';
var str_GMT71 = 'Magadan';
var str_GMT72 = 'Auckland, Wellington';
var str_GMT73 = 'Fiji';
var str_GMT74 = 'Nuku_alofa';


//Abfrage
var str_ask_sdfat32 = "Die SD-Karte wird als fat32 formatiert. Sind Sie sicher?";
var str_ask_sdstop = "Die SD-Karte wird gestoppt. Sind Sie sicher?";
var str_ask_recoverbak = "Die ipcam wird wiederhergestellt. Sind Sie sicher?";
var str_ask_syspath = "Bitte geben Sie den Dateipfad ein";
var str_ask_upgradesys = "Die IPcam wird aktualisiert. Sind Sie sicher?";
var str_ask_reboot = "Die ipcam wird neu gestartet. Sind sie sicher?";
var str_ask_recoverdef = "Konfigurationsdaten werden initialisiert. Sind Sie sicher?";


/// Anzeige
var str_adjustneff = "(Anpassung des Nachteffekts)";
var str_nightmode = "Nachtmodell";
var str_adjustnl = "Anpassung der Nachtluminanz";
var str_nlight = "Nachtluminanz";
var str_brightness = "Helligkeit";
var str_saturation = "Sättigung";
var str_contrast = "Kontrast";
var str_sharpness = "Schärfe";
var str_hue = "Chroma";
var str_shutter = "Verschluss";
var str_ldcratio = "Verzerrung";
var str_ae = "Minimale Exposition";
var str_targety = "Exposure";
var str_gamma = "Gamma";
var str_dnt = "Empfindlichkeit";
var str_lumi = "Leuchtdichte";
var str_imageset = "Bildeinstellungen";
var str_updown = "Flip";
var str_leftright = "Spiegel";
var str_wdr = "WDR";
var str_onmode = "Modus";
var str_mode = "Modus";
var str_black = "Schwarzweiß";
var str_color = "Farbe";
var str_aemode = "Belichtungsmodus";
var str_auto = "Auto";
var str_indoor = "Drinnen";
var str_outdoor = "Draußen";
var str_imgmode = "Bildmodus";
var str_framerate1 = "Framerate";
var str_inance = "Beleuchtungsstärke";
var str_ircut = "IRCut";
var str_ircutye = "(1-1024, je größer der Wert ist, desto größer ist die Schaltzeit)";
var str_sensitivity = "Empfindlichkeit";
var str_wdrmode = "WDR";
var str_wdrvalue = "WDR-Wert";
var str_lightmode     = "Modus des Lichts";
var str_changing      = "Veränderung";
var str_manual       = "Handbuch";
var str_lightness    = "Helligkeit";
var str_window = "Fenster";
var str_safetype = "Sicherheitsmodus";
var str_encway = "WPA-Algorithmus";
var str_key = "Schlüssel";
var str_confirmkey = "Bestätigungsschlüssel";
var str_checkwl = "Drahtlos-Einstellung überprüfen";
var str_hwctrl = "IR-LED-Steuerung";
var str_noise = "Rauschen";
var str_noisetye = "(0-100, je nach Arbeit niedriger)";
var str_lamp       = "Nachtsichtmodus";
var str_lamp0       = "Normal";
var str_lamp1       = "Vollfarbig";
var str_lamp2       = "Intelligent";

// kabellos
var str_wlenable = "Drahtlos aktivieren";
var str_conmode = "Modus";
var str_route = "Infrastruktur";
var str_p2p = "Punkt zu Punkt";

var str_welcome = "Wählen Sie aus, was Sie tun möchten:";
var str_pcview = "PC-Ansicht";
var str_mbview = "Mobile Ansicht";
var str_setupsoft   = "Konfiguration-Software (erstmalig)";

var str_sd = "SD-Karte";
var str_snap = "Erfassen";
var str_record = "Datensatz";
var str_playback = "Wiedergabe";
var str_up = "Nach oben";
var str_down = "Nach unten";
var str_right = "Rechts";
var str_left = "Links";
var str_center = "zentriert";
var str_ud = "rauf und runter kreuzend";
var str_lr = "links und rechts kreuzend";
var str_preset = "Voreinstellung";
var str_zoomin = "Vergrößern";
var str_zoomout = "Verkleinern";
var str_focusin = "Fokus +";
var str_focusout = "Fokus-";
var str_posset = "Einstellung";
var str_poscall = "Abrufen";
var str_refresh = "Aktualisieren";
// gb28181
var str_err_svrport = "Der reicht von 1 bis 65535.";
var str_gb28181 = "GB28181";
var str_gb_gb28181 = "GB28181";
var str_svrid = "Server-ID";
var str_svrip = "Server-Adresse";
var str_svrport = "Serverport";
var str_devid = "Geräte-ID";
var str_devport = "Geräte-Port";
var str_devpwd = "Gerätepasswort";
var str_alarmid = "Alarm-ID";
var str_heartcycle   ="Kreislauf des Herzschlags";
var str_heartcount   ="Maximale Pulszeit";
var str_regtime      ="Gültigkeit der Registrierung";

// Mehrere Einstellungen
var str_addport = 'Mehrere Einstellungen';
var str_addportset = 'Mehrere Einstellungen';
var str_local_host = "Host";
var str_refesh = "Aktualisieren";
var str_local_network = "LAN-Suche";
var str_first_dev = "Das 1. Gerät";
var str_second_dev = "Das 2. Gerät";
var str_third_dev = "Das 3. Gerät";
var str_fourth_dev = "Das 4. Gerät";
var str_fifth_dev = "Das 5. Gerät";
var str_sixth_dev = "Das 6. Gerät";
var str_seventh_dev = "Das 7. Gerät";
var str_eighth_dev = "Das 8. Gerät";
var str_ninth_dev = "Das 9. Gerät";
var str_add = "Hinzufügen";
var str_remove = "Entfernen";
var str_set = "Senden";
var str_cancel = "Abbrechen";
var str_none = 'Keine';
var str_overlay_name = 'Kameraname:';
var str_ip_address = 'IP:';
var str_http_port = 'Port:';
var str_user_name = 'Benutzer:';
var str_user_psw = 'Passwort:';
var str_anonymous = '';
var str_err_selected ="Der Host existiert nicht, bitte wählen Sie nochmal aus!" 
var str_err_hostnum  ="Bitte wählen Sie, um auf dem Host zu arbeiten!"; 

//wifi_Modus
var str_wifi_mode ='WiFi-Modus';
var str_wifimode ='Modus';
var str_wifi_speed ='Geschwindigkeit';
var str_wifi_channel ='Kanal';
var str_wifi_power ='Strom';
var str_wifimode0='Nicht modulierter kontinuierlicher TX Modus';
var str_wifimode1='Modulierter kontinuierlicher TX Modus';
var str_wifimode2='Kontinuierlicher RX Modus';

//4G
var str_4gset ='Einstellungen 4G';
var str_4grunmode ='Modus APN';
var str_4gauto ='Automatisch';
var str_4gmanual ='Handbuch';
var str_4gapn ='APN';
var str_4gsimcard ='SIM Karte';
var str_4gversion ='Version des Moduls';
var str_4gquality ='Qualität der Signale';
var str_4gmcc ='Code des Landes';
var str_4gmnc ='Code des Netzwerks';
var str_4gstatus ='Code des Status';
var str_4gauthtype ='Art der Verschlüsselung';
var str_4gcarrier ='Betreiber';
var str_4gimei ='IMEI';
var str_4giccid ='ICCID';

//Timer-Neustart 
var str_restarttime="Timer-Neustart";
var str_oclock="Uhr";

//Tmall Genie
var str_tmall="Tmall Genie";

//Amazon Echo
var str_amazon="Amazon Echo";