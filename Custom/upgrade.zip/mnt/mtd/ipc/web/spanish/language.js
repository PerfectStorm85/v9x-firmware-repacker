﻿// JavaScript Document
//punct
var colon    = ":";
var period   = ".";
var comma    = ",";
var blank    = "&nbsp;";
var exclamation = "!";

//deviceinfo
var str_devname = "ID de dispositivo";
var str_devtype = "Tipo de dispositivo";
var str_netstat = "Conexión de red";
var str_connnum = "Cliente actual";
var str_softver = "Versión de software";
var str_webware = "Versión de Webware";
var str_rs485ver   = "Versión de PTZ";
var str_macaddr = "Dirección de Mac";
var str_ipaddr = "Dirección IP";
var str_submask = "Máscara de subred";
var str_gateway = "Puerta de enlace";
var str_1stdns = "DNS primario";
var str_2nddns = "DNS secundario";
var str_upnpstatus = "Estado UPnP";
var str_facddnsstatus = "Estado DDNS de fabricantes";
var str_th3ddnsstatus = "Estado DDNS de terceros";
var success = "Éxito";
var unenable = "No habilitado";
var fail = "Fallado";
var str_sysstart = "Hora de inicio";
var str_sdstat = "Estado SD";
var str_connwireless = "WiFi";
var str_connwired = "LAN";
var str_conn4g     = "4G";
var str_dnsset = "Tipo de configuración de DNS";
var str_manualdns = "DNS manual";
var str_autodns = "DNS automático";
var str_httpport = "Puerto HTTP";
var str_rtspport = "Puerto RTSP";
var str_rtmpport = "Puerto RTMP";
var str_rtspauth = "Verificación de permisos RTSP";
var str_cap_cvbs = "Ajuste de CVBS";
var str_cloud = "Configuración de Cloud";
var str_cloudstat = "Estado Cloud";
var str_notpurchased = "Not Purchased";
var str_retention = "Días reservados"
var str_exptime = "Expiration Time";

//Terminal
var str_addrcode = "Dirección";
var str_protocol = "Protocolo";
var str_portset = "Configuración de puerto";
var str_485portset = 485 + str_portset;
var str_485set = "Ajuste 485";
var str_baudrate = "Baudio";
var str_databit = "Bit de datos";
var str_stopbit = "Bit de parada";
var str_check = "Tipo de verificación";
var str_none = "Ninguno";
var str_oddcheck = "Impar";
var str_evencheck = "Par";
var str_tiltscope = '(1-50)';
var str_tiltno = 'El número de vueltas de crucero no puede estar vacío.';
var tilttes = "Velocidad PTZ";
var tiltnum = "El número de vueltas de crucero";
var tiltmunmax = "Rango de número de vueltas de crucero: 1-50";
var tiltcenter = "Centrado mientras la autocomprobación";
var str_speed0 = "Rápido";
var str_speed1 = "Medio";
var str_speed2 = "Lento";
var str_ptzalarm = "Cerrar el movimiento de alarma PTZ";
var str_lenmodetip = 'Modo de visualización del indicador';
var str_lenmode1 = 'Siempre iluminado';
var str_lenmode2 = 'Siempre extinguido';
var str_smartrack="Órbita inteligente";

//FTP 
var str_pasvmode = "Modo pasivo";
var str_ftppic_name = "Nombre del archivo de imagen";
var str_time_name = "Nombre de hora y fecha";
var str_fixed_name = "Nombre de archivo fijo";
var str_alampic_name = "Nombre de archivo de imagen de captura de alarma";
var str_timepic_name = "Nombre de archivo de imagen de captura temporizada";
var str_filename_set = "Configuración de nombre de archivo";
var str_autocreatedir = "Crear automáticamente un directorio";

//Servidor
var str_server = "Dirección del servidor";
var str_port = "Puerto del servidor";
var str_username = "Nombre de usuario";
var str_password = "Contraseña";
var str_repassword = "Reescriba la contraseña";
var str_auth = "Autenticación";
var str_ftp_path = "Ruta";
var str_ftp_test = "Probar Ajuste de FTP";
var str_email_test = "Probar Ajuste de correo electrónico";

//Correo electrónico
var str_emailset = "Configuración de correo electrónico";
var str_smtpserv = "Nombre del servidor SMTP:";
var str_sendto = "Dirección de recepción";
var str_emailaddr = "Dirección de correo electrónico"
var str_sendaddr = "Dirección de envío";
var str_subject = "Asunto";
var str_info = "Mensaje";
var str_max127c = "la longitud máxima es 127";
var str_safelink = "Enlace seguro";
var str_massl0 = "Ninguno";
var str_massl1 = "SSL";
var str_massl2 = "TLS";
var str_massl3 = "STARTTLS";

// Captura automática
var str_timeint = "Intervalo";
var str_sendemail = "Enviar correo electrónico";
var str_savepic = "Guardar imagen en la tarjeta SD";
var str_ftpsnap = "Guardar imagen en el servidor FTP";
var str_cloudsnap  = "Guardar imagen en el servidor Cloud";

// Configuración de grabación
var str_recsetup = "Configuración de grabación";
var str_recfile = "Duración de los archivos grabados";
var str_recplan = "Grabación programada";
var str_allday = "Grabación a lo largo del día";
var str_allclear = "Sin grabación";
var str_timearea = "Registro de tiempo especificado";
var str_recswitch = "Si abrir grabación";
var str_all_area = 'Seleccionar Lista';
var str_no_area = 'Borrar lista';
var str_recformat = 'Formato de grabación';

//Alarma
var str_offenon = "Abrir";
var str_offenoff = "Cerrar";
var str_alarmex = "Alarma externa";
var str_alarmimode = "Modo de alarma externa";

//audio alarm
var str_alarmaudio = "Alarma de audio";
var str_audiorange = "Rango de volumen";

//smd
var str_alarmsmd ="Alarma humanoide";
var str_smdrecognition ="Reconocimiento humanoide inteligente";
var str_smdthreshold ="Límite";
var str_smdrect ="Marco forma humana";

//audio
var str_audioset = "Configuración de audio";
var str_collecta = "Colección de audio";
var str_auformat = "Tipo de audio";
var str_audioin = "Modo de entrada";
var str_volumein = "Volumen de entrada";
var str_volumeout = "Volumen de salida";
var str_inoption = "Opción de entrada";
var str_intype = "Tipo de entrada";
var str_aumicin = "MIC";
var str_aulinein = "Entrada lineal";

//Hora
var str_timenow = "Fecha y hora actuales";
var str_timedev = "Device Date Time";
var str_change = "Ajustar";
var str_manualset = "Configuración manual";
var str_date = "Fecha";
var str_time = "Hora";
var str_dateformat = "(aaaa-mm-dd)";
var str_timeformat = "(hh: mm: ss)";
var str_daterange = "(1971-01-01 ~ 2036-12-31)";
var str_syncfrompc = "Sincronizar con la hora de la computadora";
var str_syncfrompc1 = "Sincronizar con la hora de PC";
var str_pctime = "Hora de PC";
var str_ntserver = "Servidor de tiempo de red";
var str_ntpserver = "servidor NTP";
var str_synctime = "Intervalo";
var str_hour = "Horas";
var str_keeptmset = "Mantener la configuración actual";
var str_timezone = "Zona horaria";
var str_autotime = "Ajustar el tiempo automáticamente";

//Vídeo
var str_videoset = "Configuración de video";
var str_videomode = "Formato de video";
var str_videocoding = "Codificación de video";
var str_resolution = "Nitidez";
var str_streamrate = "Velocidad de bits";
var str_framerate = "Velocidad máxima de cuadros";
var str_framegap = "Intervalo de cuadro principal";
var str_vcodectrl = "Control de velocidad de bits";
var str_fixedcr = "CBR";
var str_variablecr = "VBR";
var str_vcodequa = "Calidad de imagen";
var str_osdset = "Ajuste de OSD";
var str_osdopt = "Opción de superposición";
var str_osdtime = "Tiempo de superposición";
var str_osdname = "Nombre de superposición";
var str_name = "Nombre";
var str_maxchn = "Canal de codificación de video más grande";
var str_colour = "Color";
var str_timeshow = "Visualización de tiempo";
var str_nameshow = "Visualización de nombre";
var str_tl = "Arriba a la izquierda";
var str_tr = "Arriba a la derecha";
var str_bl = "Abajo a la izquierda";
var str_br = "Arriba a la derecha";

//Plataforma
var str_plcon = "Habilitar";
var str_puidnum = "PUID";
var str_asp = "Acceso al puerto del servidor";
var str_asa = "Dirección del servidor de acceso";
var str_fsp = "Reenviar puerto de servidor";
var str_fsa = "Reenviar dirección del servidor";
var str_gpsi = "Intervalo de transmisión de información GPS";
var str_msec = "(milisegundos)";
var str_loginid = "ID de dispositivo";
var str_loginpass = "Contraseña";
var str_serverport = "Puerto";
var str_serveraddr = "Servidor";
var str_timeout = "Tiempo muerto";
var str_constate = "Estado de conexión";
var str_devnum = "ID de dispositivo";
var str_dvsn = "Número de serie";
var str_atransfer = "transmisión de audio";
var str_alarmtrans = "Transmisión de información de alarma";
var str_uid = "UID";
var str_server1 = "Servidor 1";
var str_server2 = "Servidor 2";
var str_server3 = "Servidor 3";
var str_server4 = "Servidor 4";

// Onvif
var str_onvifenable = "onvif";
var str_offcheck = "Sin verificación";
var str_timecheck = "Configuración de zona horaria";
var str_videocheck = "Configuración de imagen";
var str_allow = "Permitir";
var str_prohibit = "Prohibir";
var str_onvifchn = "Forma de circulación de subcódigo";
var str_onvifsnap = "Capturar el canal";
var str_onvifnvctype = "Tipo de NVC";
var str_normal = "Normal";
var str_uniview = "Uniview";

//alarma
var str_emailalarm = "Alarma de correo electrónico y Enviar imagen";
var str_sendpic = "Enviar imagen";
var str_saverecftp = "Guardar video en el servidor FTP";
var str_relayout = "Salida de relé";
var str_savevideo = "Guardar video en la tarjeta SD";
var str_cloudrecord  = "Configuración del servidor Cloud";
var str_ftpservset = "Configuración del servidor FTP";
var str_alarmplan = "Hora de alarma";
var str_alarmday = "Alarma de todo el tiempo";
var str_alarmclear = "Sin alarma";
var str_alermarea = "Alarma de tiempo especificado";
var str_mdalarm_type    ="Alarma Trigger";
var str_mdalarm_single    ="Separate trigger";
var str_mdalarm_union    ="Linkage trigger";
var str_linkset = "Configuración de vinculación";
var str_snapset = "Captura de imagen";
var str_snapnum = "Número de captura de imagen";
var str_alarmpreset = "Preajuste de enlace";
var str_alarmsound = "Sonido de vinculación";
var str_alarmbell = "Alarma";
var str_alarmdog = "Perro";
var str_alarmcustom = "Personalización";

//Red
var str_manualip = "Dirección IP fija";
var str_autoip = "Dirección IP dinámica";
var str_lnset = "Configuración de LAN";
var str_ipget = "Tipo de configuración de IP";
var str_internetip = "Dirección IP de Internet";
var str_netip = "Dirección IP de Internet";
var str_proddnsset = "Configuración de DDNS del fabricante";
var str_hostname = "Su dominio";
var str_3thdnsset = "Configuración de DDNS de terceros";
var str_servprov = "Proveedor";
var str_autoupnp = "Reenvío de puertos UPnP";
var str_wlcheck = "Comprobar configuración inalámbrica";
var str_wlsuccess = "Conectado a WiFi con éxito.";
var str_applywl = "Haga clic en 'Aplicar' para guardar la configuración inalámbrica.";
var str_wlfailed = "Ha fallado la conexión WiFi.";

//programar
var str_weekmode = "Usar el modo semana";
var str_weekendmode = "Usar el modo de trabajo";
var str_alltimemode = "Modo de todo el tiempo";
var str_week = "día";
var str_begintime = "empezar";
var str_endtime = "terminar";
var str_workday = "día laboral";
var str_freeday = "fin de semana";
var str_everyday = "Todos los días";
var str_sunday = "domingo";
var str_monday = "lunes";
var str_tuesday = "martes";
var str_wednesday = "miércoles";
var str_thursday = "jueves";
var str_friday = "viernes";
var str_saturday = "sábado";

//Navegación
var str_rtview = "Monitor";
var str_config = "Configuración";
var str_avargs = "Media";
var str_videoa = "Video";
var str_imagea = "Imagen";
var str_audioa = "Audio";
var str_netset = "Red";
var str_wlset = "Inalámbrico";
var str_ddnsset = "Ddns";
var str_plset = "Plataforma";
var str_onvif = "ONVIF";
var str_p2pset = "P2P";
var str_alarmset = "Alarma";
var str_alarmin = "Alarma en";
var str_mdset = "Detección de movimiento";
var str_alaction = "Alarma";
var str_altime = "horario";
var str_advset = "Avanzado";
var str_userset = "Usuario";
var str_timesnap = "Ajuste automático";
var str_timerec = "Grabación del temporizador";
var str_email = "Email";
var str_ftpset = "FTP";
var str_ptzset = "Terminal";
var str_sysset = "Sistema";
var str_timeset = "Tiempo";
var str_initset = "inicializar";
var str_devinfo = "Información del dispositivo";
var str_systemlog = "Registro del sistema";
var str_videoshade = "Sombra de video";

// sd op
var str_sdview = "Tarjeta SD del navegador";
var str_sdfat32 = "Formatear la tarjeta SD como fat32";
var str_sdstop = "Desconectar la tarjeta SD";

// sd stat
var str_havesd = "Con tarjeta";
var str_nothavesd = "Sin tarjeta";
var str_freespace = "espacio libre"
var str_totalspace = "espacio total"

// Actualización de copia de seguridad del sistema
var str_reboot = "Reiniciar";
var str_recoverdef = "Valor predeterminado de fábrica";
var str_backup = "Datos de configuración de copia de seguridad";
var str_recoverbak = "Restaurar";
var str_upgradesys = "Actualizar";
var str_lenstype = "Tipo de lente";

//Botón
var str_btn_reboot = "&nbsp; reiniciar &nbsp;";
var str_btn_save = "&nbsp; guardar &nbsp;";
var str_btn_confirm = "&nbsp; confirmar &nbsp;";
var str_btn_query = "&nbsp; consultar &nbsp;";
var str_btn_advanced = "&nbsp; Avanzado &nbsp;";
var str_btn_recoverdef = "predeterminado de fábrica";
var str_btn_apply = "&nbsp; Aplicar &nbsp;";
var str_btn_cancel = "Cancelar";
var str_btn_clear = "&nbsp; Borrar &nbsp;";
var str_btn_default = "Por defecto";
var str_btn_search = "&nbsp; buscar &nbsp;";
var str_btn_check = "&nbsp; revisar &nbsp;";
var str_btn_close = "&nbsp; cerrar &nbsp;";
var str_btn_refresh = "&nbsp; actualizar &nbsp;";
var str_btn_test = "Prueba";
var str_btn_cleanlog = "Borrar registro";

// Aviso
var str_note_upgrade = "&nbsp; La cámara IP se está actualizando, por favor no apague la cámara.";
var str_note_upgradeok = "¡El éxito de la actualización de la cámara IP!";
var str_note_needreset = "Nota: modifique la configuración, el sistema se reiniciará automáticamente";
var str_note_needreset0 = "(Nota: modifique la configuración, el sistema se reiniciará automáticamente)";
var str_note_needreset1 = "Nota: modifique la configuración, reinicie el dispositivo";
var str_note_needreset2 = "(Nota: modifique la configuración, reinicie el dispositivo)";
var str_note_astreamnote = "(móvil)";
var str_note_wlsetting = "Comprobando WiFi, espere unos 30 segundos.";
var str_note_inputpath = "por favor ingrese la ruta del archivo";
var str_note_inputipaddr = "ingrese la dirección IP";
var str_note_inputsubmask = "ingrese la dirección de la máscara de subred";
var str_note_inputgateway = "ingrese la dirección de la puerta de enlace";
var str_note_inputhostname = "por favor ingrese el dominio";
var str_note_inputusername = "por favor ingrese el nombre de usuario";
var str_note_inputpassword = "ingrese la contraseña";
var str_note_inputport = "ingrese el puerto del servidor";
var str_note_inputpath = "Ingrese la ruta raíz./";
var str_note_testtitle = "Por favor, establezca primero y luego pruebe.";
var str_note_inputservaddr = "ingrese la dirección del servidor";
var str_note_inputservname = "ingrese el nombre del servidor";
var str_note_inputemail = "ingrese la dirección de correo electrónico";
var str_note_inputsendaddr = "ingrese la dirección del remitente";
var str_note_inputasp = "Ingrese el puerto del servidor";
var str_note_inputasa = "Introduzca la dirección de acceso";
var str_note_inputfsp = "Ingrese el puerto del servidor del reenviador";
var str_note_inputfsa = "Introduzca la dirección del reenviador";
var str_note_inputtimeout = "Ingrese el valor de tiempo de espera";
var str_note_inputgpsi = "Ingrese el intervalo de transmisión de información GPS";
var str_note_noinpublicip = "Dirección IP de Internet: NULL";
var str_note_internetipis = "Dirección IP de Internet:";
var str_note_vcodequa = "(Cuanto menor sea el valor, mejor será la calidad de la imagen y el control de flujo más grande)";
var str_note_mbsize = "Resolución de imagen en movimiento";
var str_note_mdoff = "Nota: la detección de movimiento se deshabilitará cuando el primer flujo sea 320x176";
var str_note_maxframerate = "Las velocidades de fotogramas son mayores de 25.";
var str_note_maxbps = "El rango de velocidad de bits es 32-6144.";
var str_note_maxbps1 = "El rango de velocidad de bits es 32-8192.";
var str_note_maxbps2 = "El rango de velocidad de bits es 32-2048.";
var str_note_maxbps3 = "El rango de velocidad de bits es 32-512.";
var str_note_maxbps4 = "El rango de velocidad de bits es 32-256.";
var str_note_atransfer = "(Antes de abrir la transmisión de audio, ingrese a la página de configuración de audio y video, configure la segunda transmisión de audio en el modo de 'encendido', formato AMR)";
var str_note_ipportchange = "Se ha cambiado la IP o el puerto, por favor, vuelva a conectar";
var str_note_rhportsame = "http y rtsp usan el mismo puerto";
var str_note_inputdate = "por favor ingrese la fecha";
var str_note_inputtime = "por favor ingrese la hora";
var str_note_routemode = "(Seleccione el modo Infraestructura si usa un enrutador inalámbrico.)";
var str_note_inputascii = "por favor ingrese el carácter ASCII (la longitud es 5 o 13)";
var str_note_inputascii2 = "ingrese el carácter ASCII (la longitud es de 8 a 63)";
var str_note_inputhex = "por favor ingrese el carácter HEX (la longitud es 10 o 26)";
var str_note_inputssid = "ingrese el ssid";
var str_note_inputkey = "Introduzca la clave";
var str_note_inputrekey = "Ingrese la clave de confirmación";
var str_note_nosupportp2p = "WPA / WPA2 no admite el modo Punto a Punto.";
var str_note_turnoffmd = "la resolución del video es 320x176, la detección de movimiento está deshabilitada";
var str_note_autoreboot = "¡La máquina se reiniciará!";
var str_test_success = "Prueba ...... exitosa.";
var str_test_fail = "Prueba ...... fallida.";
var str_note_mdalarmtype   = "(La alarma de activación de enlace requiere que se active la detección de movimiento y la alarma humanoide).";



// error
var str_err_invaildc = "incluir carácter no válido";
var str_err_invaildc2 = "incluye un carácter no válido. (&, =, \", \\\) ";
var str_err_username = "error de nombre de usuario";
var str_err_hostname = "error de nombre de host";
var str_err_servname = "error de nombre de servidor";
var str_err_password = "error de contraseña";
var str_err_port = "El puerto es error";
var str_err_userinfo = "error de información del usuario, ingrese nuevamente";
var str_err_servbusy = "El servidor está ocupado, espere un momento";
var str_err_addrcode = "Dirección fuera de rango";
var str_err_port = "Error de puerto"
var str_err_servaddr = "Error de dirección del servidor";
var str_err_smptserv = "Error de puerto";
var str_err_emailaddr = "Dirección no válida";
var str_err_tooshort = "La longitud de la dirección debe ser mayor que 5";
var str_err_noat = "La dirección debe incluir el carácter '@'";
var str_err_addr1 = "Error de la dirección del receptor";
var str_err_addr2 = "";
var str_err_addr3 = "";
var str_err_sendaddr = "Error de la dirección del remitente";
var str_err_subject = "Error del asunto";
var str_err_info = "Error del mensaje";
var str_err_snapint = "El intervalo de tiempo es de 5-86400.";
var str_err_recfile = "El rango de tiempo es de 15-900 segundos";
var str_err_recfile1 = "El rango de tiempo es de 15-600 segundos";
var str_err_pwdconfirm = "Confirmar error de contraseña.";
var str_err_framegap = "El marco principal es de 2-300";
var str_err_gopframe   = "Key frame are less than framerate";
var str_err_osdname = "El número de la palabra 'es más que 18.";
var str_err_noname = "por favor ingrese el nombre de la cámara";
var str_err_noblank = "El nombre no puede ser todos los espacios";
var str_err_puid = "Error de PUID de entrada";
var str_err_asp = "Error de puerto de servidor de acceso";
var str_err_asa = "Error de dirección de acceso";
var str_err_fsp = "Error de puerto del servidor del reenviador";
var str_err_fsa = "Error de dirección del reenviador";
var str_err_username = "error de nombre de usuario";
var str_err_timeout = "Error de valor de tiempo de espera de entrada";
var str_err_tooutrange = "Tiempo de espera fuera de rango";
var str_err_devnum = "Error de ID de dispositivo de entrada";
var str_err_servaddr = "Error de dirección del servidor";
var str_err_input = "Error de entrada \ n \ n";
var str_err_addrrange1 = "dirección inválida, el primer número";
var str_err_addrrange2 = "dirección inválida, el segundo número";
var str_err_addrrange3 = "dirección inválida, el tercer número";
var str_err_addrlast = "dirección inválida, el último número"
var str_err_addr = "dirección inválida";
var str_err_value = "valor inválido";
var str_err_pctime = "El tiempo de su PC no es válido, el tiempo debe estar entre 1970-01-01 y 2037-12-31";
var str_err_dateformat = "formato de fecha no válido";
var str_err_dfinput = "el formato debe ser aaaa-mm-dd";
var str_err_reinputd = "la fecha no es válida, vuelva a ingresar";
var str_err_invaildtmf = "formato de fecha no válido";
var str_err_timeformat = "el formato debe ser hh: mm: ss";
var str_err_imvaildtm = "formato de hora no válido";
var str_err_key = "Error de la longitud de la clave. El hex es 10 o 26; ASCII es 5 o 13";
var str_err_ssid = "Error de SSID, incluye un carácter no válido";
var str_err_rekey = "Confirmar la clave es incorrecta";
var str_err_ssid = "Error de SSID, incluye un carácter no válido";
var str_err_ip2gateway = "IP y puerta de enlace no está en el mismo segmento de red";
var str_err_volume = "El volumen está fuera del rango (1-100), reinicie";
var str_err_username = "El nombre de usuario no puede ser el mismo";
var str_err_nameerr = "El nombre de usuario solo puede contener letras y números";
var str_err_nousername = "Por favor ingrese el nombre de usuario";
var str_error_none = "Un error desconocido";
var str_error_server = "No se puede conectar al servidor";
var str_error_namepwd = "Usuario o contraseña incorrectos";
var str_error_dir = "Error de ruta";
var str_error_ssl = "Error de configuración de SSL";


var str_bps32_2048 = "La velocidad de bits del primer flujo es de 32-2048 kbps";
var str_bps32_512 = "La velocidad de bits del primer flujo es de 32-512 kbps";
var str_bps32_256 = "La velocidad de bits del primer flujo es de 32-256 kbps";

//distancia
var str_1_65535 = "1-65535";
var str_1_223_127 = "debe entre 1 a 223 y no 127";
var str_0_255 = "debe entre 0 y 255";
var str_1_255 = "debe entre 1 a 255";
var str_0_254 = "debe entre 0 y 254";
var str_1_254 = "debe entre 1 y 254"
var str_80or1024_49151 = "(80 or1024 ~ 49151)";
var str_554or1024_49151 = "(554 or1024 ~ 49151)";
var str_1935or1024_49151 = "(1935 o 1024 ~ 49151)";
var str_daterange = "la fecha debe estar entre 1971-01-01 y 2036-12-31, vuelva a ingresar";
var str_drange = "(1971-01-01 ~ 2036-12-31)";

// no ins
var str_noins0 = "El mensaje de advertencia se muestra de la siguiente manera:";
var str_noins1 = "1. No ha instalado este control ActiveX.";
var str_noins2 = "2. Ha instalado, pero existe una versión actualizada del control ActiveX que necesita descargar.";
var str_noins3 = "3. Tienes que conectarte a Internet.";
var str_noins4 = "Haga clic en";
var str_noins5 = "Descargar ActivX";
var str_noins6 = "y haga clic en";
var str_noins7 = "correr";
var str_noins8 = "en el cuadro de mensaje emergente para instalar este control ActiveX, finalmente, actualizar esta página web, iniciar un dispositivo, luego puede ver el video";

//En uso común
var str_readonly = "Solo lectura";
var str_rate = "Velocidad";
var str_auto = "Auto";
var str_view = "Revisar";
var str_minute = "Minutos";
var str_stream = "Corriente";
var str_1ststream = "Primer corriente";
var str_2ndstream = "Segundo corriente";
var str_3thstream = "Tercer corriente";
var str_on = "Abrir";
var str_off = "Cerrar";
var str_online = "Conectado";
var str_offline = "Desconectado";
var str_sec = "Segundo"
var str_language_ex  = "Language";
var str_ch_ex        = "Chinese";
var str_en_ex        = "English";
var str_fr_ex        = "Français";
var str_de_ex        = "Deutsch";
var str_it_ex        = "Italiano";
var str_sp_ex        = "Español";
var str_ru_ex        = "русский язык";
var str_ja_ex        = "日本語";
var str_kr_ex        = "Korean";
var str_pl_ex        = "Polski";
var str_language = "Idioma";
var str_chinese = "Chino";
var str_english = "Inglés";
var str_francaise = "Francés";
var str_deutsch   = "Alemán";
var str_italiano  = "Italiano";
var str_spanish   = "Español";
var str_russian   = "русский язык";
var str_japan    = "日本語";
var str_korean   = "coreano";
var str_poland    = "Polski";
var str_add = "Acción";
var str_encrypt = "Encriptación";
var str_authen = "Autenticar";
var str_connetm = "Tipo de red";
var str_channel = "Canal";
var str_confirm = "Participar";
var str_purview = "Permiso";


//zona horaria
var str_GMT1 = 'Línea de fecha internacional oeste';
var str_GMT2 = 'Samoa';
var str_GMT3 = 'Hawaii';
var str_GMT4 = 'Alaska';
var str_GMT5 = 'Hora del Pacífico (EE. UU. y Canadá)';
var str_GMT6 = 'Chihuahua';
var str_GMT7 = 'Tiempo de montaña (EE. UU. y Canadá)';
var str_GMT8 = 'Arizona';
var str_GMT9 = 'Saskatchewan';
var str_GMT10 = 'Guadalajars, Ciudad de México, Monterrey';
var str_GMT11 = 'Hora central (EE. UU. y Canadá)';
var str_GMT12 = 'América Central';
var str_GMT13 = 'Indians (East)';
var str_GMT14 = 'Hora del Este (EE. UU. y Canadá)';
var str_GMT15 = 'Bogotá, Lima, Quita';
var str_GMT16 = 'Carcacas';
var str_GMT17 = 'Santiago';
var str_GMT18 = 'Hora del Atlántico (Canadá)';
var str_GMT19 = 'Terranova';
var str_GMT20 = 'Montevideo';
var str_GMT21 = 'Buenos Aires';
var str_GMT22 = 'Brasilia';
var str_GMT23 = 'Mid-Atlantic';
var str_GMT24 = 'Islas de Cabo Verde';
var str_GMT25 = 'Azores';
var str_GMT26 = 'Dublín, Edimburgo, Lisboa, Londres';
var str_GMT27 = 'Casablance';
var str_GMT28 = 'Ámsterdam, Berlín, Berna, Roma, Estocolmo, Viena';
var str_GMT29 = 'Belgrado, Bratislava, Budapest, Ljubljana, Praga';
var str_GMT30 = 'Bruselas, Copenhague, Madrid, París';
var str_GMT31 = 'Sarajevo, Skopje, Varsovia, Zagreb';
var str_GMT32 = 'África Central Occidental';
var str_GMT33 = 'Atenas, Bucarest, Estambul';
var str_GMT34 = 'Bucharest';
var str_GMT35 = 'El Cairo';
var str_GMT36 = 'Harare, Pretoria';
var str_GMT37 = 'Helsinki, Kiev, Riga, Sofía, Vilnius, Talinn';
var str_GMT38 = 'Jerusalem';
var str_GMT39 = 'Bagdad';
var str_GMT40 = 'Kuwait, Riyadh';
var str_GMT41 = 'Moscú, San Petersburgo, Volgogrado';
var str_GMT42 = 'Nairobi';
var str_GMT43 = 'Teherán';
var str_GMT44 = 'Abu_Dhabi, Muscat';
var str_GMT45 = 'Baku';
var str_GMT46 = 'Kabul';
var str_GMT47 = 'Ekaterimburgo';
var str_GMT48 = 'Islamabad, Karachi';
var str_GMT49 = 'Chennai, Kolkata, Mumbai, Nueva Delhi';
var str_GMT50 = 'Katmandu';
var str_GMT51 = 'Novosibirsk';
var str_GMT52 = 'Dhaka';
var str_GMT53 = 'Astana';
var str_GMT54 = 'Rangoon';
var str_GMT55 = 'Bangkok, Hanoi, Jakarta';
var str_GMT56 = 'Krasnoyarsk';
var str_GMT57 = 'Beijing, Chongqing, Hong Kong, Urumqi';
var str_GMT58 = 'Irkutsk';
var str_GMT59 = 'Kuala Lumpur, Singapur';
var str_GMT60 = 'Perth';
var str_GMT61 = 'Taipei';
var str_GMT62 = 'Osaka, Sapporo, Tokio';
var str_GMT63 = 'Seúl';
var str_GMT64 = 'Yakutsk';
var str_GMT65 = 'Adelaide';
var str_GMT66 = 'Brisbane';
var str_GMT67 = 'Canberra, Melbourne, Sydney';
var str_GMT68 = 'Guam, Port Moresby';
var str_GMT69 = 'Hobart';
var str_GMT70 = 'Vladivostok';
var str_GMT71 = 'Magadan';
var str_GMT72 = 'Auckland, Wellington';
var str_GMT73 = 'Fiji';
var str_GMT74 = 'Nuku_alofa';


//Consulta
var str_ask_sdfat32 = "La tarjeta SD se formateará como fat32. ¿Está seguro?";
var str_ask_sdstop = "La tarjeta SD se detendrá. ¿Está seguro?";
var str_ask_recoverbak = "La cámara IP se restaurará. ¿Está seguro?";
var str_ask_syspath = "Ingrese la ruta del archivo";
var str_ask_upgradesys = "La ipcam se actualizará. ¿Está seguro?";
var str_ask_reboot = "la ipcam se reiniciará. ¿Está seguro?";
var str_ask_recoverdef = "Se inicializarán los datos de configuración. ¿Está seguro?";


/// Monitor
var str_adjustneff = "(Ajuste del efecto nocturno)";
var str_nightmode = "Modelo nocturno";
var str_adjustnl = "Ajuste de luminancia nocturna";
var str_nlight = "luminancia nocturna";
var str_brightness = "Brillo";
var str_saturation = "Saturación";
var str_contrast = "Contraste";
var str_sharpness = "Nitidez";
var str_hue = "Chroma";
var str_shutter = "Shutter";
var str_ldcratio = "Distorsión";
var str_ae = "Exposición mínima";
var str_targety = "Exposición";
var str_gamma = "Gamma";
var str_dnt = "Sensibilidad";
var str_lumi = "Luminancia";
var str_imageset = "Configuración de imagen";
var str_updown = "Flip";
var str_leftright = "Mirror";
var str_wdr = "WDR";
var str_onmode = "Modo";
var str_mode = "Modo";
var str_black = "Blanco y Negro";
var str_color = "Color";
var str_aemode = "Modo de exposición";
var str_auto = "Auto";
var str_indoor = "Interior";
var str_outdoor = "Exterior";
var str_imgmode = "Modo de prioridad de imagen";
var str_framerate1 = "Velocidad de fotogramas";
var str_inance = "Iluminancia";
var str_ircut = "IRCut";
var str_ircutye = "(1-1024, cuanto mayor sea el valor, mayor será el tiempo de conmutación)";
var str_sensitivity = "Sensibilidad";
var str_wdrmode = "WDR";
var str_wdrvalue = "Valor WDR";
var str_lightmode     = "Modo de iluminación";
var str_changing      = "Cambio";
var str_manual       = "Manual";
var str_lightness    = "Ligereza";
var str_window = "Ventana";
var str_safetype = "Modo de seguridad";
var str_encway = "Algoritmo WPA";
var str_key = "Clave";
var str_confirmkey = "Clave de confirmación";
var str_checkwl = "Comprobar configuración inalámbrica";
var str_hwctrl = "IR LED Control";
var str_noise = "Ruido";
var str_noisetye = "(0-100, inferior según el trabajo)";
var str_lamp       = "Modo de visión nocturna";
var str_lamp0       = "Normal";
var str_lamp1       = "A todo color";
var str_lamp2       = "Inteligente";

// inalámbrico
var str_wlenable = "Habilitar inalámbrico";
var str_conmode = "Modo";
var str_route = "Infraestructura";
var str_p2p = "Punto a punto";

var str_welcome = "Selecciona lo que quiere hacer:";
var str_pcview = "PC view";
var str_mbview = "Vista móvil";
var str_setupsoft = "Software de instalación (primera vez)";

var str_sd = "Tarjeta SD";
var str_snap = "Captura";
var str_record = "Grabar";
var str_playback = "Reproducir";
var str_up = "Arriba";
var str_down = "Abajo";
var str_right = "Derecha";
var str_left = "Izquierda";
var str_center = "Centro";
var str_ud = "Crucero arriba y abajo";
var str_lr = "Crucero a la izquierda y derecha";
var str_preset = "Preajuste";
var str_zoomin = "Acercar";
var str_zoomout = "Alejar";
var str_focusin = "Focus +";
var str_focusout = "Focus-";
var str_posset = "Ajuste";
var str_poscall = "Llamar";
var str_refresh = "Actualizar";
// gb28181
var str_err_svrport = "El rango del puerto es de 1 a 65535.";
var str_gb28181 = "GB28181";
var str_gb_gb28181 = "GB28181";
var str_svrid = "ID de servidor";
var str_svrip = "Dirección del servidor";
var str_svrport = "Puerto del servidor";
var str_devid = "ID de dispositivo";
var str_devport = "Puerto del dispositivo";
var str_devpwd = "Contraseña del dispositivo";
var str_alarmid = "ID de alarma";
var str_heartcycle   ="Ciclo cardíaco";
var str_heartcount   ="Tiempo máximo de latido cardíaco";
var str_regtime      ="Período de validez del registro";

// Configuraciones múltiples
var str_addport = 'Configuraciones múltiples';
var str_addportset = 'Configuraciones múltiples';
var str_local_host = "Nativo";
var str_refesh = "Actualizar";
var str_local_network = "Búsqueda de lan";
var str_first_dev = "El primer dispositivo";
var str_second_dev = "El segundo dispositivo";
var str_third_dev = "El tercer dispositivo";
var str_fourth_dev = "El cuarto dispositivo";
var str_fifth_dev = "El quinto dispositivo";
var str_sixth_dev = "El sexto dispositivo";
var str_seventh_dev = "El séptimo dispositivo";
var str_eighth_dev = "El octavo dispositivo";
var str_ninth_dev = "El noveno dispositivo";
var str_add = "Agregar";
var str_remove = "Eliminar";
var str_set = "Enviar";
var str_cancel = "Cancelar";
var str_none = 'Ninguno';
var str_overlay_name = 'Nombre de la cámara:';
var str_ip_address = 'IP:';
var str_http_port = 'Puerto:';
var str_user_name = 'Usuario:';
var str_user_psw = 'Contraseña:';
var str_anonymous = '';
var str_err_selected = "El host no existe, por favor, elija otra vez!"
var str_err_hostnum = "Por favor, elija operar en el host!";

// wifi_mode
var str_wifi_mode = 'Modo Wifi';
var str_wifimode = 'Modo';
var str_wifi_speed = 'Velocidad';
var str_wifi_channel = 'Canal';
var str_wifi_power = 'Power';
var str_wifimode0 = 'Modo de transmisión continua sin modulación ninguna';
var str_wifimode1 = 'Modo de transmisión continua modulada';
var str_wifimode2 = 'Modo RX continuo';

//4G
var str_4gset ='Configuración 4G';
var str_4grunmode ='Modo APN';
var str_4gauto ='Automaticidad';
var str_4gmanual ='Manual';
var str_4gapn ='APN';
var str_4gsimcard ='Tarjeta SIM';
var str_4gversion ='Versión del módulo';
var str_4gquality ='Calidad de señal';
var str_4gmcc ='Código del país';
var str_4gmnc ='Código de red';
var str_4gstatus ='Código de Estado';
var str_4gauthtype ='Tipo de cifrado';
var str_4gcarrier ='Operador M.';
var str_4gimei ='IMEI';
var str_4giccid ='ICCID';

// reiniciar el temporizador
var str_restarttime = "Reinicio del temporizador";
var str_oclock = "en punto";

//Tmall Genie
var str_tmall="Tmall Genie";

//Amazon Echo
var str_amazon="Amazon Echo";