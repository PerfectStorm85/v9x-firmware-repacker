#! /bin/sh

IPC_PATH="/mnt/mtd/ipc"
rm -fr $IPC_PATH/wificfguide.g711
rm -fr $IPC_PATH/start.g711
rm -fr $IPC_PATH/succeed.g711
rm -fr $IPC_PATH/reset.g711
rm -fr $IPC_PATH/finish.g711
rm -fr $IPC_PATH/failed.g711
rm -fr $IPC_PATH/4gstart_*.g711
rm -fr $IPC_PATH/4gcheck_*.g711
rm -fr $IPC_PATH/4gnosim_*.g711
rm -fr $IPC_PATH/4gsucceed_*.g711
rm -fr $IPC_PATH/4gfailed_*.g711

#sync
