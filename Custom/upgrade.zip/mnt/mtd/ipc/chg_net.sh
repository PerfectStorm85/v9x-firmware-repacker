#! /bin/sh

TARGET="/mnt/mtd/ipc"
DRV_PATH="$TARGET/modules"
CONF="$TARGET/conf"
NETDEV=eth0
WIFIPATH="$CONF/wifi.conf"
. $WIFIPATH
NETINFO=$CONF/config_net.ini
NETPRIV=$CONF/config_priv.ini
PLATFORM=$CONF/config_platform.ini

DEF_IPADDR="192.168.1.88"
DEF_GATEWAY="192.168.1.1"

clearRoute()
{
	route del -net 239.0.0.0 netmask 255.0.0.0 eth0
	route del -net 239.0.0.0 netmask 255.0.0.0 wlan0
	GATEWAY=`route | grep default | awk -F " " '{printf $2}'`
	route del default gw $GATEWAY
	GIP=`route | grep eth0 | awk -F " " '{printf $1}'`
	GNM=`route | grep eth0 | awk -F " " '{printf $3}'`
	route del -net $GIP netmask $GNM
	GIP=`route | grep wlan0 | awk -F " " '{printf $1}'`
	GNM=`route | grep wlan0 | awk -F " " '{printf $3}'`
	route del -net $GIP netmask $GNM	
}

setRoute()
{
	ipaddr1=`ifconfig $NETDEV | grep "inet addr:" | awk '{printf $2}' | awk -F ":" '{printf $2}'`
    gat1=`echo $ipaddr1 | awk -F "." '{print $1}'`
    gat2=`echo $ipaddr1 | awk -F "." '{print $2}'`
    gat3=`echo $ipaddr1 | awk -F "." '{print $3}'`
    routeway1="$gat1.$gat2.$gat3.0" 
    route add -net $routeway1 netmask 255.255.255.0 $NETDEV
}

loadwifista()
{
	wpa_cli -i wlan0 -p /var/run/wpa_supplicant remove_network 0
	wpa_cli -i wlan0 -p /var/run/wpa_supplicant add_network
	wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 scan_ssid 1
	wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 ssid "\"${WifiSsid}\""
	if [ $WifiEnc == "NONE" ]
	then	
		wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 key_mgmt NONE
	elif [ $WifiEnc == "WEP" ]
		then
		wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 key_mgmt NONE
		StrNum=`echo "$WifiKey" | wc -L`
		if [ $StrNum -eq  5 ]
		then
			wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 wep_key0 "\"$WifiKey\""
		elif [ $StrNum -eq  13 ]
		then
			wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 wep_key0 "\"$WifiKey\""
		else
			wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 wep_key0 $WifiKey
		fi
		wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 wep_tx_keyidx 0
		wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 auth_alg 'OPEN SHARED'
	else
		wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 key_mgmt WPA-PSK
		wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 psk "\"$WifiKey\""
	fi
	wpa_cli -i wlan0 -p /var/run/wpa_supplicant set_network 0 scan_ssid 1
	wpa_cli -i wlan0 -p /var/run/wpa_supplicant select_network 0
}

loadwifiap()
{
	TUUID=`/mnt/mtd/ipc/readcfg $PLATFORM "xquncfg:xqunuuid"`
	TUUID=`echo $TUUID | awk -F "-" '{print $2}'`
	WifiSsid="IPCAM-$TUUID"
	TMP=/mnt/mtd/ipc/tmpfs/wf129
	TMP1=/mnt/mtd/ipc/tmpfs/wf129t
	SEARCH=/mnt/mtd/ipc/tmpfs/wifi.search
	if grep 8731 /mnt/mtd/ipc/tmpfs/wifi.type
	then
		echo 1 > /proc/net/rtl8733bu/wlan0/survey_info
		usleep 500000
		cat /proc/net/rtl8733bu/wlan0/survey_info > $SEARCH
		/mnt/mtd/ipc/wf_merge $SEARCH $TMP 0
		sleep 5
		echo 1 > /proc/net/rtl8733bu/wlan0/survey_info
		usleep 500000
		cat /proc/net/rtl8733bu/wlan0/survey_info > $SEARCH
		/mnt/mtd/ipc/wf_merge $SEARCH $TMP 1	
	else
	iwlist wlan0 scanning > $SEARCH
	/mnt/mtd/ipc/m_wpa_cli $SEARCH $TMP 0
	fi
	if grep 7601 /mnt/mtd/ipc/tmpfs/wifi.type
	then	
		/mnt/mtd/ipc/wfsort $TMP $TMP1 0
	elif grep 8731 /mnt/mtd/ipc/tmpfs/wifi.type
	then
		/mnt/mtd/ipc/wfsort $TMP $TMP1 3
	elif grep 3733 /mnt/mtd/ipc/tmpfs/wifi.type
	then
		/mnt/mtd/ipc/wfsort $TMP $TMP1 4		
	else
		/mnt/mtd/ipc/wfsort $TMP $TMP1 1
	fi
	mv $TMP1 $TMP
	wpa_cli terminate
	wpa_cli terminate
	ifconfig wlan0 $DEF_IPADDR netmask 255.255.255.0
	if grep -E '7601|8731|9101|3733' /mnt/mtd/ipc/tmpfs/wifi.type
	then
		cp $TARGET/conf/hostapd7601.conf $TARGET/tmpfs/hostapd.conf
		echo "ssid=$WifiSsid" >> $TARGET/tmpfs/hostapd.conf
		echo channel=$(($RANDOM%10+1)) >> $TARGET/tmpfs/hostapd.conf
		hostapds $TARGET/tmpfs/hostapd.conf -B
	else
		AP_MODE=`/mnt/mtd/ipc/readcfg /mnt/mtd/ipc/conf/config_wifi.ini "global:apmode"`
		if [ $AP_MODE -eq 0 ]
		then
			cp $TARGET/conf/hostapd8192_2g.conf $TARGET/tmpfs/hostapd.conf
			echo "ssid=$WifiSsid" >> $TARGET/tmpfs/hostapd.conf
			echo channel=$(($RANDOM%10+1)) >> $TARGET/tmpfs/hostapd.conf
		else
			cp $TARGET/conf/hostapd8192_5g.conf $TARGET/tmpfs/hostapd.conf
			echo "ssid=$WifiSsid" >> $TARGET/tmpfs/hostapd.conf	    	
			echo channel=36 >> $TARGET/tmpfs/hostapd.conf
		fi
		hostapd $TARGET/tmpfs/hostapd.conf -B
	fi
	udhcpd -f /mnt/mtd/ipc/conf/udhcps/udhcpd.conf &
	route add default gw $DEF_GATEWAY
}

loadNetwork()
{	
    dhcp1=`grep dhcp $NETINFO | awk -F "\"" '{print $2}'`
    ipaddr1=`grep ipaddr $NETINFO | awk -F "\"" '{print $2}'`
    gateway1=`grep gateway $NETINFO | awk -F "\"" '{print $2}'`
    netmask1=`grep netmask $NETINFO | awk -F "\"" '{print $2}'` 

    gat1=`echo $ipaddr1 | awk -F "." '{print $1}'`
    gat2=`echo $ipaddr1 | awk -F "." '{print $2}'`
    gat3=`echo $ipaddr1 | awk -F "." '{print $3}'`
    gat4=`echo $ipaddr1 | awk -F "." '{print $4}'`
    gateway2="$gat1.$gat2.$gat3.1"     	   	
		
	if [ $dhcp1 = "y" ] 
	then
		$TARGET/dhcp.sh $NETDEV &
		sleep 5
		return 0
	fi   

	if ! ifconfig $NETDEV $ipaddr1 netmask $netmask1
	then
		ifconfig $NETDEV $DEF_IPADDR netmask 255.255.255.0	
	fi
	
	if ! route add default gw $gateway1
	then
		if ! route add default gw $gateway2
		then
			route add default gw $DEF_GATEWAY
		fi
	fi
		
	killall runarp
	$TARGET/runarp $NETDEV & > /dev/null	
		
	return 0      
}

loadwifi()
{
	if [ $WifiType = "Infra" ]	
	then
    	loadwifista
    	loadNetwork
    	$TARGET/updatewifi &
	else
		loadwifiap
                $TARGET/load_ble.sh &
	fi
}

loadAround()
{
    $TARGET/facddns.sh
    $TARGET/upnpmap.sh
    $TARGET/th3ddns.sh
    $TARGET/loadp2p.sh 1 &
}

NETFL=`cat /mnt/mtd/ipc/tmpfs/netchg`
killall dhcp.sh
killall udhcpc	
killall load_ble.sh
sleep 1
killall udhcpc
killall udhcpd
killall hostapd
killall hostapds
killall upnp_map
killall updatewifi
killall onvif
killall ble
rm /mnt/mtd/ipc/tmpfs/wifi.ok 2> /dev/null
wpa_cli -i wlan0 -p /var/run/wpa_supplicant remove_network 0

if [ $NETFL -eq 0 ]
then
	NETDEV="eth0"
	if [ $WifiType = "Adhoc" ]
	then
		ifconfig wlan0 up
		if grep -E '7601|8731|3733' /mnt/mtd/ipc/tmpfs/wifi.type
		then
			wpa_supplicant -B -D nl80211 -i wlan0 -c /mnt/mtd/ipc/tmpfs/wpa.conf					
		else
			wpa_supplicant -B -D wext -i wlan0  -c /mnt/mtd/ipc/tmpfs/wpa.conf
		fi
		wpa_cli -i wlan0 -p /var/run/wpa_supplicant remove_network 0
	fi
	clearRoute
	setRoute
	loadNetwork
	NETFLAG="0"
else
	NETDEV="wlan0"
	clearRoute
	setRoute
	loadwifi
	NETFLAG="1"
fi

echo $NETFLAG > $TARGET/tmpfs/netflag.dat

loadAround

rm -f /mnt/mtd/ipc/tmpfs/netchg
