#! /bin/sh

killall chksock.sh
killall sd.sh

OPID=`ps | grep udhcpc | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep sd_detect | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep gerddns | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep ddns_update | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep upnp_map | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep proxy | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep onvif | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep tutk | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep gbdog | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep gb28181 | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep updatewifi | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep net_detect | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep upnpd | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep mdns | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep g4dial | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep ble | awk '{print $1}'`
kill -9 $OPID
OPID=`ps | grep tlsvr | awk '{print $1}'`
kill -9 $OPID