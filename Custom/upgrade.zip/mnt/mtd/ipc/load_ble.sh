#! /bin/sh

PLATFORM=/mnt/mtd/ipc/conf/config_platform.ini
TUUID=`/mnt/mtd/ipc/readcfg $PLATFORM "xquncfg:xqunuuid"`

# 1: 8733 2:3873
ModuleType=1

# 1:2.4G 2:5.8G
WifiType=2

# Second
Timeout=1

for count in $(seq 1 10)
do
	rm /mnt/mtd/ipc/tmpfs/blestat
	sleep 1
	/mnt/mtd/ipc/ble $ModuleType $WifiType $TUUID $Timeout /mnt/mtd/ipc/wifi_setblue.sh
	APSTAT=`cat /mnt/mtd/ipc/tmpfs/blestat`
	if [ $APSTAT -eq 0 ]
	then
		exit 0
	fi
done
